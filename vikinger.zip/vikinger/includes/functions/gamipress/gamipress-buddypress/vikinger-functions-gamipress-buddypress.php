<?php
/**
 * Functions - GamiPress + BuddyPress
 * 
 * @package Vikinger
 * 
 * @since 1.9.1
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

/**
 * Actions
 */
require_once VIKINGER_PATH . '/includes/functions/gamipress/gamipress-buddypress/vikinger-functions-gamipress-buddypress-actions.php';

?>
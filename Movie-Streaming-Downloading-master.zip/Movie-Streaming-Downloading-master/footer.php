<div class="mt-5">
<footer class="footer new_footer mt-auto py-3" style="background-color: #080808; color: #ffffff;">
    <div class="container text-center">
        <span>Copyright HDMovies.com &copy; 2020</span>
    </div>
</footer>
</div>
<?php
set_time_limit(0);
ini_set("memory_limit", "512M");

/* CONFIG */
$playlistUrl =
"http://filex.me:8080/get.php?username=MAS101A&password=MAS101AABB&type=m3u_plus&output=m3u8";

$proxyBase = "https://siam3310-iptv.wasmer.app/?url=";

$allowedGroups = [
    "✯CRICKET✯",
    "T20 | WORLDCUP (2026)"
];

$outputFile = __DIR__ . "/channels.json";

/* fetch playlist */
function fetchPlaylist($url) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_USERAGENT => "Mozilla/5.0"
    ]);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
}

$m3u = fetchPlaylist($playlistUrl);
if (!$m3u) exit("Fetch failed");

$lines = explode("\n", $m3u);

$result = [];
$current = null;

foreach ($lines as $line) {
    $line = trim($line);

    if (strpos($line, "#EXTINF") === 0) {

        preg_match('/group-title="([^"]+)"/', $line, $g);
        preg_match('/,(.*)$/', $line, $name);

        $group = $g[1] ?? "";
        $channelName = $name[1] ?? "Channel";

        if (in_array($group, $allowedGroups)) {
            $current = [
                "name" => $channelName,
                "category" => $group
            ];
        } else {
            $current = null;
        }

    } elseif ($current && strpos($line, "http") === 0) {

        $current["stream_url"] =
            $proxyBase . urlencode($line);

        $result[] = $current;
        $current = null;
    }
}

file_put_contents(
    $outputFile,
    json_encode($result, JSON_PRETTY_PRINT)
);

echo "JSON Updated: " . count($result) . " channels\n";

<?php
/**
 * Activity Log Options
 */

defined( "ABSPATH" ) || exit;

?>
<div class="lt-at-error-logs tlm-atd-panel">
 
        <h2><?php esc_html_e( 'Activity Log', 'tutor-lms-attendance' ); ?></h2>
 
    <div class="tatd-row-debug">
    <p>
	    <?php
	    printf(
	    // Translators: placeholder is a link to WP_DEBUG documentation.
		    esc_html__( '%s activity logs allows WooNinja\'s support team to identify the issue easily.', 'tutor-lms-attendance' ),
		    __('TutorLMS Attendance', 'tutor-lms-attendance')
	    );
	    ?>
    </p>

    <div class="site-health-copy-buttons">
        <div class="copy-button-wrapper">
            <button type="button" class="button tlms-ad-activity-copy-button" data-clipboard-text=""><?php _e('Copy to Clipboard', 'tutor-lms-attendance'); ?></button>
            <span class="success hidden" aria-hidden="true">Copied!</span>
        </div>
    </div>
    </div>
    <div id="error-log-wrapper">
        <textarea  rows="16" cols="80" class="code large-text tlms-ad-activity-code-box" class="large-text" rows="15" name="wn-ld-qie-debug-logs"><?php echo esc_textarea( (new Tutor_Lms_Logging())->get_log() ); ?></textarea>

    </div>
    <div class="error-log-info" style="margin-top: 1rem;">
        <code><?php echo esc_html( basename( (new Tutor_Lms_Logging())->get_filename() ) ); ?></code>
        <a class="ld-qie-debug-clear-button" href="<?php echo add_query_arg( array( 'page' => 'tlms-attendance', 'tab' => 'activity_log', 'action' => 'clear_activity_log' ), admin_url( 'admin.php' ) );?>"><?php _e('Clear Log', 'tutor-lms-attendance'); ?></a>
    </div>
</div>
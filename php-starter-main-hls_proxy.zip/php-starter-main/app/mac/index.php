<?php
include("_inc.configs.php");
?>
<!DOCTYPE html>
<html>
<head>
<title><?php print($APP_CONFIG['APP_NAME']); ?> | TV Channels</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
<link rel="shortcut icon" href="assets/favicon.png"/>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400&display=swap" rel="stylesheet">
<style>
  body {
    background-color: #000;
    color: #fff;
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding-top: 20px;
  }
  .search-container {
    text-align: center;
    padding: 15px 0;
  }
  #search {
    width: 90%;
    max-width: 500px;
    padding: 10px 15px;
    border: 1px solid #fff;
    border-radius: 0;
    background-color: #000;
    color: #fff;
    font-size: 16px;
  }
  #tv_catalog {
    max-width: 700px;
    margin: 0 auto;
    padding: 0 10px;
  }
  .list-item-link {
    display: block; /* Changed from flex */
    padding: 12px 15px; /* Adjusted padding */
    text-decoration: none;
    color: #fff;
    border-bottom: 1px solid #333;
    transition: background-color 0.2s ease;
  }
  .list-item-link:hover {
    background-color: #222;
  }
  .list-item-title {
    font-size: 16px;
    font-weight: 400;
  }
  #loading {
    padding: 20px;
    text-align: center;
    font-size: 16px;
  }
  footer {
    text-align: center;
    padding: 30px 0;
    font-size: 12px;
    color: #888;
  }
</style>
</head>
<body>

  <div class="search-container">
    <input id="search" type="search" placeholder="Search Channels..."/>
  </div>

  <div id="loading">Loading Channels...</div>
  <div id="tv_catalog"></div>

  <footer>
    <p>Powered by Siam3310</p>
  </footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
$(document).ready(function(){
    load_tv_list();
    $("input#search").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#tv_catalog .list-item-link").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
});

function load_tv_list(){
    $.ajax({
        url: "api.php",
        type: "post",
        data: "action=getChannels",
        dataType: "json",
        success: function(response){
            if(response.status == "success") {
                let utml = '';
                $.each(response.data.list, function(k, v) {
                    utml += '<a class="list-item-link" href="live.php?id=' + v.id + '" title="' + v.title + '">';
                    utml += '<span class="list-item-title">' + v.title + '</span>';
                    utml += '</a>';
                });
                $("#tv_catalog").html(utml);
                $("#loading").hide();
            } else {
                $("#loading").text(response.message);
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            $("#loading").text("Failed to load channels. Please try again later.");
        }
    });
}
</script>

</body>
</html>

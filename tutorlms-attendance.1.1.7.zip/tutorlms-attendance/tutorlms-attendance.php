<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wooninjas.com/
 * @since             1.0.0
 * @package           Tutor_Lms_Attendance
 *
 * @wordpress-plugin
 * Plugin Name:       TutorLMS Attendance
 * Plugin URI:        https://wooninjas.com/downloads/tutorlms-attendance/
 * Description:       Allow Tutor LMS users to mark attendance for enrolled courses, lessons
 * Version:           1.1.7
 * Author:            WooNinjas
 * Author URI:        https://wooninjas.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       tutor-lms-attendance
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define('TUTOR_LMS_ATTENDANCE_VERSION', '1.1.7');

/**
 * Set plugin FILE to access it globally
 */
define('TUTOR_LMS_ATTENDANCE_FILE', __FILE__);
define('TUTOR_LMS_ATTENDANCE_URL', plugin_dir_url(__FILE__));
define('TUTOR_LMS_ATTENDANCE_PATH', plugin_dir_path(__FILE__));
define('TUTOR_LMS_ATTENDANCE_PLUGIN_NAME', 'TutorLMS Attendance');

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-tutor-lms-attendance-activator.php
 */
function activate_tutor_lms_attendance()
{
	require_once plugin_dir_path(__FILE__) . 'includes/class-tutor-lms-attendance-activator.php';
	Tutor_Lms_Attendance_Activator::activate();
}
/**
 * Load tutor text domain for translation
 */
add_action(
	'init',
	function () {
		load_plugin_textdomain('tutor-lms-attendance', false, basename(dirname(__FILE__)) . '/languages');
	}
);

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-tutor-lms-attendance-deactivator.php
 */
function deactivate_tutor_lms_attendance()
{
	require_once plugin_dir_path(__FILE__) . 'includes/class-tutor-lms-attendance-deactivator.php';
	Tutor_Lms_Attendance_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_tutor_lms_attendance');
register_deactivation_hook(__FILE__, 'deactivate_tutor_lms_attendance');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path(__FILE__) . 'includes/class-tutor-lms-attendance.php';

if (!class_exists('LDAT_LOG_List_Table')) {
	require plugin_dir_path(__FILE__) . 'includes/class-tutor-lms-attendance-report-table.php';
}
if (file_exists(plugin_dir_path(__FILE__) . 'includes/helper.php')) {
	require_once plugin_dir_path(__FILE__) . 'includes/helper.php';
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_tutor_lms_attendance()
{

	$plugin = new Tutor_Lms_Attendance();
	$plugin->run();
	
}

function custom_interface_for_tlms_attendance_notice()
{
	unset($_GET['activate']);  //unset this to hide default Plugin activated. notice

	$plugin_data = get_plugin_data(__FILE__);

	$class   = 'notice notice-error is-dismissible';
	$message = sprintf(__('%s requires <a href="https://www.themeum.com/product/tutor-lms/">Tutor LMS</a> plugin to be activated.', 'tutor-lms-attendance'), $plugin_data['Name']);
	printf("<div id='message' class='%s'> <p>%s</p></div>", $class, $message);
}

function custom_interface_for_tlms_attendance_loaded_cb()
{

	if (current_user_can('activate_plugins') && !class_exists('\TUTOR\Utils')) {

		if (!function_exists('is_plugin_active_for_network')) {
			include_once(ABSPATH . '/wp-admin/includes/plugin.php');
		}

		deactivate_plugins(plugin_basename(__FILE__), true);

		add_action("admin_notices", 'custom_interface_for_tlms_attendance_notice');
	} else {
		run_tutor_lms_attendance();
	}
}

add_action('plugins_loaded', 'custom_interface_for_tlms_attendance_loaded_cb');

function tla_login_cron_job( $user_login, $user ) {

	global $wpdb;

	$user_id = $user->data->ID;
	
	$time_format = $get_option['tlms_show_universal_time'] == 'on' ? current_time('timestamp') : time();

	$timestamp = $time_format + 12 * HOUR_IN_SECONDS;

	$table_name = $wpdb->prefix . 'tlms_timetrack_logs';

	$sql = $wpdb->prepare(
	    "SELECT * FROM $table_name WHERE user_id = %d ORDER BY id DESC LIMIT 1",
	    $user_id
	);

	$last_entry = $wpdb->get_row( $sql );
	$timelog_id_inc = $last_entry->id + 1;

    if ( !wp_next_scheduled( 'tla_user_login', array( $user_id ) ) ) {
    	update_option( 'tla_timetrack_id_'.$user_id, $timelog_id_inc );
        wp_schedule_single_event( $timestamp, 'tla_user_login', array( $user_id ) );

    }else{

    	wp_clear_scheduled_hook( 'tla_user_login', array( $user_id ) );

		update_option( 'tla_timetrack_id_'.$user_id, $timelog_id_inc );

		wp_schedule_single_event( $timestamp, 'tla_user_login', array( $user_id ) );

		if( !isset( $last_entry->logout_time ) ){

        $update_sql = $wpdb->prepare(
            "UPDATE $table_name SET logout_time = NOW() WHERE id = %d",
            $last_entry->id
        );

        $wpdb->query( $update_sql );

		}
	}

}
add_action( 'wp_login', 'tla_login_cron_job', 10, 2 );

function tla_handle_user_login_cron_job( $user_id ) {

		global $wpdb;

	    if ( !session_id() ) session_start();

	    $_SESSION['my_variable'] = '';

		$table_name = $wpdb->prefix . 'tlms_timetrack_logs';

		if( !isset( $last_entry->logout_time ) ){

			$timetrack_id = get_option( 'tla_timetrack_id_'.$user_id );

	        $update_sql = $wpdb->prepare(
	            "UPDATE $table_name SET logout_time = NOW() WHERE id = %d",
	            $timetrack_id
	        );

	        $wpdb->query( $update_sql );
		}

}

add_action( 'tla_user_login', 'tla_handle_user_login_cron_job' );

function tlms_clear_login_cron_job( $user_id ) {
	session_start();
	session_unset();
	session_destroy();
    wp_clear_scheduled_hook( 'tla_user_login', array( strval( $user_id ) ) );

}

add_action( 'wp_logout', 'tlms_clear_login_cron_job' );

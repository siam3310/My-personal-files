(function ($) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	$(document).ready(function () {

		var mouseX = 0;
		var mouseY = 0;
		var current_user_id = tlms_ajax_url.sessionValue;
		document.addEventListener("mousemove", function(e) {
		    mouseX = e.clientX;
		    mouseY = e.clientY;
		    // document.getElementById("coordinates").innerHTML = "<br />X: " + e.clientX + "px<br />Y: " + e.clientY + "px";
		});

		var ajaxRequestSent = false;
		var tracking_option = tlms_ajax_url.user_tr_option;
		if(tracking_option=='on'){
			jQuery(document).mousemove(function (event) {

			    var mouseY = event.pageY;
			    var mouseX = event.pageX;
			    var roles = tlms_ajax_url.user_role;
			    var hasSubscriber = roles.includes('subscriber');
			    var hasCustomer = roles.includes('customer');
			    var value = tlms_ajax_url.sessionValue;

			    if (!ajaxRequestSent && value !== 'true' && mouseY < 130 && mouseX > $(window).width() - 200 && (hasSubscriber || hasCustomer)) {
			        ajaxRequestSent = true;
			        $.post(tlms_ajax_url.ajax_url, { action: 'update_session', value: true }, function(response) {
			            if (response.success) {
			                console.log(response.success);
			                if (value !== 'true'){
			                    value = true;
			                    $('#logout-popup').show();
			                }
			            } else {
			                alert('Error: ' + response.data);
			            }
			        });
			    }
			});


		    $('.close-btn').click(function() {
		        $('#logout-popup').hide();
		    });

		    $('.cancel-btn').click(function() {
		        $('#logout-popup').hide();
		    });

		    $(window).click(function(event) {
		        if ($(event.target).is('#logout-popup')) {
		            $('#logout-popup').hide();
		        }
		    });
		}

		$(".chosen-select").chosen({
			no_results_text: "Oops, nothing found!"
		})
		$(".search-choice-close").text("X");
		$('#tlms-mark-attendance-user').submit(function (e) {
			e.preventDefault();
			var attendance_button = $('#tlms-mark-attendance-user button');

			attendance_button.attr('disabled', true);

			const formData = new FormData(this);
			$.ajax({
				url: tlms_ajax_url.ajax_url,
				type: 'POST',
				data: formData,
				contentType: false, // prevent jQuery from using an incorrect Content-type header
				processData: false,
				success: function (response) {
					if (response['status'] == 'error') {
						alert(response['message']);
						attendance_button.attr('disabled', false);

					} else {
						attendance_button.hide();
						console.log(response);
					}
				}
			})
		})

		$('#tlmsat-mark-attendance-form').submit(function (e) {
			e.preventDefault();
			$('#tlms_at_failed').hide();
			$('#tlms_at_success').hide();

			const formData = new FormData(this);
			$.ajax({
				url: tlms_ajax_url.ajax_url,
				type: 'POST',
				data: formData,
				contentType: false, // prevent jQuery from using an incorrect Content-type header
				processData: false,
				success: function (response) {
					$('#tlmsat-mark-attendance-form').trigger("reset");
					$('#tlmsat_mark_attendance_users').val('').trigger('chosen:updated');
					$('.chosen-choices')
					if (response['status'] == 'error') {
						$('#tlms_at_failed').text(response['message']);
						$('#tlms-at_front_msg-box').show();
						$('#tlms_at_failed').show();
					}
					if (response['status'] == 'success') {
						$('#tlms-at_front_msg-box').show();
						$('#tlms_at_success').show();
					}
				}
			})
		})


	})


})(jQuery);

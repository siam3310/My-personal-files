<?php
// Get the channel ID from the URL
$id = "";
if(isset($_REQUEST['id'])){
    $id = trim(strip_tags($_REQUEST['id']));
}

if(empty($id)) {
    http_response_code(404);
    exit("Channel ID is missing.");
}

// The stream will be served by our proxy script
$streamURL = "stream.php?id=" . $id;

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Minimal Player</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/shaka-player/4.8.5/controls.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/shaka-player/4.8.5/shaka-player.ui.min.js"></script>

<style>
html, body {
  margin:0;
  height:100%;
  background:#000000;
  overflow: hidden;
}
#video-container {
  width:100%;
  height:100%;
}
video {
  width:100%;
  height:100%;
  object-fit:contain;
}
.overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: transparent; /* Show Shaka spinner underneath */
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
    z-index: 9999;
    font-family: sans-serif;
    color: #fff;
}
#countdown {
    font-size: 72px;
}
#error-message {
    font-size: 24px;
    padding: 20px;
}
.shaka-controls-button-panel button {
  font-size: 50px !important;
  padding: 0 12px !important;
}
.shaka-controls-button-panel {
  height: 70px !important;
}
.shaka-seek-bar-container, .shaka-play-button-container {
  display: none !important;
}
</style>
</head>

<body>

<div id="loading-overlay" class="overlay">
    <span id="countdown"></span>
</div>

<div id="error-overlay" class="overlay" style="display: none;">
    <span id="error-message">This stream could not be played.</span>
</div>

<div id="video-container" data-shaka-player-container>
  <video id="video" autoplay muted playsinline data-shaka-player></video>
</div>

<script>
const streamUrl = "<?php echo $streamURL; ?>";
const loadingOverlay = document.getElementById('loading-overlay');
const countdown = document.getElementById('countdown');
const errorOverlay = document.getElementById('error-overlay');
let countdownInterval;

function startCountdown() {
    let count = 1;
    countdown.innerText = count;
    countdownInterval = setInterval(() => {
        count++;
        countdown.innerText = count;
    }, 1000);
}

function handleError(error) {
    console.error("Player Error:", error);
    loadingOverlay.style.display = 'none';
    clearInterval(countdownInterval);
    errorOverlay.style.display = 'flex';
}

startCountdown();
document.addEventListener("shaka-ui-loaded", init);

async function init() {
  shaka.polyfill.installAll();

  const video = document.getElementById("video");
  const ui = video['ui'];

  video.addEventListener('playing', () => {
      loadingOverlay.style.display = 'none';
      clearInterval(countdownInterval);
  });

  ui.configure({
    controlPanelElements: ["mute", "spacer", "fullscreen"],
    addSeekBar: false,
    addBigPlayButton: false,
    overflowMenuButtons: []
  });

  const player = ui.getControls().getPlayer();
  
  // Add a listener for all player errors
  player.addEventListener('error', event => handleError(event.detail));

  player.configure({
    streaming: {
      lowLatencyMode: false,
      bufferingGoal: 15,
      rebufferingGoal: 5,
      bufferBehind: 20
    },
    abr: {
      enabled: true,
      defaultBandwidthEstimate: 2500000,
      switchInterval: 5
    }
  });

  try {
    await player.load(streamUrl);
  } catch (error) {
    handleError(error);
  }
}
</script>

</body>
</html>

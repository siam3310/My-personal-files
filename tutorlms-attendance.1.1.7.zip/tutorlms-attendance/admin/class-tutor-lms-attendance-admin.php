<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://wooninjas.com/
 * @since      1.0.0
 *
 * @package    Tutor_Lms_Attendance
 * @subpackage Tutor_Lms_Attendance/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Tutor_Lms_Attendance
 * @subpackage Tutor_Lms_Attendance/admin
 * @author     WooNinjas
 */
class Tutor_Lms_Attendance_Admin
{
	public $page_tab;
	private $plugin_name;
	private $version;
	private $user_id;
	private $user_ip;
	private $device_id;
	private $course_automatic_attendance_type = 'present';
	private $course_automatic_attendance_comment = '';
	private $course_automatic_attendance_on_login_setting;
	private $user_all_enrolled_courses;
	public $attandence_uid;
	private $options;
	private $auto_att_options;
	private array $user_individual_enrolled_courses;
	private array $user_groups_enrolled_courses;


	/**
	 * Initialize the class and set its properties.
	 *
	 * @param string $plugin_name The name of this plugin.
	 * @param string $version The version of this plugin.
	 *
	 * @since    1.0.0
	 */
	public function __construct($plugin_name, $version)
	{
		if (current_user_can('administrator')) {
			$this->page_tab = isset($_GET['tab']) ? $_GET['tab'] : 'general';
		} else {
			$this->page_tab = 'report';
		}
		$this->plugin_name = $plugin_name;
		$this->version     = $version;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Tutor_Lms_Attendance_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Tutor_Lms_Attendance_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_style('date-picker-css', plugin_dir_url(__FILE__) . 'css/daterangepicker.css', array(), $this->version, 'all');
		wp_enqueue_style('data-table-css', plugin_dir_url(__FILE__) . 'css/jquery.dataTables.min.css', array(), $this->version, 'all');
		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/tutor-lms-attendance-admin.css', array(), $this->version, 'all');
		wp_enqueue_style('tlms-atd-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css');
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Tutor_Lms_Attendance_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Tutor_Lms_Attendance_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_script('moment', plugin_dir_url(__FILE__) . 'js/moment.min.js', array('jquery'), $this->version, false);
		wp_enqueue_script('date-picker-js', plugin_dir_url(__FILE__) . 'js/daterangepicker.js', array('jquery'), $this->version, false);
		wp_enqueue_script('data-table-js', plugin_dir_url(__FILE__) . 'js/jquery.dataTables.min.js', array('jquery'), $this->version, false);

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/tutor-lms-attendance-admin.js', array(
			'jquery',
			'date-picker-js',
			'moment'
		), $this->version, false);
		add_thickbox();
	}

	/**
	 * Clear Attendance Logs functionality 
	 *
	 * @return void
	 */
	public function tlms_clear_attendance_logs(){
		$result = array();
		global $wpdb;
		$tablename = $wpdb->prefix . 'tlms_attendance_logs';

		$delete = $wpdb->query("TRUNCATE TABLE $tablename");
		$result['message'] = __('Attendance Logs Cleared', 'tutor-lms-attendance');
		$result['error'] = false;
		return wp_send_json($result);
	}

	/**
	 * Export Attendance functionality 
	 *
	 * @return void
	 */
	public function tlms_at_export_btn()
	{
		// error_log('role:' . var_export('role', true));
		$table_head = array(
			'Course id',
			'Lesson id',
			'Topic id',
			'Quiz id',
			'User id',
			'IP Address',
			'Device id',
			'Log by User id',
			'Attendance Type',
			'Comment',
			'Create at',
			'Modiied at',
		);
		$table_body = [];

		global $wpdb;
		$attendances = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}tlms_attendance_logs ", OBJECT);
		if (is_array($attendances) && count($attendances) != 0) {
			foreach ($attendances as $attendance) {
				error_log('attendances:' . var_export($attendance, true));

				$data_array = array(

					$attendance->course_id,
					$attendance->lesson_id,
					$attendance->topic_id,
					$attendance->quiz_id,
					$attendance->user_id,
					$attendance->ip_address,
					$attendance->device_id,
					$attendance->log_by_user_id,
					$attendance->attendance_type,
					$attendance->comment,
					$attendance->created_at,
					$attendance->modified_at,

				);
				array_push($table_body, $data_array);
			}

			$filename = "attendance.csv";
			header('Content-Type: text/csv'); // te"lls browser to download
			header('Content-Disposition: attachment; filename="' . $filename . '"');
			$fh = fopen('php://output', 'w');
			if (!empty($table_body)) {
				fputcsv($fh, array_values($table_head));
				foreach ($table_body as $body) {
					fputcsv($fh, array_values($body));
				}
				// error_log('get_feedback:' . var_export($a, true));
				fclose($fh);
			}

			exit;
		} else {
			wp_send_json(['errormsg'=>__('Sorry, you have not any attendance', 'tutor-lms-attendance')]);
		}
	}

	/**
	 * import attendance functionality
	 *
	 * @return void
	 */
	public function tlms_at_upload_file_form_action()
	{
		global $wpdb;
		// ini_set( 'display_errors', 'On' );
		// error_reporting(E_ALL);
		if (!wp_doing_ajax()) {
			return;
		}
		if (!check_ajax_referer('tlms-at-ajax-nonce', 'tlms_at_ajax_nonce')) {
			return;
		}

		$response = array(
			'status'  => 'error',
			'message' => __('An unknown error occurred while importing file.', 'cs_ld_addon')
		);
		if (wp_doing_ajax() && !empty($_POST) && !empty($_FILES) && is_user_logged_in()) {
			if ($_FILES["ldcms_import_file"]["tmp_name"] == '') {
				wp_send_json('Please upload file before import');
			}
			$allowed =  array('csv');
			$filenamess = $_FILES['ldcms_import_file']['name']; // csv_file is the file name on the form
			$ext = pathinfo($filenamess, PATHINFO_EXTENSION);
			if (in_array($ext, $allowed)) {
				$filename = $_FILES["ldcms_import_file"]["tmp_name"];
				if ($_FILES["ldcms_import_file"]["size"] > 0) {
					$file = fopen($filename, "r");
					$check = true;
					$table_header = [];
					$attendance_date = [];
					while (($getData = fgetcsv($file, 10000, ",")) !== FALSE) {
						if ($check) {
							array_push($table_header, $getData);
							$check = false;
						} else {
							array_push($attendance_date, $getData);
						}
					}
					global $wpdb;
					if (is_array($attendance_date)) {
						foreach ($attendance_date as $data) {
							global $wpdb;
							$tablename = $wpdb->prefix . 'tlms_attendance_logs';

							$aa = $wpdb->insert(
								$tablename,
								array(
									'course_id' => $data[0],
									'lesson_id' => $data[1],
									'topic_id' => $data[2],
									'quiz_id' => $data[3],
									'user_id' => $data[4],
									'ip_address' => $data[5],
									'device_id' => $data[6],
									'log_by_user_id' => $data[7],
									'attendance_type' => $data[8],
									'comment' => $data[9],
									'created_at' => $data[10],
									'modified_at' => $data[11],
								),
							);
						}
					}
					fclose($file);

					wp_send_json(__('The file has been import successfully', 'tutor-lms-attendance'));
				}
			} else {

				wp_send_json('Please upload CSV file only');
			}
		}
	}

	/**
	 * Create submenu page for Attendance.
	 *
	 * @since    1.0.0
	 */

	public function tlms_menu_page_fnc()
	{
		$options        = get_option('tlms_at_options', array());
		$selected_roles = isset($options['tlms_at_attendance_allow_user_roles']) ? $options['tlms_at_attendance_allow_user_roles'] : array();
		$user           = wp_get_current_user();
		$roles          = $user->roles;
		$current_role   = array_intersect($selected_roles, $roles) ? $roles[0] : 'manage_options';
		add_submenu_page(
			'tutor',
			__('Attendance', 'tutor-lms-attendance'),
			__('Attendance', 'tutor-lms-attendance'),
			$current_role,
			'tlms-attendance',
			array($this, 'tlms_attendance_page_call')
		);
	}

	public function tlms_attendance_page_call()
	{
?>
		<div id="wrap" class="tlms-settings-wrapper">
			<div id="icon-options-general" class="icon32"></div>
			<h1 class="tlms-ad-title"><?php echo __('Tutor LMS Attendance Settings', 'tutor-lms-attendance'); ?></h1>

			<div class="tlms-att-nav-tab">
				<?php
				$tlms_settings_sections = $this->tlms_get_setting_sections();
				foreach ($tlms_settings_sections as $key => $tlms_settings_section) {
				?>
					<a href="?page=tlms-attendance&tab=<?php echo $key; ?>" class="nav-tab <?php echo $this->page_tab == $key ? 'nav-tab-active' : ''; ?>">
						<i class="dashicons dashicons-<?php echo $tlms_settings_section['icon']; ?>" aria-hidden="true"></i>
						<?php _e($tlms_settings_section['title'], 'tutor-lms-attendance'); ?>
					</a>
				<?php
				}
				?>
			</div>

			<?php
			foreach ($tlms_settings_sections as $key => $tlms_settings_section) {
				if ($this->page_tab == $key) {
					include 'templates/' . $key . '.php';
				}
			}
			?>
		</div>
		<?php
	}

	public function tlms_get_setting_sections()
	{

		$options = get_option('tlms_at_options', array());

		if (current_user_can('administrator')) {

			$tlms_settings_sections = array(
				'general'         => array(
					'title' => __('General Option', 'tutor-lms-attendance'),
					'icon'  => 'admin-settings',
				),
				'report'          => array(
					'title' => __('Attendance Logs', 'tutor-lms-attendance'),
					'icon'  => 'list-view',
				),
				'mark_attendance' => array(
					'title' => __('Mark Attendance', 'tutor-lms-attendance'),
					'icon'  => 'calendar-alt',
				),
				'users_tracking_time'          => array(
					'title' => __('Users Tracking Time', 'tutor-lms-attendance'),
					'icon'  => 'list-view',
				),
				'import'          => array(
					'title' => __('Import/Export', 'tutor-lms-attendance'),
					'icon'  => 'list-view',
				),
				'license'         => array(
					'title' => __('License Option', 'tutor-lms-attendance'),
					'icon'  => 'update',
				),
			);
			// Check if activity log is enabled and add relevant sections.
			if (isset($options['tutor_lms_att_activity_log']) && 'on' == $options['tutor_lms_att_activity_log']) {
				$tlms_at_activity_logs_sections = array(
					'activity_log' => array(
						'title' => __('Activity Logs', 'tutor-lms-attendance'),
						'icon'  => 'backup',
					),
				);
				// Merge activity log sections with the existing sections.
				$tlms_settings_sections = array_merge($tlms_settings_sections, $tlms_at_activity_logs_sections);
			}
			// Check if debug log is enabled and add relevant sections.
			if (isset($options['tutor_lms_att_debug_log']) && 'on' == $options['tutor_lms_att_debug_log']) {
				$tlms_at_debug_logs_sections = array(
					'debug_log' => array(
						'title' => __('Debug Logs', 'tutor-lms-attendance'),
						'icon'  => 'backup',
					)
				);
				// Merge debug log sections with the existing sections.
				$tlms_settings_sections = array_merge($tlms_settings_sections, $tlms_at_debug_logs_sections);
			}
		} else {
			$tlms_settings_sections = array(

				'report' => array(
					'title' => __('Attendance Logs', 'tutor-lms-attendance'),
					'icon'  => 'list-view',
				)
			);
		}

		$config_file = ABSPATH . 'wp-config.php';
		$config_content = file_get_contents($config_file);

		if (isset($options['tutor_lms_att_debug_log']) && $options['tutor_lms_att_debug_log'] == 'on') {
			if (strpos($config_content, "define( 'WP_DEBUG', false );") !== false) {
				$config_content = str_replace("define( 'WP_DEBUG', false );", "define( 'WP_DEBUG', true );\ndefine('WP_DEBUG_LOG', true );\ndefine('WP_DEBUG_DISPLAY', false );", $config_content);
				file_put_contents($config_file, $config_content);
			}
		} elseif (strpos($config_content, "define( 'WP_DEBUG', true );\ndefine('WP_DEBUG_LOG', true );\ndefine('WP_DEBUG_DISPLAY', false );") !== false) {
			$config_content = str_replace(
				"define( 'WP_DEBUG', true );\ndefine('WP_DEBUG_LOG', true );\ndefine('WP_DEBUG_DISPLAY', false );",
				"define( 'WP_DEBUG', false );",
				$config_content
			);
			file_put_contents($config_file, $config_content);
		}

		return apply_filters('tlms_settings_sections', $tlms_settings_sections);
	}

	public function tlms_at_admin_settings_save_settings()
	{
		if (isset($_POST['tlms_at_settings_submit'])) {

			$tlms_at_options = array();

			$global_settings = isset($_POST['tlms_at_restrict_ip']) ? $_POST['tlms_at_restrict_ip'] : 'no';
			$tlms_at_user_track = isset($_POST['tlms_at_user_track']) ? $_POST['tlms_at_user_track'] : 'no';
			$tlms_at_user_celendar = isset($_POST['tlms_at_user_celendar']) ? $_POST['tlms_at_user_celendar'] : 'no';
			$manual_settings = isset($_POST['tlms_at_manual_attendance']) ? $_POST['tlms_at_manual_attendance'] : 'no';
			$show_universal_time = isset($_POST['tlms_show_universal_time']) ? $_POST['tlms_show_universal_time'] : 'no';
			$delete_settings = isset($_POST['tlms_at_delete_attendance']) ? $_POST['tlms_at_delete_attendance'] : 'no';

			$user_attendance_email_option     = isset($_POST['tlms_at_disable_user_attendance_email_option']) ? $_POST['tlms_at_disable_user_attendance_email_option'] : 'no';
			$attendance_email_report_duration = isset($_POST['tlms_at_attendance_email_report_duration']) ? $_POST['tlms_at_attendance_email_report_duration'] : '';
			$attendance_email_report_count    = isset($_POST['tlms_at_attendance_email_report_count']) ? $_POST['tlms_at_attendance_email_report_count'] : '';

			$disable_user_mark_attendance_temp = isset($_POST['tlms_at_disable_user_mark_attendance_temp']) ? $_POST['tlms_at_disable_user_mark_attendance_temp'] : 0;

			if ($disable_user_mark_attendance_temp == 1) {
				$disable_user_mark_attendance = isset($_POST['tlms_at_disable_user_mark_attendance']) ? $_POST['tlms_at_disable_user_mark_attendance'] : array();
			} else {
				$disable_user_mark_attendance = [];
			}

			$attendance_allow_user_roles_temp = isset($_POST['tlms_at_attendance_allow_user_roles_temp']) ? $_POST['tlms_at_attendance_allow_user_roles_temp'] : 0;
			if ($attendance_allow_user_roles_temp == 1) {
				$attendance_allow_user_roles = isset($_POST['tlms_at_attendance_allow_user_roles']) ? $_POST['tlms_at_attendance_allow_user_roles'] : array();
			} else {
				$attendance_allow_user_roles = [];
			}


			$auto_att_options             = [];
			$auto_attendance_on_login     = 'no';
			$automatic_att_login_settings = isset($_POST['tlms_at_automatic_attendance_on_login']) ? $_POST['tlms_at_automatic_attendance_on_login'] : 'no';
			if ($automatic_att_login_settings == 'on' && isset($_POST['login_auto_att'])) {
				$auto_att_options         = $_POST['login_auto_att'];
				$auto_attendance_on_login = 'on';
			}

			$tlms_at_show_absent_of_unmarked_days = isset($_POST['tlms_at_show_absent_of_unmarked_days']) ? $_POST['tlms_at_show_absent_of_unmarked_days'] : 'no';
			$tlms_at_activity_log = isset($_POST['tutor_lms_att_activity_log']) ? $_POST['tutor_lms_att_activity_log'] : 'no';
			$tlms_at_debug_log = isset($_POST['tutor_lms_att_debug_log']) ? $_POST['tutor_lms_att_debug_log'] : 'no';
			$minimum_att_text = isset($_POST['tutor_lms_att_minimum_attendance']) ? $_POST['tutor_lms_att_minimum_attendance'] : 'Your attendance falls below the minimum requirement. To complete this course, kindly ensure you have fulfilled the attendance criteria.';

			$tlms_at_options['tlms_at_restrict_ip']                          = sanitize_text_field($global_settings);
			$tlms_at_options['tlms_at_user_track']        					 = sanitize_text_field($tlms_at_user_track);
			$tlms_at_options['tlms_at_user_celendar']        				 = sanitize_text_field($tlms_at_user_celendar);
			$tlms_at_options['tlms_at_manual_attendance']                    = sanitize_text_field($manual_settings);
			$tlms_at_options['tlms_show_universal_time']                     = sanitize_text_field($show_universal_time);
			$tlms_at_options['tlms_at_delete_attendance']                    = sanitize_text_field($delete_settings);
			$tlms_at_options['tlms_at_disable_user_attendance_email_option'] = sanitize_text_field($user_attendance_email_option);
			$tlms_at_options['tlms_at_attendance_email_report_duration']     = sanitize_text_field($attendance_email_report_duration);
			$tlms_at_options['tlms_at_attendance_email_report_count']        = sanitize_text_field($attendance_email_report_count);
			$tlms_at_options['disable_user_mark_attendance']                 = array_map('sanitize_text_field', $disable_user_mark_attendance);
			$tlms_at_options['tlms_at_attendance_allow_user_roles']          = array_map('sanitize_text_field', $attendance_allow_user_roles);
			$tlms_at_options['tlms_at_automatic_attendance_on_login']        = sanitize_text_field($auto_attendance_on_login);
			$tlms_at_options['tlms_auto_attendance_options']                 = array_map('sanitize_text_field', $auto_att_options);
			$tlms_at_options['tlms_at_show_absent_of_unmarked_days']         = sanitize_text_field($tlms_at_show_absent_of_unmarked_days);
			$tlms_at_options['tutor_lms_att_activity_log'] 					 = sanitize_text_field($tlms_at_activity_log);
			$tlms_at_options['tutor_lms_att_debug_log'] 					 = sanitize_text_field($tlms_at_debug_log);
			$tlms_at_options['tutor_lms_att_minimum_attendance'] 			 = sanitize_text_field($minimum_att_text);

			update_option('tlms_at_options', $tlms_at_options);

			(new Tutor_Lms_DEBUG())->log_message('Saving TutorLMS Attendance settings...', 'tutor-lms-attendance');

			$url = admin_url('admin.php');
			$url = add_query_arg('page', 'tlms-attendance', $url);
			$url = add_query_arg('tab', 'general', $url);
			$url = add_query_arg('settings_updated', 1, $url);
			wp_safe_redirect($url);
			exit;
		}
	}

	function tlms_at_admin_footer_scripts()
	{
		$is_settings_report_page          = (isset($_GET['page']) && isset($_GET['tab']) && $_GET['page'] == 'tlms-attendance' && $_GET['tab'] == 'report');
		$is_settings_mark_attendance_page = (isset($_GET['page']) && isset($_GET['tab']) && $_GET['page'] == 'tlms-attendance' && $_GET['tab'] == 'mark_attendance');
		if ($is_settings_report_page || $is_settings_mark_attendance_page) {
		?>
			<script>
				(function($) {
					LDA_Admin_Settings.initDateRangePicker();
				})(jQuery);
			</script>
		<?php
		}
	}

	function tlms_at_admin_mark_attendance()
	{
		$is_mark_attendance_post = filter_input(INPUT_POST, 'tlms_at_mark_attendance_submit');
		if (!empty($is_mark_attendance_post)) {
			$selected_users   = isset($_POST['tlms_at_user_id_field']) ? $_POST['tlms_at_user_id_field'] : array();
			$selected_courses = isset($_POST['tlms_at_course_id_field']) ? $_POST['tlms_at_course_id_field'] : array();
			$selected_lessons = isset($_POST['tlms_at_lesson_id_field']) ? $_POST['tlms_at_lesson_id_field'] : array();
			$date_start       = isset($_POST['tlms_at_date_start']) ? $_POST['tlms_at_date_start'] : null;
			$date_end         = isset($_POST['tlms_at_date_end']) ? $_POST['tlms_at_date_end'] : null;
			$selected_users   = $this->parse_selector_data($selected_users);
			$selected_courses = $this->parse_selector_data($selected_courses);
			$selected_lessons = $this->parse_selector_data($selected_lessons);
			$remarks          = isset($_POST['tlms_at_mark_attendance_comment']) ? $_POST['tlms_at_mark_attendance_comment'] : '';
			$remarks          = str_replace('\"', "'", $remarks);

			$attendance_type = isset($_POST['tlms_at_mark_attendance_type']) ? $_POST['tlms_at_mark_attendance_type'] : 'absent';

			(new Tutor_Lms_DEBUG())->log_message('Marking attendance from admin panel..', 'tutor-lms-attendance');


			if (empty($selected_users)) {
				add_action(
					'admin_notices',
					function () {
						$class   = 'notice notice-error is-dismissible';
						$message = __('Please select users', 'tutor-lms-attendance');
						printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), esc_html($message));
					}
				);

				return;
			} elseif (empty($date_start) || empty($date_end)) {
				add_action(
					'admin_notices',
					function () {
						$class   = 'notice notice-error is-dismissible';
						$message = __('Please select valid dates', 'tutor-lms-attendance');
						printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), esc_html($message));
					}
				);

				return;
			}

			foreach ($selected_users as $user_id) {
				$enrolled_courses = tutor_utils()->get_enrolled_courses_ids_by_user($user_id);


				foreach ($enrolled_courses as $course_id) {
					// Mark attendance for courses that are selected by admin/group-leader
					if (in_array($course_id, (array) $selected_courses)) {
						$this->mark_attendance_bulk($course_id, $user_id, $attendance_type, $remarks, array(
							$date_start,
							$date_end
						));
					}

					$topics = tutor_utils()->get_topics($course_id);
					$topics = tutor_utils()->get_topics($course_id);
					foreach ($topics->posts as $topic) {
						$topic_id            = $topic->ID;
						$enrolled_lessons    = tutor_utils()->get_course_contents_by_topic($topic_id, -1);
						$enrolled_lesson_ids = array();

						foreach ($enrolled_lessons->posts as $enrolled_lesson) {
							$enrolled_lesson_ids[] = $enrolled_lesson->ID;
						}


						// Mark attendance for lessons that are selected by admin/group-leader
						foreach ($enrolled_lesson_ids as $lesson_id) {
							foreach ($enrolled_lesson_ids as $lesson_id) {
								if (in_array($lesson_id, (array) $selected_lessons)) {
									if (tutor_utils()->has_enrolled_content_access('lesson', $lesson_id, $user_id)) {
										$this->mark_attendance($lesson_id, $user_id, $attendance_type, $remarks, $date_start, 'lesson');
									}
								}
							}

							foreach ($enrolled_lessons->posts as $enrolled_lesson) {
								$lesson_id = $enrolled_lesson->ID;

								if (
									in_array($lesson_id, (array) $selected_lessons) &&
									tutor_utils()->has_enrolled_content_access('lesson', $lesson_id, $user_id)
								) {
									$this->mark_attendance($lesson_id, $user_id, $attendance_type, $remarks, $date_start, 'lesson');
								}
							}
						}


						foreach ($topics->posts as $topic) {
							$cours_topic_ids[] = $topic->ID;
						}

						foreach ($cours_topic_ids as $topic_id) {
							$enrolled_lessons    = tutor_utils()->get_course_contents_by_topic($topic_id, -1);
							$enrolled_lesson_ids = array_map(function ($enrolled_lesson) {
								return $enrolled_lesson->ID;
							}, $enrolled_lessons->posts);

							// Mark attendance for lessons that are selected by admin/group-leader
							foreach ($enrolled_lesson_ids as $lesson_id) {
								if (in_array($lesson_id, (array) $selected_lessons) && tutor_utils()->has_enrolled_content_access('lesson', $lesson_id, $user_id)) {
									$this->mark_attendance($lesson_id, $user_id, $attendance_type, $remarks, $date_start, 'lesson');
								}
							}
						}
					}
				}
			}

			add_action(
				'admin_notices',
				function () {
					unset($_POST);
					$class   = 'notice notice-success is-dismissible';
					$message = __('Attendance marked successfully', 'tutor-lms-attendance');
					printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), esc_html($message));
				}
			);

			// die();
		}
	}

	function parse_selector_data($data)
	{

		if (!empty($data)) {
			$data = (array) json_decode(stripslashes($data[0]));
		}

		return $data;
	}

	/**
	 *
	 * Mark attendance on the bases of given arguements
	 *
	 * @param $resource_id
	 * @param $user_id
	 * @param $attendance_type
	 * @param $comment
	 * @param $attendance_date
	 * @param $resource_type
	 *
	 * @return int
	 */
	public function mark_attendance($resource_id, $user_id, $attendance_type = 'present', $comment = '', $attendance_date = null, $resource_type = 'course')
	{
		global $wpdb;

		$table_attendance_logs = $wpdb->prefix . 'tlms_attendance_logs';

		$ip_address = $this->get_client_ip();
		$device_id  = wp_is_mobile() ? $_SERVER['HTTP_USER_AGENT'] : 'desktop';

		$date_from = current_time('mysql');
		$date_to   = current_time('mysql');
		$date      = current_time('mysql');

		if (!empty($attendance_date)) {
			$datetime  = new DateTime($attendance_date, wp_timezone());
			$date      = $datetime->format('Y-m-d H:i:s');
			$date_from = $date;
			$date_to   = $date;
		}

		switch ($resource_type) {
			case 'lesson':
				$resource_field = 'lesson_id';
				break;
			default:
				$resource_field = 'course_id';
				break;
		}

		$attendance_exists = $this->check_user_attendance($user_id, $resource_field, $resource_id, $date_from, $date_to);

		if (empty($attendance_exists)) {

			if (isset($resource_type) && !empty($resource_type) && $resource_type != 'course') {
				if ($resource_type == 'lesson') {
					$resource_array = array('lesson_id' => $resource_id);
				}
				if ($resource_type == 'topic') {
					$resource_array = array('topic_id' => $resource_id);
				}

				$data = array(
					'user_id'         => $user_id,
					'ip_address'      => $ip_address,
					'device_id'       => $device_id,
					'log_by_user_id'  => get_current_user_id(),
					'attendance_type' => $attendance_type,
					'comment'         => $comment,
					'created_at'      => $date
				);

				$data = array_merge($resource_array, $data);
			} else {
				$data = array(
					'course_id'       => $resource_id,
					'user_id'         => $user_id,
					'ip_address'      => $ip_address,
					'device_id'       => $device_id,
					'log_by_user_id'  => get_current_user_id(),
					'attendance_type' => $attendance_type,
					'comment'         => $comment,
					'created_at'      => $date
				);
			}

			$format = array(
				'%d',
				'%d',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
				'%s'
			);

			$wpdb->insert($table_attendance_logs, $data, $format);
			$id = $wpdb->insert_id;
		} else {
			$id                      = $attendance_exists[0]['id'];
			$current_attendance_type = $attendance_exists[0]['attendance_type'];

			$data = array(
				'log_by_user_id'  => get_current_user_id(),
				'attendance_type' => $attendance_type,
				'comment'         => $comment,
			);

			$where = array(
				'id' => $id,
			);

			$format = array(
				'%d',
				'%s',
				'%s'
			);

			$wpdb->update($table_attendance_logs, $data, $where, $format);
		}

		$attendance_count = tlms_attendance_get(array(
			'course_ids' => array($course_id ?? null),
			'user_ids'   => $user_id,
			'no_group'   => true,
		));

		$count      = count($attendance_count);
		$percentage = tlms_attendance_get_percentage($count);

		do_action('learndash_mark_attendance', $user_id, ($course_id ?? null), $percentage, $count);

		return $id;
	}

	/**
	 *
	 * Mark bulk attendance on the bases of given arguements
	 *
	 * @param $course_id
	 * @param $user_id
	 * @param $attendance_type
	 * @param $comment
	 * @param $date_range
	 *
	 * @return array
	 */
	public function mark_attendance_bulk($course_id, $user_id, $attendance_type = 'absent', $comment = '', $date_range = array())
	{

		$attendance_log_ids = array();

		if (empty($date_range)) {
			$date_range = array(current_time('mysql'), current_time('mysql'));
		}

		list($start_date, $end_date) = $date_range;
		$end_date_obj = new DateTime($end_date . ' +1 day');
		$end_date     = $end_date_obj->format('Y-m-d H:i:s');

		$period = new DatePeriod(
			new DateTime($start_date),
			new DateInterval('P1D'),
			new DateTime($end_date)
		);

		foreach ($period as $key => $value) {
			$date = $value->format('Y-m-d');

			$attendance_log_ids[] = $this->mark_attendance($course_id, $user_id, $attendance_type, $comment, $date);
		}

		return $attendance_log_ids;
	}

	/**
	 *
	 * Checks user attendance for specific course, lesson and topic
	 *
	 * @param $user_id
	 * @param $resource_type
	 * @param $resource_id
	 *
	 * @return array
	 */
	private function check_user_attendance($user_id, $resource_type = null, $resource_id = null, $date_from = null, $date_to = null)
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'tlms_attendance_logs';

		$result = $wpdb->get_results("SELECT * FROM {$table_name} WHERE 1=1 AND DATE(created_at) >= DATE('{$date_from}') AND DATE(created_at) <= DATE('{$date_to}')  AND (user_id = {$user_id}) AND ({$resource_type} = {$resource_id})", ARRAY_A);

		return $result;
	}

	/**
	 *
	 * Get current active user IP
	 *
	 * @return string
	 */
	private function get_client_ip()
	{
		$ipaddress = '';
		if (isset($_SERVER['HTTP_CLIENT_IP'])) {
			$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} elseif (isset($_SERVER['HTTP_X_FORWARDED'])) {
			$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
		} elseif (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
			$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
		} elseif (isset($_SERVER['HTTP_FORWARDED'])) {
			$ipaddress = $_SERVER['HTTP_FORWARDED'];
		} elseif (isset($_SERVER['REMOTE_ADDR'])) {
			$ipaddress = $_SERVER['REMOTE_ADDR'];
		} else {
			$ipaddress = 'UNKNOWN';
		}

		$comma_ipaddress = explode(',', $ipaddress);

		if (isset($comma_ipaddress[0]) && !empty($comma_ipaddress[0])) {
			return $comma_ipaddress[0];
		}

		return $ipaddress;
	}

	function tlms_at_auto_init()
	{
		$this->options                                      = get_option('tlms_at_options', array());
		$this->user_ip                                      = $this->get_client_ip();
		$this->device_id                                    = wp_is_mobile() ? $_SERVER['HTTP_USER_AGENT'] : 'desktop';
		$this->auto_att_options                             = $this->tlms_auto_attendance_options();
		$this->course_automatic_attendance_on_login_setting = $this->get_automatic_attendance_on_login_setting();
		
	}

	private function get_automatic_attendance_on_login_setting()
	{
		$ldat_options = get_option('tlms_at_options', array());

		return !empty($ldat_options['tlms_at_automatic_attendance_on_login']) ? $ldat_options['tlms_at_automatic_attendance_on_login'] : 'no';
	}

	private function tlms_auto_attendance_options()
	{
		$ldat_options = get_option('tlms_at_options', array());

		return $ldat_options['tlms_auto_attendance_options'] ?? [];
	}

	function tlms_at_auto_login_setup_course_att($user_login, $user)
	{
		$this->user_id = $user->ID;
		$user_roles    = ($user->roles);

		if (sizeof($user_roles) > 0 && (in_array("subscriber", $user_roles) || in_array("administrator", $user_roles))) {

			$this->user_individual_enrolled_courses = tutor_utils()->get_enrolled_courses_ids_by_user($this->user_id);
			$this->user_groups_enrolled_courses     = array();

			// mark courses attendance
			if ( is_array( $this->auto_att_options ) && in_array( 'course', $this->auto_att_options ) ) {
				
				do_action('setup_course_automatic_attendance_on_login');
			}

			// mark lessons attendance
			if ( is_array( $this->auto_att_options ) && in_array( 'lesson', $this->auto_att_options ) ) {
				foreach ($this->user_individual_enrolled_courses as $course_id) {
					foreach ($this->user_individual_enrolled_courses as $course_id) {
						$topics = tutor_utils()->get_topics($course_id);
						$topics = tutor_utils()->get_topics($course_id);
						foreach ($topics->posts as $topic) {
							$topic_id         = $topic->ID;
							$enrolled_lessons = tutor_utils()->get_course_contents_by_topic($topic_id, -1);
							$enrolled_lessons = tutor_utils()->get_course_contents_by_topic($topic_id, -1);

							foreach ($enrolled_lessons->posts as $enrolled_lesson) {
								if ($enrolled_lesson->post_type != 'lesson') {
									continue;
								}

								$lesson_id         = $enrolled_lesson->ID;
								$date_from         = current_time('mysql');
								$date_to           = current_time('mysql');
								$attendance_exists = $this->check_user_attendance($this->user_id, 'lesson_id', $lesson_id, $date_from, $date_to);
								if (empty($attendance_exists)) {
									$this->mark_lesson_attednance_on_login($lesson_id);
								}
							}
						}
					}
				}
			}
		}
	}

	function mark_lesson_attednance_on_login($lesson_id)
	{
		// Disallow auto attendance if admin not set in general setting.
		if ($this->course_automatic_attendance_on_login_setting != 'on') :
			return false;
		endif;


		global $wpdb;
		$table_name = $wpdb->prefix . 'tlms_attendance_logs';
		$result     = array();
		// Prevent attendance if admin disallowed attendance on this course.
		// today attendance will be perform, if already not found.
		$data   = array(
			'lesson_id'       => $lesson_id,
			'user_id'         => $this->user_id,
			'ip_address'      => $this->user_ip,
			'device_id'       => $this->device_id,
			'log_by_user_id'  => $this->user_id,
			'attendance_type' => $this->course_automatic_attendance_type,
			'comment'         => $this->course_automatic_attendance_comment,
			'created_at'      => date(
				'Y-m-d H:i:s',
				current_time('timestamp', wp_timezone_string())
			),
		);
		$format = array(
			'%d',
			'%d',
			'%s',
			'%s',
			'%d',
			'%s',
			'%s',
			'%s',
		);


		$wpdb->insert($table_name, $data, $format);
		$query_id = $wpdb->insert_id;
		$result[] = $query_id;

		return $result;
	}

	/**
	 * This function use to track time 
	 *
	 * @param [string] $user_login
	 * @param [object] $user
	 * @return void
	 */
	function  user_login_hook($user_login, $user)
	{
		$get_option  = get_option('tlms_at_options');
		$time_format = $get_option['tlms_show_universal_time'] == 'on' ? current_time('timestamp') : time();
		if ($get_option['tlms_at_user_track'] == 'on') {
			$timestap = current_time('timestamp');
			$save_arr = array(
				"user_id" => $this->user_id,
				"login_time" => date('Y-m-d H:i:s', $time_format),
				"logout_time" => null,
				"ip_address" => $this->user_ip
			);
			$this->attandence_uid = $this->login_track_time($save_arr);
			return $this->attandence_uid;
		}
	}

	/**
	 * This function use to track time 
	 *
	 * @param [int] $user_id
	 * @return void
	 */
	function user_logout_hook($user_id)
	{
		$get_option  = get_option('tlms_at_options');
		$time_format = $get_option['tlms_show_universal_time'] == 'on' ? current_time('timestamp') : time();
		if ($get_option['tlms_at_user_track'] == 'on') {
			$data = array(
				"logout_time" => date('Y-m-d H:i:s', $time_format),
				"user_id" => $user_id
			);
			$result = $this->logout_track_time($data);
		}
	}

	/**
	 * add meta box for minimum attendance option
	 *
	 * @param [object] $post_type
	 * @return void
	 */
	public function add_minimum_attendance_metabox($post_type)
	{
		if ($post_type === 'courses') {
			add_meta_box(
				'tlms_at_course_minimum_attendance',
				__('Minimum Attendance option', 'tutor-lms-attendance'),
				array($this, 'render_attendance_meta_box_content'),
				$post_type,
				'advanced',
				'high'
			);
		}
	}

	/**
	 * Render minimum attendance metabox setting
	 *
	 * @param [object] $post
	 * @return void
	 */
	public function render_attendance_meta_box_content($post)
	{
		// Add an nonce field so we can check for it later.
		wp_nonce_field('tlms_at_minimum_att', 'tlms_at_minimum_att_nonce');

		// Use get_post_meta to retrieve an existing value from the database.
		$value = get_post_meta($post->ID, '_minimum_attendance_tlms_at', true);

		// Display the form, using the current value.
		?>
		<label for="tlms_at_course_minimum_attendance">
			<?php _e('Minimum Attendance', 'tutor-lms-attendance'); ?>
		</label>
		<input type="number" id="tlms_at_course_minimum_attendance" name="tlms_at_course_minimum_attendance" value="<?php echo esc_attr($value); ?>" size="25" />
<?php
	}

	/**
	 * Save the meta when the post is saved.
	 *
	 * @param [init] $post_id
	 * @return void
	 */
	public function save_minimum_attendance_metabox($post_id)
	{

		// Check if our nonce is set.
		if (!isset($_POST['tlms_at_minimum_att_nonce'])) {
			return $post_id;
		}

		$nonce = $_POST['tlms_at_minimum_att_nonce'];

		// Verify that the nonce is valid.
		if (!wp_verify_nonce($nonce, 'tlms_at_minimum_att')) {
			return $post_id;
		}

		/*
		* If this is an autosave, our form has not been submitted,
		* so we don't want to do anything.
		*/
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return $post_id;
		}

		// Check the user's permissions.
		if ('courses' == $_POST['post_type']) {
			if (current_user_can('edit_page', $post_id)) {
				return $post_id;
			}
		}
		/* OK, it's safe for us to save the data now. */

		// Sanitize the user input.
		$mydata = sanitize_text_field($_POST['tlms_at_course_minimum_attendance']);

		// Update the meta field.
		update_post_meta($post_id, '_minimum_attendance_tlms_at', $mydata);
	}

	function login_track_time($data){
		
		global $wpdb;
		$table_name = $wpdb->prefix . 'tlms_timetrack_logs';
		$result     = array();
		$format = array(
			'%d',
			'%s',
			'%s',
			'%s',
		);
		$wpdb->insert($table_name, $data, $format);
		$query_id = $wpdb->insert_id;
		$result[] = $query_id;
		$this->attandence_uid = $query_id;
		return $result;
	}
	public function logout_track_time($data){
		global $wpdb;
		$table_name = $wpdb->prefix . 'tlms_timetrack_logs';
		$result     = array();
		$id = $wpdb->get_var( 'SELECT id FROM ' . $table_name. ' WHERE user_id = '.$data['user_id'].' ORDER BY id DESC LIMIT 1');

		$query_result = $wpdb->update($table_name, $data, array('id' => $id));
		
		if ($query_result !== false) :
			$query_id = $id;
			$result[] = $query_id;
		endif;
		return $result;
	}
	function set_user_all_courses_attendance_on_login()
	{
		
		// Disallow auto attendance if admin not set in genral setting.
		if ($this->course_automatic_attendance_on_login_setting != 'on') :
			return false;
		endif;

		$this->user_all_enrolled_courses = array_unique(array_merge($this->user_individual_enrolled_courses, $this->user_groups_enrolled_courses), SORT_REGULAR);

		global $wpdb;
		$table_name = $wpdb->prefix . 'tlms_attendance_logs';
		$result     = array();
		foreach ($this->user_all_enrolled_courses as $user_enrolled_course) :
			// Prevent attendance if admin disallowed attendance on this course.
			// today attendance will be perform, if already not found.
			$data   = array(
				'course_id'       => $user_enrolled_course,
				'user_id'         => $this->user_id,
				'ip_address'      => $this->user_ip,
				'device_id'       => $this->device_id,
				'log_by_user_id'  => $this->user_id,
				'attendance_type' => $this->course_automatic_attendance_type,
				'comment'         => $this->course_automatic_attendance_comment,
				'created_at'      => date(
					'Y-m-d H:i:s',
					current_time('timestamp', wp_timezone_string())
				),
			);
			$format = array(
				'%d',
				'%d',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
				'%s',
			);

			$attendance_query_type = ($this->course_today_attendance($this->user_id, $user_enrolled_course) != 0) ? 'update' : 'insert';
			$today_attendance_id   = ($this->course_today_attendance($this->user_id, $user_enrolled_course) != 0) ? $this->course_today_attendance($this->user_id, $user_enrolled_course) : 0;

			//Disallow user auto login attendance if admin / Tutor Instructor has already mark there attendance
			if ($attendance_query_type == 'update' && $this->course_today_attendance_admin_overwrite($this->user_id, $user_enrolled_course) == true) :
				continue;
			endif;

			if ($attendance_query_type == 'update') :
				$query_result = $wpdb->update($table_name, $data, array('id' => $today_attendance_id));
				if ($query_result !== false) :
					$query_id = $today_attendance_id;
					$result[] = $query_id;
				endif;
			elseif ($attendance_query_type == 'insert') :
				$wpdb->insert($table_name, $data, $format);
				$query_id = $wpdb->insert_id;
				$result[] = $query_id;
			endif;

		endforeach;

		return $result;
	}

	private function course_today_attendance($user_id = 0, $course_id = 0)
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'tlms_attendance_logs';
		$result     = $wpdb->get_var("SELECT id FROM {$table_name} WHERE (DATE(created_at) = CURDATE()) AND (user_id = {$user_id}) AND (course_id = {$course_id})");

		return $result;
	}

	private function course_today_attendance_admin_overwrite($user_id = 0, $course_id = 0)
	{
		global $wpdb;
		$table_name     = $wpdb->prefix . 'tlms_attendance_logs';
		$log_by_user_id = $wpdb->get_var("SELECT log_by_user_id FROM {$table_name} WHERE (DATE(created_at) = CURDATE()) AND (user_id = {$user_id}) AND (course_id = {$course_id})");

		if ($log_by_user_id != $user_id) {
			// if record exist then it states that attendance is marked by admin / Tutor instructor
			return true;
		} else {
			// if record exist then it states that attendance is marked by user
			return false;
		}
	}

	/**
	 * Save the plugin's settings.
	 */
	public function save_settings()
	{
		if (!current_user_can('manage_options')) {
			return;
		}

		// Check if we are on the plugin settings page.
		if (isset($_REQUEST['page']) && 'learndash-audio-assignments' === rtrim($_REQUEST['page'])) {

			// Check if the active tab is settings.
			if (isset($_REQUEST['tab']) && 'settings' === rtrim($_REQUEST['tab'])) {

				if (!empty($_POST)) {
					$tlms_att_nonce = isset($_POST['tutor_lms_att_settings_save']) ? $_POST['tutor_lms_att_settings_save'] : -100;

					// Check if the nonce is valid.
					if (!wp_verify_nonce($tlms_att_nonce, 'learndash_audio_assignments_nonce')) {
						die('Process stopped, request could not be verified. Please contact the administrator.');
					}

					$tlms_att_settings = get_option('tlms_attendance_settings', array());

					$tlms_att_settings['tlms_att_wp_log'] = isset($_POST['tlms_att_wp_log']) ? $_POST['tlms_att_wp_log'] : '';


					$tlms_att_settings['tlms_att_ffmpeg'] = '';
					if (isset($_POST['tlms_att_ffmpeg']) & !empty($_POST['tlms_att_ffmpeg'])) {
						if (WN_LD_AA_Helper::isEnabled('shell_exec')) {
							$this->installFFmpeg();

							if (file_exists($this->getFFmpeg())) {
								$tlms_att_settings['tlms_att_ffmpeg'] = $_POST['tlms_att_ffmpeg'];
							} else {
								add_action("admin_notices", function () {
									$class   = 'notice notice-error is-dismissible';
									$message = __('FFmpeg installation declined by server. Please ask your server support to enable cUrl and wget.', 'tutor-lms-attendance');
									printf("<div id='message' class='%s'> <p>%s</p></div>", $class, $message);
								});
							}
						}
					}

					// Update tlms_att global settings.
					update_option('tlms_attendance_settings', $tlms_att_settings);
				}
			}
		}
	}
}

<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://wooninjas.com/
 * @since      1.0.0
 *
 * @package    Wn_Learndash_Feedback
 * @subpackage Wn_Learndash_Feedback/admin/partials
 */


?>
<div class="wn_wrap wrap-tlms-at-imprt">
    <div id="tlms_at_import_messages"></div>
    <div id="ld_qie_content_wrap">
        <div id="tlms_at_loader_spinner" style="display: none;">
            <div class="ld_qie_spinner"></div>
        </div>
        <form id="tlms_at_upload_file_form" method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" id="ld_qie_action" value="tlms_at_upload_file_form_action">
            <input type="hidden" name="tlms_at_ajax_nonce" value="<?php echo wp_create_nonce('tlms-at-ajax-nonce'); ?>">
            <div id="ld_qie_import_step1">
                <h2><?php _e("Please Select CSV to Import Attendance", 'tutor-lms-attendance'); ?></h2>
                <button id="btn_export_attendance_logs" type="button" class="button button-primary ld-qie-button"><?php _e('Export Attendance logs', 'tutor-lms-attendance'); ?></button>
                <br>
                <br>
                <div class="tlms-at-impr-ex-box">
                    <div class="import-excel-page">
                        <div class="content">
                            <div class="box">
                                <input type="file" id="ldcms_import_file" name="ldcms_import_file" class="inputfile inputfile-6" />
                                <label for="ldcms_import_file"><span id="uploaded_file_name_here"></span> <strong>
                                        <svg xmlns='http://www.w3.org/2000/svg' width='20' height='17' viewBox='0 0 20 17'>
                                            <path d='M10 0l-5.2 4.9h3.3v5.1h3.8v-5.1h3.3l-5.2-4.9zm9.3 11.5l-3.2-2.1h-2l3.4 2.6h-3.5c-.1 0-.2.1-.2.1l-.8 2.3h-6l-.8-2.2c-.1-.1-.1-.2-.2-.2h-3.6l3.4-2.6h-2l-3.2 2.1c-.4.3-.7 1-.6 1.5l.6 3.1c.1.5.7.9 1.2.9h16.3c.6 0 1.1-.4 1.3-.9l.6-3.1c.1-.5-.2-1.2-.7-1.5z' />
                                        </svg>
                                        <?php _e('Select a file &hellip;', 'tutor-lms-attendance'); ?></strong></label>
                                <div class="tlms-at-import-log"></div>
                            </div>
                        </div>
                    </div>

                    <div class="submit" style="text-align: center;">
                        <button class="button button-primary ld-qie-button" type="submit" name="import-btn"><?php _e('Import', 'tutor-lms-attendance'); ?>
                            <span class="dashicons dashicons-arrow-right-alt2 no-left-margin"></span></button>
                    </div>
                </div>
            </div>
        </form>

    </div>
</div>
<script>

    // Alert Message before export csv
    var export_confirm = '<?php _e('Do you want to export Attendance in a CSV file?', 'tutor-lms-attendance') ?>';

    document.addEventListener('DOMContentLoaded', function() {
    var fileInputs = document.querySelectorAll('input[type="file"]');

    fileInputs.forEach(function(fileInput) {
        // Create a span element to show the custom "No file chosen" text
        var fileChosen = document.createElement('span');
        fileChosen.textContent = '<?php _e('No File chosen', 'tutor-lms-attendance') ?>';
        fileInput.parentNode.insertBefore(fileChosen, fileInput.nextSibling);

        // Change the "Choose File" button text
        var fileLabel = document.createElement('label');
        fileLabel.textContent = '<?php _e('Choose File', 'tutor-lms-attendance') ?>';
        fileLabel.style.cursor = 'pointer';
        fileInput.parentNode.insertBefore(fileLabel, fileInput);
        fileInput.style.display = 'block';

        // Update the label text when a file is chosen
        fileInput.addEventListener('change', function() {
            fileChosen.textContent = fileInput.files.length > 0 ? fileInput.files[0].name : '<?php _e('No file selected', 'tutor-lms-attendance') ?>';
        });

        // Style the custom label to look like a button
        fileLabel.style.backgroundColor = '#074b79';
        fileLabel.style.color = '#fff';
        fileLabel.style.padding = '15px';
        fileLabel.style.display = 'inline-block';
        fileLabel.style.borderRadius = '3px';
        fileLabel.style.marginRight = '10px';

        // Associate the label with the file input
        fileLabel.setAttribute('for', fileInput.id);
        fileInput.id = 'custom-file-' + Math.random().toString(36).substr(2, 9);
    });
});

</script>
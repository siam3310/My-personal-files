<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function doing_cron() {

	// Bail if not doing WordPress cron (>4.8.0)
	if ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ) {
		return true;

		// Bail if not doing WordPress cron (<4.8.0)
	} elseif ( defined( 'DOING_CRON' ) && ( true === DOING_CRON ) ) {
		return true;
	}

	// Default to false
	return false;
}


/**
 * Get attendance of students for given $args
 *
 * @param array $args
 *
 * @return array
 */
function tlms_attendance_get( $args = array() ) {
	global $wpdb;
	$table_attendance_logs = $wpdb->prefix . 'tlms_attendance_logs';
	$table_posts           = $wpdb->prefix . 'posts';
	$table_users           = $wpdb->prefix . 'users';

	if ( ! isset( $args['user_ids'] ) ) {
		$args['user_ids'] = array();
	}

	/**
	 * Checks Capability
	 *
	 * If logged in user is tutor instructor then get all user ids of users enrolled to this tutor instructor's Group
	 * Then pass these user ids to pull their Attendance Logs and display to their tutor instructor in Dashboard
	 *
	 * Also checks if logged in user is tutor instructor but not assigned any Group then do not show Attendance Logs of any user
	 */

	if ( ! isset( $args['display_col'] ) ) {
		$args['display_col'] = false;
	}

	if ( ! isset( $args['is_paged'] ) ) {
		$args['is_paged'] = false;
	} else {
		if ( empty( $args['current_page'] ) ) {
			$args['current_page'] = 1;
		}

		if ( empty( $args['per_page'] ) ) {
			$args['per_page'] = get_option( 'posts_per_page' );
		}
	}

	$group_by = false;
	if ( isset( $args['group_by'] ) ) {
		$group_by = $args['group_by'];
	}

	$is_paged     = $args['is_paged'];
	$lesson_ids_x = '';
	$args         = get_course_attendance_logs_filter_by_taxonomy( $args );
	$args         = get_lesson_attendance_logs_filter_by_taxonomy( $args, $lesson_ids_x );
	$args         = get_attendance_logs_for_searched_user_ids( $args );

	$params = array();
	if ( $group_by || ( isset( $_GET['action'] ) && ( $_GET['action'] !== 'export_detail_logs' && $_GET['action'] !== 'view_detail_logs' ) ) ) {
		$cols = ' TLMSAL.*, COUNT(*) attendance_count';
	} else {
		$cols = ' TLMSAL.*, 1 AS attendance_count';
	}

	if ( $args['display_col'] ) {
		$cols .= ', P.post_title, P.post_type, U.user_login, U2.user_login AS admin_user_login';
	}

	$sql_str = "SELECT {$cols} FROM {$table_attendance_logs} TLMSAL ";

	if ( $args['display_col'] ) {
		if ( ! $group_by || $group_by == 'all' ) {
			$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON ( P.`ID` = TLMSAL.course_id OR  P.`ID` = TLMSAL.lesson_id OR  P.`ID` = TLMSAL.topic_id )';
		} elseif ( $group_by == 'course,lesson,topic' ) {
			$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON ( P.`ID` = TLMSAL.course_id OR  P.`ID` = TLMSAL.lesson_id OR  P.`ID` = TLMSAL.topic_id )';
		} elseif ( $group_by == 'course,lesson' ) {
			$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON ( P.`ID` = TLMSAL.course_id OR  P.`ID` = TLMSAL.lesson_id )';
		} elseif ( $group_by == 'course,topic' ) {
			$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON ( P.`ID` = TLMSAL.course_id OR  P.`ID` = TLMSAL.topic_id )';
		} elseif ( $group_by == 'lesson,topic' ) {
			$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON ( P.`ID` = TLMSAL.lesson_id OR  P.`ID` = TLMSAL.topic_id )';
		} elseif ( $group_by == 'user' ) {
			$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON ( P.`ID` = TLMSAL.course_id OR  P.`ID` = TLMSAL.lesson_id OR  P.`ID` = TLMSAL.topic_id )';
		} elseif ( $group_by == 'course' ) {
			$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON (P.`ID` = TLMSAL.`course_id`)';
		} elseif ( $group_by == 'lesson' ) {
			$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON (P.`ID` = TLMSAL.`lesson_id`)';
		} elseif ( $group_by == 'topic' ) {
			$sql_str .= 'INNER JOIN ' . $table_posts . ' P ON (P.`ID` = TLMSAL.`topic_id`)';
		} else {
			// for Details of Logs, courses, lessons, topics
			if ( isset( $_GET['action'] ) && ( $_GET['action'] == 'view_detail_logs' || $_GET['action'] == 'export_detail_logs' ) ) {
				if ( isset( $_GET['view_type'] ) && $_GET['view_type'] == 'course' ) {
					$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON (P.`ID` = TLMSAL.`course_id`)';
				} elseif ( isset( $_GET['view_type'] ) && $_GET['view_type'] == 'lesson' ) {
					$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON (P.`ID` = TLMSAL.`lesson_id`)';
				} elseif ( isset( $_GET['view_type'] ) && $_GET['view_type'] == 'topic' ) {
					$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON (P.`ID` = TLMSAL.`topic_id`)';
				} elseif ( isset( $_GET['view_type'] ) && $_GET['view_type'] == 'user' ) {
					$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON ( P.`ID` = TLMSAL.course_id OR  P.`ID` = TLMSAL.lesson_id OR  P.`ID` = TLMSAL.topic_id )';
				} elseif ( isset( $_GET['view_type'] ) && $_GET['view_type'] == 'absent' ) {
					if ( isset( $_GET['post_type'] ) && $_GET['post_type'] == 'course' ) {
						$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON ( P.`ID` = TLMSAL.course_id )';
					} elseif ( isset( $_GET['post_type'] ) && $_GET['post_type'] == 'lesson' ) {
						$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON ( P.`ID` = TLMSAL.lesson_id )';
					} elseif ( isset( $_GET['post_type'] ) && $_GET['post_type'] == 'topic' ) {
						$sql_str .= ' INNER JOIN ' . $table_posts . ' P ON ( P.`ID` = TLMSAL.topic_id )';
					}
				}
			}
		}

		$sql_str .= ' INNER JOIN ' . $table_users . ' U ON (U.`ID` = TLMSAL.`user_id`)
                    INNER JOIN ' . $table_users . ' U2 ON (U2.`ID` = TLMSAL.`log_by_user_id`)';
	}

	$sql_str .= ' WHERE 1=1 ';

	$data = array();
	$data = get_attendance_logs_group_by_post_type( $group_by, $args, $params, $sql_str, $format = '' );

	$args    = $data['args'];
	$sql_str = $data['sql_str'];
	$params  = $data['params'];

	if ( ! empty( $args['user_ids'] ) ) {
		if ( is_numeric( $args['user_ids'] ) && ! empty( absint( $args['user_ids'] ) ) ) {
			$args['user_ids'] = array( $args['user_ids'] );
		}
		$format  = implode( ', ', array_fill( 0, count( $args['user_ids'] ), '%d' ) );
		$sql_str .= " AND ( TLMSAL.user_id IN ({$format}) )";
		$params  = array_merge( $params, $args['user_ids'] );
	}

	if ( ! empty( $args['date_from'] ) ) {
		$sql_str  .= ' AND ( DATE(TLMSAL.created_at) >= DATE(%s) )';
		$params[] = $args['date_from'];
	}

	if ( ! empty( $args['date_to'] ) ) {
		$sql_str  .= ' AND ( DATE(TLMSAL.created_at) <= DATE(%s) )';
		$params[] = $args['date_to'];
	}

	if ( ! empty( $args['ip_address'] ) ) {
		$sql_str  .= ' AND ( TLMSAL.ip_address = %s )';
		$params[] = $args['ip_address'];
	}

	if ( ! empty( $args['device_id'] ) ) {
		$sql_str  .= ' AND ( TLMSAL.device_id = %s )';
		$params[] = $args['device_id'];
	}

	if ( ! isset( $args['attendance_type'] ) || empty( $args['attendance_type'] ) ) {
		// $sql_str .= ' AND ( TLMSAL.attendance_type = %s )';
		// $params[] = 'present';
	} else {
		if ( $args['attendance_type'] != 'any' ) {
			$sql_str  .= ' AND ( TLMSAL.attendance_type = %s )';
			$params[] = $args['attendance_type'];
		}
	}

	if ( ! isset( $args['order_by'] ) || empty( $args['order_by'] ) ) {
		$args['order_by'] = 'attendance_count';
	}

	if ( ! isset( $args['order'] ) || empty( $args['order'] ) ) {
		$args['order'] = 'DESC';
	}

	if ( ! empty( $params ) ) {
		$sql_str = $wpdb->prepare( $sql_str, $params );
	}

	$total_records = 0;

	if ( $group_by != false ) {
		$sql_str .= ' GROUP BY ';
	}

	if ( isset( $args['front_end_short_code'] ) && $args['front_end_short_code'] == true ) {
		if ( ( $args['group_by'] ?? null ) == 'course,lesson,topic' ) {
			$sql_str .= ' TLMSAL.course_id, TLMSAL.lesson_id, TLMSAL.topic_id, TLMSAL.user_id';
		}
		if ( ( $args['group_by'] ?? null ) == 'course,lesson' ) {
			$sql_str .= ' TLMSAL.course_id, TLMSAL.lesson_id, TLMSAL.user_id';
		} elseif ( ( $args['group_by'] ?? null ) == 'course,topic' ) {
			$sql_str .= ' TLMSAL.course_id, TLMSAL.topic_id, TLMSAL.user_id';
		} elseif ( ( $args['group_by'] ?? null ) == 'lesson,topic' ) {
			$sql_str .= ' TLMSAL.lesson_id, TLMSAL.topic_id, TLMSAL.user_id';
		} elseif ( ( $args['group_by'] ?? null ) == 'course' ) {
			$sql_str .= 'TLMSAL.course_id, TLMSAL.user_id';
		} elseif ( ( $args['group_by'] ?? null ) == 'lesson' ) {
			$sql_str .= ' TLMSAL.lesson_id, TLMSAL.user_id';
		} elseif ( ( $args['group_by'] ?? null ) == 'topic' ) {
			$sql_str .= ' TLMSAL.topic_id, TLMSAL.user_id';
		} elseif ( ( $args['group_by'] ?? null ) == 'user' ) {
			$sql_str .= ' TLMSAL.user_id';
		}
	} else {
		if ( $group_by == 'all' ) {
			$sql_str .= 'TLMSAL.course_id, TLMSAL.lesson_id, TLMSAL.topic_id, TLMSAL.user_id';
		} elseif ( $group_by == 'course' && ( $_GET['action'] ?? null ) !== 'export_detail_logs' ) {
			$sql_str .= ' TLMSAL.course_id';
		} elseif ( $group_by == 'lesson' && ( $_GET['action'] ?? null ) !== 'export_detail_logs' ) {
			$sql_str .= ' TLMSAL.lesson_id';
		} elseif ( $group_by == 'topic' && ( $_GET['action'] ?? null ) !== 'export_detail_logs' ) {
			$sql_str .= ' TLMSAL.topic_id';
		} elseif ( $group_by == 'user' && ( $_GET['action'] ?? null ) !== 'export_detail_logs' ) {
			$sql_str .= ' TLMSAL.user_id';
		}
		if ( isset( $params['attendance_type'] ) && ! empty( $params['attendance_type'] ) ) {
			$sql_str .= ', TLMSAL.attendance_type';
		}
	}

	$sql_str .= " ORDER BY {$args['order_by']} {$args['order']}";


	if ( $is_paged ) {
		$total_records  = $wpdb->get_var( "SELECT COUNT(1) FROM ({$sql_str}) AS combined_table" );
		$items_per_page = $args['per_page'];
		$current_page   = $args['current_page'];
		$offset         = ( $current_page * $items_per_page ) - $items_per_page;
		$sql_str        .= " LIMIT {$offset}, {$items_per_page}";
	}

	$results = $wpdb->get_results( $sql_str, ARRAY_A );

	if ( ! is_wp_error( $results ) ) {
		if ( $is_paged ) {
			return array(
				'results' => $results,
				'total'   => $total_records,
			);
		}

		return $results;
	}

	return array();
}

function get_attendance_logs_for_searched_user_ids( $args ) {
	$roles = array();
	if ( isset( $args['user_role'] ) && ! empty( $args['user_role'] ) ) {
		$roles[] = $args['user_role'];
	}

	$is_user_search = isset( $args['search'] ) && ! empty( $args['search'] );
	$is_user_role   = isset( $args['user_role'] ) && ! empty( $args['user_role'] );

	if ( $is_user_search || $is_user_role ) {

		$search_string = null;
		$user_role     = array();

		if ( $is_user_search ) {
			$search_string = esc_attr( trim( $args['search'] ) );
		}

		if ( $is_user_role ) {
			$user_role[] = sanitize_text_field( $args['user_role'] );
		}

		$user_query_args = array(
			'fields'   => 'ids',
			'search'   => "*{$search_string}*",
			'role__in' => $user_role,
			'order'    => 'ASC',
			'orderby'  => 'display_name',
		);

		if ( is_numeric( $args['user_ids'] ) && ! empty( absint( $args['user_ids'] ) ) ) {
			$args['user_ids'] = array( $args['user_ids'] );
		} elseif ( is_array( $args['user_ids'] ) && ! empty( $args['user_ids'] ) ) {
			$args['user_ids'] = array_filter( array_map( 'sanitize_text_field', $args['user_ids'] ) );
		}
		if ( ! empty( $args['user_ids'] ) ) {
			$user_query_args['include'] = $args['user_ids'];
		}
		$users            = new WP_User_Query( $user_query_args );
		$args['user_ids'] = empty( $users->get_results() ) ? - 1 : $users->get_results();

		return $args;
	}

	return $args;
}

function get_course_attendance_logs_filter_by_taxonomy( $args ) {

	if ( empty( $args['course_ids'] ) ) {

		$args['course_ids'] = - 1;
		$tax_query          = array( 'relation' => 'AND' );

		if ( ! empty( $args['course_category_id'] ) ) {

			$tax_query[] = array(
				'taxonomy' => 'course-category',
				'field'    => 'term_id',
				'terms'    => absint( $args['course_category_id'] ),
				'operator' => 'AND',
			);

		}

		if ( ! empty( $args['course_tag_id'] ) ) {

			$tax_query[] = array(
				'taxonomy' => 'course-tag',
				'field'    => 'term_id',
				'terms'    => absint( $args['course_tag_id'] ),
				'operator' => 'AND',
			);
		}

		if ( ! empty( $args['post_category_id'] ) ) {

			$tax_query[] = array(
				'taxonomy' => 'category',
				'field'    => 'term_id',
				'terms'    => absint( $args['post_category_id'] ),
				'operator' => 'AND',
			);
		}

		if ( ! empty( $args['post_tag_id'] ) ) {

			$tax_query[] = array(
				'taxonomy' => 'post_tag',
				'field'    => 'term_id',
				'terms'    => absint( $args['post_tag_id'] ),
				'operator' => 'AND',
			);
		}

		$query_args = array(
			'post_type' => 'courses',
			'fields'    => 'ids',
			'tax_query' => $tax_query,
		);

		$query = new WP_Query( $query_args );
		if ( ! empty( $query->posts ) ) {
			$args['course_ids'] = $query->posts;
		}
	}

	return $args;
}

function get_lesson_attendance_logs_filter_by_taxonomy( $args, $lesson_ids_x ) {

	if ( empty( $args['lesson_ids'] ) ) {
		$args['lesson_ids'] = - 1;
		$tax_query          = array( 'relation' => 'AND' );
		if ( ! empty( $args['lesson_category_id'] ) ) {
			$tax_query[] = array(
				'taxonomy' => 'ld_lesson_category',
				'field'    => 'term_id',
				'terms'    => absint( $args['lesson_category_id'] ),
				'operator' => 'AND',
			);
		}
		if ( ! empty( $args['lesson_tag_id'] ) ) {
			$tax_query[] = array(
				'taxonomy' => 'ld_lesson_tag',
				'field'    => 'term_id',
				'terms'    => absint( $args['lesson_tag_id'] ),
				'operator' => 'AND',
			);
		}
		if ( ! empty( $args['post_category_id'] ) ) {
			$tax_query[] = array(
				'taxonomy' => 'category',
				'field'    => 'term_id',
				'terms'    => absint( $args['post_category_id'] ),
				'operator' => 'AND',
			);
		}
		if ( ! empty( $args['post_tag_id'] ) ) {
			$tax_query[] = array(
				'taxonomy' => 'post_tag',
				'field'    => 'term_id',
				'terms'    => absint( $args['post_tag_id'] ),
				'operator' => 'AND',
			);
		}
		$query_args = array(
			'post_type' => 'lesson',
			'fields'    => 'ids',
			'tax_query' => $tax_query,
		);

		$query = new WP_Query( $query_args );

		if ( ! empty( $query->posts ) ) {
			$args['lesson_ids'] = $query->posts;
		}


		return $args;
	}

	return $args;
}

function get_topic_attendance_logs_filter_by_taxonomy( $args, $topic_id_x ) {

	if ( empty( $args['topic_ids'] ) ) {
		$args['topic_ids'] = - 1;
		$tax_query         = array( 'relation' => 'AND' );
		if ( ! empty( $args['topic_category_id'] ) ) {
			$tax_query[] = array(
				'taxonomy' => 'ld_topic_category',
				'field'    => 'term_id',
				'terms'    => absint( $args['topic_category_id'] ),
				'operator' => 'AND',
			);
		}
		if ( ! empty( $args['topic_tag_id'] ) ) {
			$tax_query[] = array(
				'taxonomy' => 'ld_topic_tag',
				'field'    => 'term_id',
				'terms'    => absint( $args['topic_tag_id'] ),
				'operator' => 'AND',
			);
		}
		if ( ! empty( $args['post_category_id'] ) ) {
			$tax_query[] = array(
				'taxonomy' => 'category',
				'field'    => 'term_id',
				'terms'    => absint( $args['post_category_id'] ),
				'operator' => 'AND',
			);
		}
		if ( ! empty( $args['post_tag_id'] ) ) {
			$tax_query[] = array(
				'taxonomy' => 'post_tag',
				'field'    => 'term_id',
				'terms'    => absint( $args['post_tag_id'] ),
				'operator' => 'AND',
			);
		}
		$query_args = array(
			'post_type' => 'topics',
			'fields'    => 'ids',
			'nopaging'  => true,
			'tax_query' => $tax_query,
		);
		$query      = new WP_Query( $query_args );
		if ( ! empty( $query->posts ) ) {
			$args['topic_ids'] = $query->posts;
		}

		if ( learndash_is_group_leader_user() && ! learndash_is_admin_user() ) {
			$args['topic_ids'] = count( $topic_id_x ) > 0 ? $topic_id_x : - 1;
		}

		return $args;
	}

	return $args;
}

function get_attendance_logs_group_by_post_type( $group_by, $args, $params, $sql_str, $format ) {
	if ( $group_by == 'all' ) {
		if ( isset( $args['tlms_at_post_type'] ) && ! empty( $args['tlms_at_post_type'] ) && $args['tlms_at_post_type'] == 'courses' ) {
			if ( ! empty( $args['course_ids'] ) ) {
				$format  = implode( ', ', array_fill( 0, count( $args['course_ids'] ), '%d' ) );
				$sql_str .= " AND ( TLMSAL.course_id IN ({$format}) )";
				$params  = array_merge( $params, $args['course_ids'] );
			}
		} elseif ( isset( $args['tlms_at_post_type'] ) && ! empty( $args['tlms_at_post_type'] ) && $args['tlms_at_post_type'] == 'lesson' ) {
			if ( ! empty( $args['lesson_ids'] ) ) {
				$format  = implode( ', ', array_fill( 0, count( $args['lesson_ids'] ), '%d' ) );
				$sql_str .= " AND ( TLMSAL.lesson_id IN ({$format}) )";
				$params  = array_merge( $params, $args['lesson_ids'] );
			}
		} elseif ( isset( $args['tlms_at_post_type'] ) && ! empty( $args['tlms_at_post_type'] ) && $args['tlms_at_post_type'] == 'topics' ) {
			if ( ! empty( $args['topic_ids'] ) ) {
				$format  = implode( ', ', array_fill( 0, count( $args['topic_ids'] ), '%d' ) );
				$sql_str .= " AND ( TLMSAL.topic_id IN ({$format}) )";
				$params  = array_merge( $params, $args['topic_ids'] );
			}
		}
	} elseif ( ( $args['group_by'] ?? null ) == 'course,lesson,topic' ) {

		$sql_str .= ' AND (';
		if ( ! empty( $args['course_ids'] ) ) {
			$format  = implode( ', ', array_fill( 0, count( $args['course_ids'] ), '%d' ) );
			$sql_str .= ( ! empty( $format ) ) ? "  TLMSAL.course_id IN ({$format}) " : '';
			$params  = array_merge( $params, $args['course_ids'] );
		}
		if ( ! empty( $args['lesson_ids'] ) ) {
			$format = implode( ', ', array_fill( 0, count( $args['lesson_ids'] ), '%d' ) );
			if ( ! empty( $args['course_ids'] ) ) {
				$sql_str .= ( ! empty( $format ) ) ? " OR  TLMSAL.lesson_id IN ({$format}) " : '';
			} else {
				$sql_str .= ( ! empty( $format ) ) ? " TLMSAL.lesson_id IN ({$format}) " : '';
			}
			$params = array_merge( $params, $args['lesson_ids'] );
		}
		if ( ! empty( $args['topic_ids'] ) ) {
			$format = implode( ', ', array_fill( 0, count( $args['topic_ids'] ), '%d' ) );
			if ( ! empty( $args['lesson_ids'] ) ) {
				$sql_str .= ( ! empty( $format ) ) ? " OR TLMSAL.topic_id IN ({$format}) " : '';
			} else {
				$sql_str .= ( ! empty( $format ) ) ? " TLMSAL.topic_id IN ({$format}) " : '';
			}
			$params = array_merge( $params, $args['topic_ids'] );
		}
		$sql_str .= ' )';

	} elseif ( ( $args['group_by'] ?? null ) == 'course,lesson' ) {
		$sql_str .= ' AND (';
		if ( ! empty( $args['course_ids'] ) ) {
			$format  = implode( ', ', array_fill( 0, count( $args['course_ids'] ), '%d' ) );
			$sql_str .= ( ! empty( $format ) ) ? "  TLMSAL.course_id IN ({$format}) " : '';
			$params  = array_merge( $params, $args['course_ids'] );
		}
		if ( ! empty( $args['lesson_ids'] ) ) {
			$format = implode( ', ', array_fill( 0, count( $args['lesson_ids'] ), '%d' ) );
			if ( ! empty( $args['course_ids'] ) ) {
				$sql_str .= ( ! empty( $format ) ) ? " OR  TLMSAL.lesson_id IN ({$format}) " : '';
			} else {
				$sql_str .= ( ! empty( $format ) ) ? " TLMSAL.lesson_id IN ({$format}) " : '';
			}
			$params = array_merge( $params, $args['lesson_ids'] );
		}
		$sql_str .= ' )';
	} elseif ( ( $args['group_by'] ?? null ) == 'course,topic' ) {
		$sql_str .= ' AND (';
		if ( ! empty( $args['course_ids'] ) ) {
			$format  = implode( ', ', array_fill( 0, count( $args['course_ids'] ), '%d' ) );
			$sql_str .= ( ! empty( $format ) ) ? "  TLMSAL.course_id IN ({$format}) " : '';
			$params  = array_merge( $params, $args['course_ids'] );
		}
		if ( ! empty( $args['topic_ids'] ) ) {
			$format = implode( ', ', array_fill( 0, count( $args['topic_ids'] ), '%d' ) );
			if ( ! empty( $args['course_ids'] ) ) {
				$sql_str .= ( ! empty( $format ) ) ? " OR TLMSAL.topic_id IN ({$format}) " : '';
			} else {
				$sql_str .= ( ! empty( $format ) ) ? " TLMSAL.topic_id IN ({$format}) " : '';
			}
			$params = array_merge( $params, $args['topic_ids'] );
		}
		$sql_str .= ' )';
	} elseif ( ( $args['group_by'] ?? null ) == 'lesson,topic' ) {
		$sql_str .= ' AND (';
		if ( ! empty( $args['lesson_ids'] ) ) {
			$format  = implode( ', ', array_fill( 0, count( $args['lesson_ids'] ), '%d' ) );
			$sql_str .= ( ! empty( $format ) ) ? "  TLMSAL.lesson_id IN ({$format}) " : '';
			$params  = array_merge( $params, $args['lesson_ids'] );
		}
		if ( ! empty( $args['topic_ids'] ) ) {
			$format = implode( ', ', array_fill( 0, count( $args['topic_ids'] ), '%d' ) );
			if ( ! empty( $args['lesson_ids'] ) && is_array( $args['lesson_ids'] ) ) {
				$sql_str .= ( ! empty( $format ) ) ? " OR TLMSAL.topic_id IN ({$format}) " : '';
			} else {
				$sql_str .= ( ! empty( $format ) ) ? " TLMSAL.topic_id IN ({$format}) " : '';
			}
			$params = array_merge( $params, $args['topic_ids'] );
		}
		$sql_str .= ' )';
	} elseif ( $group_by == 'course' ) {
		if ( ! empty( $args['course_ids'] ) ) {
			if ( is_numeric( $args['course_ids'] ) && ! empty( absint( $args['course_ids'] ) ) ) {
				$args['course_ids'] = array( $args['course_ids'] );
			}
			$format  = implode( ', ', array_fill( 0, count( $args['course_ids'] ), '%d' ) );
			$sql_str .= " AND ( TLMSAL.course_id IN ({$format}) )";
			$params  = array_merge( $params, $args['course_ids'] );
		}
	} elseif ( $group_by == 'lesson' ) {
		if ( ! empty( $args['lesson_ids'] ) ) {
			if ( is_numeric( $args['lesson_ids'] ) && ! empty( absint( $args['lesson_ids'] ) ) ) {
				$args['lesson_ids'] = array( $args['lesson_ids'] );
			}
			$format  = implode( ', ', array_fill( 0, count( $args['lesson_ids'] ), '%d' ) );
			$sql_str .= " AND ( TLMSAL.lesson_id IN ({$format}) )";
			$params  = array_merge( $params, $args['lesson_ids'] );
		}
	} elseif ( $group_by == 'topic' ) {
		if ( ! empty( $args['topic_ids'] ) ) {
			if ( is_numeric( $args['topic_ids'] ) && ! empty( absint( $args['topic_ids'] ) ) ) {
				$args['topic_ids'] = array( $args['topic_ids'] );
			}
			$format  = implode( ', ', array_fill( 0, count( $args['topic_ids'] ), '%d' ) );
			$sql_str .= " AND ( TLMSAL.topic_id IN ({$format}) )";
			$params  = array_merge( $params, $args['topic_ids'] );
		}
	} else {
		// for induval course, lesson, topic detail log by id and also on absent induval screens
		if ( isset( $_GET['action'] ) && ( $_GET['action'] == 'view_detail_logs' || $_GET['action'] == 'export_detail_logs' ) ) {
			if ( isset( $_GET['view_type'] ) && $_GET['view_type'] == 'course' && isset( $_GET['course_id'] ) ) {
				$sql_str .= ' AND ( TLMSAL.course_id = ' . $_GET['course_id'] . ')';
			} elseif ( isset( $_GET['view_type'] ) && $_GET['view_type'] == 'lesson' && isset( $_GET['lesson_id'] ) ) {
				$sql_str .= ' AND ( TLMSAL.lesson_id = ' . $_GET['lesson_id'] . ')';
			} elseif ( isset( $_GET['view_type'] ) && $_GET['view_type'] == 'topic' && isset( $_GET['topic_id'] ) ) {
				$sql_str .= ' AND ( TLMSAL.topic_id = ' . $_GET['topic_id'] . ')';
			} elseif ( isset( $_GET['view_type'] ) && $_GET['view_type'] == 'absent' ) {
				if ( $_GET['post_type'] == 'course' && isset( $_GET['course_id'] ) ) {
					$sql_str .= ' AND ( TLMSAL.course_id = ' . $_GET['course_id'] . ')';
				} elseif ( $_GET['post_type'] == 'lesson' && isset( $_GET['lesson_id'] ) ) {
					$sql_str .= ' AND ( TLMSAL.lesson_id = ' . $_GET['lesson_id'] . ')';
				} elseif ( $_GET['post_type'] == 'topic' && isset( $_GET['topic_id'] ) ) {
					$sql_str .= ' AND ( TLMSAL.topic_id = ' . $_GET['topic_id'] . ')';
				}
			} else {
				if ( isset( $_GET['course_id'] ) && ! empty( $_GET['course_id'] ) ) {
					$sql_str .= ' AND ( TLMSAL.course_id = ' . $_GET['course_id'] . ')';
				} elseif ( isset( $_GET['lesson_id'] ) && ! empty( $_GET['lesson_id'] ) ) {
					$sql_str .= ' AND ( TLMSAL.lesson_id = ' . $_GET['lesson_id'] . ')';
				} elseif ( isset( $_GET['topic_id'] ) && ! empty( $_GET['topic_id'] ) ) {
					$sql_str .= ' AND ( TLMSAL.topic_id = ' . $_GET['topic_id'] . ')';
				}
			}
		}
	}

	return array( 'args' => $args, 'params' => $params, 'sql_str' => $sql_str );
}

function ld_check_attendance_exists_from_user( $args = array() ) {
	global $wpdb;
	$table_attendance_logs = $wpdb->prefix . 'ld_attendance_logs';

	$condition = " 1=1 ";

	if ( ! isset( $args['user_id'] ) ) {
		return false;
	}
	if ( isset( $args['course_id'] ) ) {
		$condition .= ' AND course_id=' . $args['course_id'];
	}
	if ( isset( $args['lesson_id'] ) ) {
		$condition .= ' AND lesson_id=' . $args['lesson_id'];
	}
	if ( isset( $args['quiz_id'] ) ) {
		$condition .= ' AND quiz_id=' . $args['quiz_id'];
	}

	$sql_str = "SELECT * FROM {$table_attendance_logs} TLMSAL Where {$condition} ";
	$results = $wpdb->get_results( $sql_str, ARRAY_A );

	if ( ! is_wp_error( $results ) ) {
		return $results;
	}

	return array();
}


function ld_time_track_get( $args = array() ) {

	global $wpdb;

	$table_users    = $wpdb->prefix . 'users';
	$table_usermeta = $wpdb->prefix . 'usermeta';
	$sql_str        = "SELECT user_id,user_login,meta_key,meta_value FROM {$table_usermeta} UM INNER JOIN {$table_users} U ON U.ID = UM.user_id ";

	$sql_str .= ' WHERE 1=1 ';

	if ( learndash_is_group_leader_user() && ! learndash_is_admin_user() ) {
		$course_ids = learndash_get_group_leader_groups_courses();
		$user_ids   = learndash_get_group_leader_groups_users();
		$format     = implode( ', ', $user_ids );
		$sql_str    .= " AND ( U.ID IN ({$format}) )";
		$course_ids = learndash_get_group_leader_groups_courses();
		$lesson_ids = get_posts( array(
			'post_type'      => 'lesson',
			'posts_per_page' => - 1,
			'meta_key'       => 'course_id',
			'meta_value'     => $course_ids,
			'fields'         => 'ids',
		) );
		$topic_ids  = get_posts( array(
			'post_type'      => 'topics',
			'posts_per_page' => - 1,
			'meta_key'       => 'lesson_id',
			'meta_value'     => $lesson_ids,
			'fields'         => 'ids',
		) );
		$quiz_ids   = get_posts( array(
			'post_type'      => 'sfwd-quiz',
			'posts_per_page' => - 1,
			'meta_key'       => 'course_id',
			'meta_value'     => $course_ids,
			'fields'         => 'ids',
		) );

		if ( isset( $args['tlms_at_post_type'] ) && ! empty( $args['tlms_at_post_type'] ) && $args['tlms_at_post_type'] == 'courses' ) {
			if ( $course_ids ) {
				$sql_str .= " AND ( ";
				$count   = 0;
				foreach ( $course_ids as $course_id ) {
					if ( $count == 0 ) {
						$sql_str .= " meta_key='tlms_at_time_log_course_{$course_id}'";
					} else {
						$sql_str .= "OR meta_key='tlms_at_time_log_course_{$course_id}'";
					}
					$count ++;
				}
				$sql_str .= " ) ";
			}
		} else if ( isset( $args['tlms_at_post_type'] ) && ! empty( $args['tlms_at_post_type'] ) && $args['tlms_at_post_type'] == 'lesson' ) {

			if ( $lesson_ids ) {
				$sql_str .= " AND ( ";
				$count   = 0;
				foreach ( $lesson_ids as $lesson_id ) {
					if ( $count == 0 ) {
						$sql_str .= " meta_key='tlms_at_time_log_lesson_{$lesson_id}'";
					} else {
						$sql_str .= " OR meta_key='tlms_at_time_log_lesson_{$lesson_id}'";
					}
					$count ++;
				}
				$sql_str .= " ) ";
			}

		} else if ( isset( $args['tlms_at_post_type'] ) && ! empty( $args['tlms_at_post_type'] ) && $args['tlms_at_post_type'] == 'topics' ) {

			if ( $topic_ids ) {
				$sql_str .= " AND ( ";
				$count   = 0;
				foreach ( $topic_ids as $topic_id ) {
					if ( $count == 0 ) {
						$sql_str .= " meta_key='tlms_at_time_log_topic_{$topic_id}'";
					} else {
						$sql_str .= " OR meta_key='tlms_at_time_log_topic_{$topic_id}'";
					}
					$count ++;
				}
				$sql_str .= " ) ";
			}

		} else if ( isset( $args['tlms_at_post_type'] ) && ! empty( $args['tlms_at_post_type'] ) && $args['tlms_at_post_type'] == 'sfwd-quiz' ) {

			if ( $quiz_ids ) {
				$sql_str .= " AND ( ";
				$count   = 0;
				foreach ( $quiz_ids as $quiz_id ) {
					if ( $count == 0 ) {
						$sql_str .= " meta_key='tlms_at_time_log_quiz_{$quiz_id}'";
					} else {
						$sql_str .= " OR meta_key='tlms_at_time_log_quiz_{$quiz_id}'";
					}
					$count ++;
				}
				$sql_str .= " ) ";
			}

		} else {
			$course_ids_modified = array();
			if ( $course_ids ) {
				foreach ( $course_ids as $key => $value ) {
					$course_ids_modified[ $value ] = 'course';
				}
			}
			$lesson_ids_modified = array();
			if ( $lesson_ids ) {
				foreach ( $lesson_ids as $key => $value ) {
					$lesson_ids_modified[ $value ] = 'lesson';
				}
			}
			$topic_ids_modified = array();
			if ( $topic_ids ) {
				foreach ( $topic_ids as $key => $value ) {
					$topic_ids_modified[ $value ] = 'topic';
				}
			}
			$quiz_ids_modified = array();
			if ( $quiz_ids ) {
				foreach ( $quiz_ids as $key => $value ) {
					$quiz_ids_modified[ $value ] = 'quiz';
				}
			}

			$all_ids = $course_ids_modified + $lesson_ids_modified + $topic_ids_modified + $quiz_ids_modified;

			if ( $all_ids ) {
				$sql_str .= " AND ( ";
				$count   = 0;
				foreach ( $all_ids as $key => $value ) {
					if ( $value == "course" ) {
						if ( $count == 0 ) {
							$sql_str .= " meta_key='tlms_at_total_time_log_{$value}_{$key}'";
						} else {
							$sql_str .= " OR meta_key='tlms_at_total_time_log_{$value}_{$key}'";
						}
					} else {
						if ( $count == 0 ) {
							$sql_str .= " meta_key='tlms_at_time_log_{$value}_{$key}'";
						} else {
							$sql_str .= " OR meta_key='tlms_at_time_log_{$value}_{$key}'";
						}
					}
					$count ++;
				}
				$sql_str .= " ) ";
			}
			// $sql_str .= " AND (meta_key LIKE 'tlms_at_total_time_log_course_%' OR meta_key LIKE 'tlms_at_time_log_lesson_%' OR meta_key LIKE 'tlms_at_time_log_topic_%' OR meta_key LIKE 'tlms_at_time_log_quiz_%')";
		}
	} else {
		if ( isset( $args['tlms_at_post_type'] ) && ! empty( $args['tlms_at_post_type'] ) && $args['tlms_at_post_type'] == 'courses' ) {
			$sql_str .= " AND meta_key LIKE 'tlms_at_total_time_log_course_%' ";
		} else if ( isset( $args['tlms_at_post_type'] ) && ! empty( $args['tlms_at_post_type'] ) && $args['tlms_at_post_type'] == 'lesson' ) {
			$sql_str .= " AND meta_key LIKE 'tlms_at_time_log_lesson_%' ";
		} else if ( isset( $args['tlms_at_post_type'] ) && ! empty( $args['tlms_at_post_type'] ) && $args['tlms_at_post_type'] == 'topics' ) {
			$sql_str .= " AND meta_key LIKE 'tlms_at_time_log_topic_%' ";
		} else if ( isset( $args['tlms_at_post_type'] ) && ! empty( $args['tlms_at_post_type'] ) && $args['tlms_at_post_type'] == 'sfwd-quiz' ) {
			$sql_str .= " AND meta_key LIKE 'tlms_at_time_log_quiz_%' ";
		} else if ( isset( $args['tlms_at_post_type'] ) and empty( $args['tlms_at_post_type'] ) ) {
			$sql_str .= " AND (meta_key LIKE 'tlms_at_total_time_log_course_%' OR meta_key LIKE 'tlms_at_time_log_lesson_%' OR meta_key LIKE 'tlms_at_time_log_topic_%' OR meta_key LIKE 'tlms_at_time_log_quiz_%')";
		} else {
			$sql_str .= " AND (meta_key LIKE 'tlms_at_total_time_log_course_%' OR meta_key LIKE 'tlms_at_time_log_lesson_%' OR meta_key LIKE 'tlms_at_time_log_topic_%' OR meta_key LIKE 'tlms_at_time_log_quiz_%')";
		}
	}

	if ( ! isset( $args['is_paged'] ) ) {
		$args['is_paged'] = false;
	} else {
		if ( empty( $args['current_page'] ) ) {
			$args['current_page'] = 1;
		}

		if ( empty( $args['per_page'] ) ) {
			$args['per_page'] = get_option( 'posts_per_page' );
		}
	}

	$is_paged = $args['is_paged'];


	if ( $is_paged ) {
		$total_records  = $wpdb->get_var( "SELECT COUNT(1) FROM ({$sql_str}) AS combined_table" );
		$items_per_page = $args['per_page'];
		$current_page   = $args['current_page'];
		$offset         = ( $current_page * $items_per_page ) - $items_per_page;
		$sql_str        .= " LIMIT {$offset}, {$items_per_page}";
	}

	$results = $wpdb->get_results( $sql_str, ARRAY_A );
	if ( ! is_wp_error( $results ) ) {
		if ( $is_paged ) {
			return array(
				'results' => $results,
				'total'   => $total_records,
			);
		}

		return $results;
	}

	return array();
}


/**
 * Checks if Course attendance is disallowed
 *
 * @param int $course_id
 *
 * @return bool
 */
function ld_attendance_is_course_attendance_disallowed( $course_id ) {
	$course_id = learndash_get_course_id( $course_id );

	if ( ! empty( $course_id ) ) {
		$is_checked = get_post_meta( $course_id, 'ldatck1', true );

		return $is_checked == 'on';
	}

	return true;
}

/**
 * Get percentage of the given $count
 *
 * @param int $count
 *
 * @return int
 */
function tlms_attendance_get_percentage( $count ) {
	return round( absint( $count ) / absint( date( 'd' ) ) * 100 );
}

/**
 * Function to recursively search for a given value
 *
 * @param mixed $search_value
 * @param array $array
 * @param mixed $id_path
 *
 * @return mixed
 */
function array_search_id( $search_value, $array, $id_path ) {
	if ( is_array( $array ) && count( $array ) > 0 ) {
		foreach ( $array as $key => $value ) {
			$temp_path = $id_path;
			// Adding current key to search path
			array_push( $temp_path, $key );
			// Check if this value is an array
			// with atleast one element
			if ( is_array( $value ) && count( $value ) > 0 ) {
				$res_path = array_search_id(
					$search_value,
					$value,
					$temp_path
				);

				if ( $res_path != null && $res_path != '' ) {
					return $res_path;
				}
			} elseif ( $value == $search_value ) {
				return $temp_path;
			}
		}
	}

	return null;
}

/**
 * Get lessons of the given course ids
 *
 * @param array $courses_ids
 *
 * @return array
 */
function get_courses_lessons( $courses_ids = array() ) {
	$course_lessons = array();
	foreach ( $courses_ids as $courses_id ) :
		$lessons = learndash_get_course_lessons_list( $courses_id );
		foreach ( $lessons as $lesson ) :
			$course_lessons[] = $lesson['post']->ID;
		endforeach;
	endforeach;

	return $course_lessons;
}

/**
 * Get lessons which do not belong to the given course ids
 *
 * @param array $lessons_ids
 * @param array $courses_ids
 *
 * @return array
 */
function get_lessons_which_are_not_related_to_courses( $lessons_ids = array(), $courses_ids = array() ) {
	$course_lessons                           = get_courses_lessons( $courses_ids );
	$lessons_which_are_not_related_to_courses = array();
	foreach ( $lessons_ids as $lesson_id ) :
		$course_lessons_search_path = array_search_id( $lesson_id, $course_lessons, array() );
		if ( empty( $course_lessons_search_path ) ) {
			$lessons_which_are_not_related_to_courses[] = $lesson_id;
		}
	endforeach;

	return $lessons_which_are_not_related_to_courses;
}

/**
 * Get topics of the given lesson ids
 *
 * @param array $lessons_ids
 *
 * @return array
 */
function get_lessons_topics( $lessons_ids = array() ) {
	$lessons_topics = array();
	foreach ( $lessons_ids as $lessons_id ) :
		global $wpdb;
		$lessons_topics_meta_args = array(
			'meta_query' => array(
				array(
					'key'   => 'lesson_id',
					'value' => $lessons_id,
				),
			),
			'post_type'  => 'topics',
		);
		$topics                   = get_posts( $lessons_topics_meta_args );
		if ( ! empty( $topics ) ) :
			foreach ( $topics as $topic ) :
				$lessons_topics[] = $topic->ID;
			endforeach;
		endif;
	endforeach;

	return $lessons_topics;
}

/**
 * Get topics which do not belong to the given lesson ids
 *
 * @param array $lessons_ids
 * @param array $topics_ids
 *
 * @return array
 */
function get_topics_which_are_not_related_to_lessons( $lessons_ids = array(), $topics_ids = array() ) {
	$lessons_topics                          = get_lessons_topics( $lessons_ids );
	$topics_which_are_not_related_to_lessons = array();
	foreach ( $topics_ids as $topic_id ) :
		$lessons_topics_search_path = array_search_id( $topic_id, $lessons_topics, array() );
		if ( empty( $lessons_topics_search_path ) ) {
			$topics_which_are_not_related_to_lessons[] = $topic_id;
		}
	endforeach;

	return $topics_which_are_not_related_to_lessons;
}

if ( ! function_exists( "dd" ) ) {
	function dd( $data, $exit_data = true ) {
		echo '<pre>' . print_r( $data, true ) . '</pre>';
		if ( $exit_data == false ) {
			echo '';
		} else {
			exit;
		}
	}
}

if ( ! function_exists( 'tlms_att_get_default_settings' ) ) {
	function tlms_att_get_default_settings() {
		return array(
			'tlms_att_debug_log'    => 0,
			'tlms_att_activity_log' => 0,
		);
	}
}

if ( ! function_exists( 'tlms_att_get_settings' ) ) {
	function tlms_att_get_settings() {
		$default_settings = tlms_att_get_default_settings();
		$settings         = get_option( 'tlms_attendance_settings', array() );
		$settings         = wp_parse_args( $settings, $default_settings );

		return $settings;
	}
}
<?php
/**
 * Functions - bbPress + BuddyPress
 * 
 * @package Vikinger
 * 
 * @since 1.9.1
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

/**
 * Filters
 */
require_once VIKINGER_PATH . '/includes/functions/bbpress/bbpress-buddypress/vikinger-functions-bbpress-buddypress-filters.php';

?>
<?php
/**
 * License Options
 */

defined( "ABSPATH" ) || exit;

//( new Error_Log() )->display(); exit;

?>
<div class="lt-at-error-logs tlm-atd-panel">
    <h2><?php esc_html_e( 'Debug Log', 'tutor-lms-attendance' ); ?></h2>


    <div class="tatd-row-debug">
    <p>
        <?php
        printf(
        // Translators: placeholder is a link to WP_DEBUG documentation.
            esc_html__( '%s debug logs allows WooNinja\'s support team to identify the issue easily.', 'tutor-lms-attendance' ),
            __('TutorLMS Attendance', 'tutor-lms-attendance')
        );
        ?>
    </p>
    </div>
    
    <div class="error-log-info" style="margin-top: 1rem;">
        <a class="ld-qie-debug-clear-button" href="<?php echo add_query_arg( array( 'page' => 'tlms-attendance', 'tab' => 'debug_log', 'action' => 'download' ), admin_url( 'admin.php' ) );?>"><?php _e('Download', 'tutor-lms-attendance'); ?></a>
    </div>
</div>
<?php
/**
 * Vikinger Template - BuddyPress Member Profile Settings
 * 
 * Displays profile settings template
 * 
 * @package Vikinger
 * @since 1.0.0
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

?>

<!-- PROFILE SETTINGS SCREEN -->
<div id="profile-settings-screen"></div>
<!-- /PROFILE SETTINGS SCREEN -->
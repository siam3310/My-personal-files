<?php
set_time_limit(0);
ini_set("memory_limit", "512M");

if (!isset($_GET['url'])) exit("Missing url");

$url = $_GET['url'];

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$cookieFile = sys_get_temp_dir() . "/hls_cookie.txt";

/* -------- CURL FETCH -------- */
function curlFetch($url, $cookieFile) {
    $headers = [];

    if (!empty($_SERVER['HTTP_RANGE'])) {
        $headers[] = "Range: " . $_SERVER['HTTP_RANGE'];
    }

    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_ENCODING => "",
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_USERAGENT =>
            $_SERVER['HTTP_USER_AGENT'] ?? "Mozilla/5.0",
        CURLOPT_REFERER => $url,
        CURLOPT_COOKIEJAR => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_HTTPHEADER => $headers
    ]);

    $data = curl_exec($ch);
    $info = curl_getinfo($ch);
    curl_close($ch);

    return [$data, $info];
}

list($data, $info) = curlFetch($url, $cookieFile);

if (!$data) exit("Fetch failed");

$contentType = $info["content_type"] ?? "";
$finalUrl = $info["url"];

/* -------- PLAYLIST -------- */
if (str_contains($contentType, "mpegurl") ||
    str_contains($finalUrl, ".m3u8")) {

    header("Content-Type: application/vnd.apple.mpegurl");

    $parsed = parse_url($finalUrl);

    $schemeHost =
        $parsed["scheme"] . "://" . $parsed["host"] .
        (isset($parsed["port"]) ? ":" . $parsed["port"] : "");

    $basePath = substr($parsed["path"], 0,
        strrpos($parsed["path"], "/") + 1);

    $self =
        (isset($_SERVER['HTTPS']) ? "https://" : "http://") .
        $_SERVER['HTTP_HOST'] .
        strtok($_SERVER["REQUEST_URI"], '?');

    $lines = explode("\n", $data);
    $out = [];

    foreach ($lines as $line) {
        $trim = trim($line);

        /* rewrite key URI */
        if (str_contains($line, 'URI="')) {
            $line = preg_replace_callback(
                '/URI="([^"]+)"/',
                function ($m) use ($schemeHost, $basePath, $self) {
                    $u = $m[1];

                    if ($u[0] === "/")
                        $u = $schemeHost . $u;
                    elseif (!preg_match("/^https?:/", $u))
                        $u = $schemeHost . $basePath . $u;

                    return 'URI="' .
                           $self . '?url=' .
                           urlencode($u) . '"';
                },
                $line
            );

            $out[] = $line;
            continue;
        }

        if ($trim === "" || $trim[0] === "#") {
            $out[] = $line;
            continue;
        }

        /* segment fix */
        if ($trim[0] === "/") {
            $trim = $schemeHost . $trim;
        } elseif (!preg_match("/^https?:\/\//", $trim)) {
            $trim = $schemeHost . $basePath . $trim;
        }

        $out[] = $self . "?url=" . urlencode($trim);
    }

    echo implode("\n", $out);
    exit;
}

/* -------- SEGMENTS -------- */
header("Content-Type: " . $contentType);
echo $data;
exit;

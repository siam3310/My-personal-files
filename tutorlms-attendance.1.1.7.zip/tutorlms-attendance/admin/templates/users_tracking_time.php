<?php

/**
 * test
 * This file is used to Create the announcement table list.
 *
 * @package     LearnDash-Announcement
 * @since       1.0.0
 *
 * @package    LearnDash-Announcement
 * @subpackage LearnDash-Announcement/includes
 */

// Ensure this file is loaded in the WordPress admin
if (!defined('ABSPATH') || !is_admin()) {
    exit;
}

// Include necessary files for WP_List_Table
if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

class User_Time_Tacking_Table extends WP_List_Table
{
    public function get_table_classes()
    {
        return array('widefat', 'fixed', $this->_args['plural'], 'attendance_logs user_tracking_table');
    }
    public function __construct()
    {
        parent::__construct(array(
            'singular' => __('item', 'tutor-lms-attendance'),
            'plural'   => __('items', 'tutor-lms-attendance'),
            'ajax'     => false
        ));
    }

    public function column_default($item, $column_name)
    {
        return $item[$column_name];
    }

    public function get_columns()
    {
        $columns = array(
            'user_id'         => __('User ID', 'tutor-lms-attendance'),
            'user_name'       => __('User Name','tutor-lms-attendance'),
            'login_time_date' => __('Login Time/Date','tutor-lms-attendance'),
            'logout_time_date' => __('Logout Time/Date','tutor-lms-attendance'),
        );

        return $columns;
    }
    function get_sortable_columns()
    {
        $sortable_columns = array(
            'user_id'     => array('user_id', true),     //true means it's already sorted
            'user_name'    => array('user_name', true),
            'login_time_date'  => array('login_time_date', true),
            'logout_time_date'  => array('logout_time_date', true)
        );
        return $sortable_columns;
    }

    public function prepare_items()
    {
        $per_page     = 10;
        $current_page = $this->get_pagenum();
        
        $offset = ($current_page - 1) * $per_page;
        $args = array(
            'offset' => $offset,
            'number' => $per_page,
        );

        $columns               = $this->get_columns();
        $hidden                = array();
        $sortable              = $this->get_sortable_columns();
        $this->_column_headers = array($columns, $hidden, $sortable);

        $data = $this->get_data($args);

        $orderby = isset($_GET['orderby']) ? $_GET['orderby'] : 'user_id';
        $order   = isset($_GET['order']) ? $_GET['order'] : 'asc';

        usort($data, array($this, 'usort_reorder'));

        // if ($order === 'desc') {
        //     $data = array_reverse($data);
        // }

        $this->items = $data;
        $this->set_pagination_args(array(
            'total_items' => $this->get_total_items(),
            'per_page'    => $per_page,
        ));
    }

    public function get_total_items()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'tlms_timetrack_logs';
        $data = $wpdb->get_results( 'SELECT * FROM ' . $table_name. ';');
        return count($data);
    }
    public function create_table(){
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table_name = $wpdb->prefix . 'tlms_timetrack_logs';
        $sql = "CREATE TABLE `{$table_name}` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `user_id` int(11) NOT NULL,
            `login_time` datetime DEFAULT NULL,
            `logout_time` datetime DEFAULT NULL,
            `ip_address` text DEFAULT NULL,
            PRIMARY KEY (`id`)
            ) $charset_collate;";
        $wpdb->query( $sql );
        return true;
    }
    public function get_data($args = array())
    {
        $result     = array();
            
        global $wpdb;
        $table_name = $wpdb->prefix . 'tlms_timetrack_logs';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) != $table_name ) {
            $upgrade_db = $this->create_table();
        }
        $data = $wpdb->get_results( 'SELECT * FROM ' . $table_name. ' ORDER BY id DESC LIMIT '.$args['number'].' OFFSET '.$args['offset'].'');
        foreach($data as $tracker){
            if( $tracker->login_time != null ){
                $user = get_user_by('id', $tracker->user_id);

                $result[] = array(
                    'user_id'          => $user->data->ID,
                    'user_name'        => $user->data->user_login,
                    'login_time_date'  => $tracker->login_time,
                    'logout_time_date' => $tracker->logout_time ?? __('Currently Active', 'tutor-lms-attendance'),
                );
            }
        }
        

        return $result;
    }

    public function usort_reorder($a, $b)
    {
        $orderby = isset($_GET['orderby']) ? $_GET['orderby'] : 'user_id';
        $order   = isset($_GET['order']) ? $_GET['order'] : 'asc';
        
        error_log('a[' . $orderby . '] = ' . $a[$orderby]);
        error_log('b[' . $orderby . '] = ' . $b[$orderby]);
        $result = strcmp( $a[$orderby], $b[$orderby] );
        // Send final sort direction to usort
        return ( $order === 'asc' ) ? $result : -$result;
    }
}

$User_Time_Tacking_Table = new User_Time_Tacking_Table();
$User_Time_Tacking_Table->prepare_items();
echo "<div class='user_container'><h2>";
_e('Users Tracking Time', 'tutor-lms-attendance');
echo "</h2>";
$User_Time_Tacking_Table->display();
echo "</div>";

function is_user_inactive($user_id) {
    $last_activity = get_user_meta($user_id, 'last_activity', true);
    $inactive_threshold = 5 * 60; // 5 minutes in seconds

    if ($last_activity && (time() - $last_activity) > $inactive_threshold) {
        return true; // User is inactive (consider them logged out)
    }
    return false; // User is still active
}
# Movie Streaming and Downloading Website
A Website that allows downloading and online streaming of movies.

## Roles:
* Admin
* User

## Functionality:
* Admin adds the data of movies.
* Simple Searching and Filter Searching.
* Shows the information about movie.
* Allows Downloading and Online Streaming


## Programming Environment:

### Front End:
HTML5, CSS3, JavaScript, jQuery v3.5.1, Bootstrap v4.5.0

### Back End:
PHP v7.2

### Database:
Maria DB

<?php
$timeTrackListTable = new LDAT_Time_Track_List_Table();
$timeTrackListTable->prepare_items();
$view_type = $timeTrackListTable->get_view_type();
?>
<div id="ldat-report-table-wrap" style="overflow-x: scroll;
    width: 98%;margin: 10px 20px 0 2px;">
    <h2><?php _e('LearnDash Time Logs', 'tutor-lms-attendance' ); ?></h2>

    <form id="attendance-logs-filter" method="get">
        <input type="hidden" name="tab" value="time_track"/>
        <input type="hidden" name="page" value="learndash_lms-ldat"/>
		<?php if ( ! isset( $_REQUEST['action'] ) || $_REQUEST['action'] != 'view_detail_logs' ): ?>

			<?php $timeTrackListTable->views(); ?>

			<?php if ( $view_type == 'user' ): ?>
                <div class="alignright actions ">
                    <?php $timeTrackListTable->search_box( __( 'Search User', 'tutor-lms-attendance' ), 'search_id'); ?>
                </div>
			<?php endif; ?>

		<?php endif; ?>

		<?php $timeTrackListTable->display() ?>
    </form>
</div>
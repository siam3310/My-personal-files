<?php
/**
 * Vikinger Template - BuddyPress Member Notification Settings
 * 
 * Displays notification settings template
 * 
 * @package Vikinger
 * @since 1.0.0
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

?>

<!-- NOTIFICATION SETTINGS SCREEN -->
<div id="notifications-settings-screen"></div>
<!-- /NOTIFICATION SETTINGS SCREEN -->
<?php

/**
 * Frontend Wishlist Page
 *
 * @package Tutor\Templates
 * @subpackage Dashboard
 * @author Themeum <support@themeum.com>
 * @link https://themeum.com
 * @version 1.4.3
 */
$options = get_option( 'tlms_at_options', array());
if( isset($options['tlms_at_user_celendar']) && $options['tlms_at_user_celendar'] == 'on' ) {


global $wpdb;
$table_name = $wpdb->prefix . 'tlms_attendance_logs';
$user_current_id = get_current_user_id();

$result = $wpdb->get_results("SELECT * FROM {$table_name} where user_id = $user_current_id");
$calendar_attendance_data = [];

if (is_array($result) && count($result) != 0) {
    foreach ($result as $attendance_data) {
        if ($attendance_data->course_id != '0') {
            $post_title = get_the_title($attendance_data->course_id);
        } else if ($attendance_data->lesson_id != '0') {
            $post_title = get_the_title($attendance_data->lesson_id);
        } else if ($attendance_data->topic_id != '0') {
            $post_title = get_the_title($attendance_data->topic_id);
        } else if ($attendance_data->quiz_id != '0') {
            $post_title = get_the_title($attendance_data->quiz_id);
        }

        $title =  $attendance_data->attendance_type . ' in ' . $post_title;
        $attendance_date  = explode(" ", $attendance_data->created_at);
        $att_type         = strtoupper($attendance_data->attendance_type);
        $calendar_array   = ['title' => $att_type, 'date' => $attendance_date[0], "backgroundColor" => "green",  "textColor" => "white",];
        // array_push($calendar_attendance_data, $calendar_array);
    }
}
$calendar_attendance_data = json_encode($calendar_attendance_data);
$course_list = get_posts([
    'post_type' => 'courses',
    'post_status' => 'publish',
    'numberposts' => -1
    // 'order'    => 'ASC'
]);
// error_log('course_list:' . var_export($course_list, true));
?>

<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/core@4.2.0/main.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@4.2.0/main.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fullcalendar/interaction@4.2.0/main.js"></script>
<link href="https://cdn.jsdelivr.net/npm/@fullcalendar/core@4.2.0/main.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<div class="tutor-fs-5 tutor-fw-medium tutor-color-black tutor-mb-24"><?php esc_html_e('Attendance', 'tutor'); ?></div>
<div>
    <label for="tlmd-at-course-list">Course List</label>
    <select class="tlmd-at-course-list">
        <option> Select Course </option>
        <?php
        foreach ($course_list as $course) {
            echo '<option value="' . $course->ID . '">' . $course->post_title . '</option>';
        }
        ?>
    </select>
</div>
<div id="calendar"></div>
<!-- <script>
    document.addEventListener('DOMContentLoaded', function() {

        //send request when page load and get data of student

        //End request code here
        var calendarEl = document.getElementById('calendar');

        var calendar = new FullCalendar.Calendar(calendarEl, {
            height: 600,
            plugins: ['dayGrid', 'interaction'],

            dateClick: function(info) {
                calendar.refetchEvents();
            },

            eventClick: function(info) {
                alert(info.event.title)
            },

            events: function(info, successCallback, failureCallback) {
                jQuery(document).on('change', '.tlmd-at-course-list', function() {

                    var output = [];
                    var course_id = jQuery(this).val();
                    jQuery.ajax({
                        url: '<?php //echo admin_url('admin-ajax.php'); 
                                ?>',
                        type: "POST",
                        data: {
                            action: 'tlms_at_get_attendance_data',
                            course_id: course_id,
                        },
                        success: function(response) {

                            console.log(response);
                            
                            successCallback(response);
                            


                        }
                    })
                })

            }
        });

        calendar.render();
    });
</script> -->

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');

        var calendar = new FullCalendar.Calendar(calendarEl, {
            height: 600,
            plugins: ['dayGrid', 'interaction'],

            eventClick: function(info) {
                alert(info.event.title);
            },

            events: function(info, successCallback, failureCallback) {
                var output = [];

                jQuery(document).off('change', '.tlmd-at-course-list').on('change', '.tlmd-at-course-list', function() {
                    var course_id = jQuery(this).val();

                    jQuery.ajax({
                        url: '<?php echo admin_url('admin-ajax.php'); ?>',
                        type: "POST",
                        data: {
                            action: 'tlms_at_get_attendance_data',
                            course_id: course_id,
                        },
                        success: function(response) {
                            console.log(response);
                            successCallback(response);

                            // Trigger a refetch of events after updating
                            calendar.refetchEvents();
                        },
                        error: function(error) {
                            console.error('Error fetching events:', error);
                            failureCallback(error);
                        }
                    });
                });
            }
        });

        calendar.render();
    });
</script>
<?php
}else{
    ?>
        <h3><?php _e('No Access, ask administrator to grant access.'); ?></h3>
    <?php
}
?>
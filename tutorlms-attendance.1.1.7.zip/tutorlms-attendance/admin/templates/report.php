<?php
$attendanceLogListTable = new tlms_at_LOG_List_Table();
$attendanceLogListTable->prepare_items();
$view_type = $attendanceLogListTable->get_view_type();
?>
<div id="tlms_at-report-table-wrap" class="tlm-atd-panel">
    <h2><?php _e('Tutor LMS Attendance Logs', 'tutor-lms-attendance' ); ?></h2>

    <form id="attendance-logs-filter" method="get">
        <input type="hidden" name="tab" value="report"/>
        <input type="hidden" name="page" value="tlms-attendance"/>
		<?php if ( ! isset( $_REQUEST['action'] ) || $_REQUEST['action'] != 'view_detail_logs' ): ?>
			<?php $attendanceLogListTable->views(); ?>
			<?php if ( $view_type == 'user' ): ?>
                <div class="alignright actions ">
                    <?php $attendanceLogListTable->search_box( __( 'Search User', 'tutor-lms-attendance' ), 'search_id'); ?>
                </div>
			<?php endif; ?>

		<?php endif; ?>

		<?php $attendanceLogListTable->display() ?>
    </form>
</div>

<!-- The Modal -->
<div id="tut_atd_Modal" class="tut-atd-modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <div class="tut-atd-wrap">
        <h4 class="tut-atd-h"><?php esc_attr_e('Action Notice'); ?></h4>
        <p class="clearlogs-title">Are you sure, this action will delete attendance logs of all users.</p>
        <p style="text-align:center">
        <button type="button" class="tut-atd-btn" id="clearLogsYes">Yes</button>
        </p>
    </div>
  </div>

</div>
<div class="reset_spinner" style="display:none">
    <div></div>
</div>
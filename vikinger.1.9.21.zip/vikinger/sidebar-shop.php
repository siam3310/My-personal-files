<?php
/**
 * Vikinger Sidebar - Sidebar Shop
 * 
 * WooCommerce shop sidebar
 * 
 * @package Vikinger
 * @since 1.6.4
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

  if (is_active_sidebar('shop')) {
    dynamic_sidebar('shop');
  }
  
?>
<?php
/**
 * Functions - VKMedia + BuddyPress
 * 
 * @package Vikinger
 * 
 * @since 1.9.1
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

/**
 * Actions
 */
require_once VIKINGER_PATH . '/includes/functions/vkmedia/vkmedia-buddypress/vikinger-functions-vkmedia-buddypress-actions.php';

?>
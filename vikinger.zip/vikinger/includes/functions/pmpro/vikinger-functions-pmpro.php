<?php
/**
 * Functions - Paid Memberships Pro
 * 
 * @package Vikinger
 * 
 * @since 1.9.1
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

/**
 * Global
 */
require_once VIKINGER_PATH . '/includes/functions/pmpro/vikinger-functions-pmpro-global.php';

/**
 * BuddyPress
 */
require_once VIKINGER_PATH . '/includes/functions/pmpro/vikinger-functions-pmpro-buddypress.php';

?>
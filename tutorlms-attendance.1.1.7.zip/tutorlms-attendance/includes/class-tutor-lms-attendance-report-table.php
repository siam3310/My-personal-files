<?php
if (!class_exists('WP_List_Table')) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class tlms_at_LOG_List_Table extends WP_List_Table
{

	function __construct()
	{
		global $status, $page;

		// Set parent defaults
		parent::__construct(
			array(
				'singular' => 'attendance_log',
				'plural'   => 'attendance_logs',
				'ajax'     => false,
				'screen'   => '',
			)
		);
	}
	function column_default($item, $column_name)
	{
		switch ($column_name) {
			case 'post_title':
			case 'ip_address':
			case 'device_id':
			case 'log_by_user_id':
			case 'attendance_count':
				return $item[$column_name];

			case 'user_login':
			case 'admin_user_login':
				$user_id_key = ($column_name === 'user_login') ? 'user_id' : 'log_by_user_id';
				$user_id     = $item[$user_id_key];

				return sprintf('<a href="%s">%s</a>', admin_url('/user-edit.php?user_id=' . $user_id), $item[$column_name]);

			case 'comment':
				$title        = sprintf(__('Remarks %s %s %s', 'tutor-lms-attendance'), $item['post_title'], $item['user_login'], $item['created_at']);
				$comment      = str_replace("\\'", "'", $item[$column_name]);
				$div_content  = sprintf('<div id="comment_%s" style="display:none"><div style="padding: 10px;">%s</div></div>', $item['id'], $comment);
				$trimmed_text = wp_trim_words($comment, 35);
				$view_text 	  = __('view', 'tutor-lms-attendance');
				$more_link    = sprintf(' <a href="#TB_inline?width=400&height=300&inlineId=comment_%s" title="%s" class="thickbox">%s</a>', $item['id'], $title, $view_text);

				if (!empty($trimmed_text)) {
					return $trimmed_text . $more_link . wpautop($div_content, true);
				} else {
					return '';
				}

			case 'created_at':
				$date_format = get_option('date_format') . ' ' . get_option('time_format');

				return date($date_format, strtotime($item[$column_name]));

			default:
				return $item[$column_name];
		}
	}

	function column_post_type($item)
	{
		$post_types_map = [
			'courses' => 'Course',
			'lesson'  => 'Lesson',
			'topics'  => 'Topic',
		];

		$post_type = '';

		if (isset($item['post_type']) && array_key_exists($item['post_type'], $post_types_map)) {
			$post_type = sprintf(
				esc_html_x(
					'%s',
					'placeholder: ' . $post_types_map[$item['post_type']],
					'tutor-lms-attendance'
				),
				$post_types_map[$item['post_type']]
			);
		}

		return $post_type;
	}

	function column_attendance_count($item)
	{

		if (isset($_REQUEST['action']) && $_GET['action'] == 'view_detail_logs') {

			return $item['attendance_count'];
		}

		$url = remove_query_arg(array(
			'_wp_http_referer',
			'_wpnonce',
			'action',
			'view_type',
			'course_id',
			'user_id',
			'paged'
		));
		$url = add_query_arg('action', 'view_detail_logs', $url);
		if (isset($_REQUEST['view_type'])) {
			$view_type = $_REQUEST['view_type'];

			if (in_array($view_type, array('course', 'lesson', 'topic'))) {
				$url = add_query_arg($view_type . '_id', $item[$view_type . '_id'], $url);
			} elseif ($view_type == 'absent') {
				if (isset($item['post_type']) && in_array($item['post_type'], array(
					'courses',
					'lessons',
					'topics'
				))) {
					$url = add_query_arg('post_type', $item['post_type'], $url);
					$url = add_query_arg($item['post_type'] . '_id', $item[$item['post_type'] . '_id'], $url);
				}
			}
		} elseif (empty($_REQUEST['view_type'])) {
			if (isset($item['post_type']) && in_array($item['post_type'], array(
				'courses',
				'lessons',
				'topics'
			))) {				
				$singular_post_type = rtrim($item['post_type'], 's');
				
				$url                = add_query_arg($singular_post_type . '_id', $item[$singular_post_type . '_id'], $url);
				$url                = add_query_arg('view_type', $singular_post_type, $url);
			}
		}

		$url = add_query_arg('user_id', $item['user_id'], $url);
		// $url = add_query_arg( 'tlms_at_attendance_type', $item['attendance_type'], $url );

		$view_type = $this->get_view_type();
		if ($view_type) {
			$url = add_query_arg('view_type', $view_type, $url);
		} else {
			$url       = add_query_arg('view_type', 'all', $url);
			$view_type = 'all';
		}

		if ($view_type == 'all') {
			if (isset($item['course_id']) && !empty($item['course_id'])) {
				$url = add_query_arg('course_id', $item['course_id'], $url);
			}

			if (isset($item['lesson_id']) && !empty($item['lesson_id'])) {
				$url = add_query_arg('lesson_id', $item['lesson_id'], $url);
			}

			if (isset($item['topic_id']) && !empty($item['topic_id'])) {
				$url = add_query_arg('topic_id', $item['topic_id'], $url);
			}
		}


		// Build row actions
		$actions = array(
			'view' => sprintf('<a href="%s">%s</a>', $url, __('View Detail Logs', 'tutor-lms-attendance')),
		);

		// Return the title contents
		return sprintf(
			'%1$s %2$s',
			/*$1%s*/
			$item['attendance_count'],
			/*$2%s*/
			$this->row_actions($actions)
		);
	}


	function column_cb($item)
	{
		return sprintf(
			// '<input type="checkbox" name="%1$s[]" value="%2$s" />',
			/*$1%s*/
			$this->_args['singular'],
			/*$2%s*/
			$item['id']
		);
	}

	function get_columns()
	{
		$view_type = $this->get_view_type();

		static $log_message_displayed = false;
		if (!$log_message_displayed) {
			(new Tutor_Lms_DEBUG())->log_message('Viewing attendance details..', 'tutor-lms-attendance');
			$log_message_displayed = true; // Set the flag to true
		}

		if ($view_type == 'absent' || $view_type == 'all') {
			if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'view_detail_logs') {

				$columns = array(
					// 'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
					'post_title'      => __('Title', 'tutor-lms-attendance'),
					'post_type'       => __('Post Type', 'tutor-lms-attendance'),
					'user_login'      => __('Username', 'tutor-lms-attendance'),
					'ip_address'      => __('IP Address', 'tutor-lms-attendance'),
					'device_id'       => __('Device ID', 'tutor-lms-attendance'),
					'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'created_at'      => __('Log Date', 'tutor-lms-attendance'),
					// 'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'comment'         => __('Remarks', 'tutor-lms-attendance'),
				);
			} else {
				$columns = array(
					// 'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
					'post_title'       => __('Title', 'tutor-lms-attendance'),
					'post_type'        => __('Post Type', 'tutor-lms-attendance'),
					'user_login'       => __('Username', 'tutor-lms-attendance'),
					// 'comment' => __('Remarks', 'tutor-lms-attendance'),
					'attendance_count' => __('Count', 'tutor-lms-attendance'),
					// 'admin_user_login' => __('Mark By', 'tutor-lms-attendance'),
				);
			}
		} elseif ($view_type == 'user') {
			if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'view_detail_logs') {
				$columns = array(
					// 'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
					'post_title'      => __('Title', 'tutor-lms-attendance'),
					'post_type'       => __('Post Type', 'tutor-lms-attendance'),
					'user_login'      => __('Username', 'tutor-lms-attendance'),
					'ip_address'      => __('IP Address', 'tutor-lms-attendance'),
					'device_id'       => __('Device ID', 'tutor-lms-attendance'),
					'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'created_at'      => __('Log Date', 'tutor-lms-attendance'),
					// 'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'comment'         => __('Remarks', 'tutor-lms-attendance'),
				);
			} else {
				$columns = array(
					// 'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
					'user_login'       => __('Username', 'tutor-lms-attendance'),
					// 'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'attendance_count' => __('Count', 'tutor-lms-attendance'),
				);
			}
		} elseif ($view_type == 'course') {
			if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'view_detail_logs') {
				$columns = array(
					// 'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
					'post_title'      => sprintf(esc_html_x('%s', 'placeholder: Course', 'tutor-lms-attendance'), ('course')),
					'user_login'      => __('Username', 'tutor-lms-attendance'),
					'ip_address'      => __('IP Address', 'tutor-lms-attendance'),
					'device_id'       => __('Device ID', 'tutor-lms-attendance'),
					'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'created_at'      => __('Log Date', 'tutor-lms-attendance'),
					// 'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'comment'         => __('Remarks', 'tutor-lms-attendance'),
				);
			} else {
				$columns = array(
					// 'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
					'post_title'       => sprintf(esc_html_x('%s', 'placeholder: Course', 'tutor-lms-attendance'), ('course')),
					// 'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'attendance_count' => __('Count', 'tutor-lms-attendance'),
				);
			}
		} elseif ($view_type == 'lesson') {
			if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'view_detail_logs') {
				$columns = array(
					// 'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
					'post_title'      => sprintf(esc_html_x('%s', 'placeholder: Lesson', 'tutor-lms-attendance'), ('lesson')),
					'user_login'      => __('Username', 'tutor-lms-attendance'),
					'ip_address'      => __('IP Address', 'tutor-lms-attendance'),
					'device_id'       => __('Device ID', 'tutor-lms-attendance'),
					'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'created_at'      => __('Log Date', 'tutor-lms-attendance'),
					// 'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'comment'         => __('Remarks', 'tutor-lms-attendance'),
				);
			} else {
				$columns = array(
					// 'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
					'post_title'       => sprintf(esc_html_x('%s', 'placeholder: Lesson', 'tutor-lms-attendance'), ('lesson')),
					// 'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'attendance_count' => __('Count', 'tutor-lms-attendance'),
				);
			}
		} elseif ($view_type == 'topic') {
			if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'view_detail_logs') {
				$columns = array(
					// 'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
					'post_title'      => sprintf(esc_html_x('%s', 'placeholder: Topic', 'tutor-lms-attendance'), ('topic')),
					'user_login'      => __('Username', 'tutor-lms-attendance'),
					'ip_address'      => __('IP Address', 'tutor-lms-attendance'),
					'device_id'       => __('Device ID', 'tutor-lms-attendance'),
					'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'created_at'      => __('Log Date', 'tutor-lms-attendance'),
					// 'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'comment'         => __('Remarks', 'tutor-lms-attendance'),
				);
			} else {
				$columns = array(
					// 'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
					'post_title'       => sprintf(esc_html_x('%s', 'placeholder: Topic', 'tutor-lms-attendance'), ('topic')),
					// 'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
					'attendance_count' => __('Count', 'tutor-lms-attendance'),
				);
			}
		} else {
			$columns = array(
				// 'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
				'post_title'       => __('Title', 'tutor-lms-attendance'),
				'post_type'        => __('Post Type', 'tutor-lms-attendance'),
				'user_login'       => __('Username', 'tutor-lms-attendance'),
				// 'attendance_type' => __('Attendance Type', 'tutor-lms-attendance'),
				'attendance_count' => __('Count', 'tutor-lms-attendance'),
			);
		}

		// }
		return $columns;
	}

	function get_sortable_columns()
	{
		$sortable_columns = array(
			'post_title'       => array('post_title', false),     // true means it's already sorted
			'post_type'        => array('post_type', false),
			'user_login'       => array('user_login', false),
			'attendance_count' => array('attendance_count', true),
		);

		return $sortable_columns;
	}

	function get_bulk_actions()
	{
		return array();
	}

	function process_bulk_action()
	{

		// Detect when a bulk action is being triggered...
		if ('export' === $this->current_action()) {

			$table_data = $this->table_data();
			$results    = $table_data;
			$filename   = 'test.csv';
			ob_start();
			$fh = @fopen('php://output', 'w');
			fprintf($fh, chr(0xEF) . chr(0xBB) . chr(0xBF));
			header('Cache-Control: max-age=0');
			header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
			header('Content-Description: File Transfer');
			header('Content-type: text/csv');
			header("Content-Disposition: attachment; filename={$filename}");
			header('Expires: 0');
			header('Pragma: public');
			$i = 0;
			foreach ($results as $data_row) {
				if ($i == 0) {
					$header_row = array_keys($data_row);
					fputcsv($fh, $header_row);
				}
				fputcsv($fh, $data_row);
				$i++;
			}
			fclose($fh);
			ob_clean();
			die();
		}
	}

	function prepare_items()
	{
		$per_page = 10;
		$columns  = $this->get_columns();
		$hidden   = array();
		$sortable = $this->get_sortable_columns();

		$this->_column_headers = array($columns, $hidden, $sortable);
		$this->process_bulk_action();

		$table_data = $this->table_data(true, $per_page);

		$data = $table_data['results'];
		function usort_reorder($a, $b)
		{
			$orderby = (!empty($_REQUEST['orderby'])) ? $_REQUEST['orderby'] : 'attendance_count'; // If no sort, default to title
			$order   = (!empty($_REQUEST['order'])) ? $_REQUEST['order'] : 'desc'; // If no order, default to asc
			$result  = strcmp($a[$orderby], $b[$orderby]);

			return ($order === 'asc') ? $result : -$result; // Send final sort direction to usort
		}

		usort($data, 'usort_reorder');

		if (isset($table_data['absent_fake_records_availables'])) {
			$total_items = 0;
		} else {
			$total_items = $table_data['total'];
		}

		$this->items = $data;
		$this->set_pagination_args(
			array(
				'total_items' => $total_items,
				'per_page'    => 10,
				'total_pages' => ceil($total_items / $per_page),
			)
		);
	}

	/**
	 * Get the table data
	 *
	 * @return Array
	 */
	public function table_data($is_paged = false, $per_page = 0, $no_group = false)
	{
		$params_map = array(
			's'                       => 'search',
			'course_id'               => 'course_ids',
			'course_category_id'      => 'course_category_id',
			'course_tag_id'           => 'course_tag_id',
			'post_category_id'        => 'post_category_id',
			'post_tag_id'             => 'post_tag_id',
			'tlms_at_date_start'      => 'date_from',
			'tlms_at_date_end'        => 'date_to',
			'orderby'                 => 'order_by',
			'order'                   => 'order',
			'action'                  => 'action',
			'user_id'                 => 'user_ids',
			'user_role'               => 'user_role',
			'tlms_at_attendance_type' => 'attendance_type',
			'lesson_id'               => 'lesson_ids',
			'lesson_category_id'      => 'lesson_category_id',
			'lesson_tag_id'           => 'lesson_tag_id',
			'topic_id'                => 'topic_ids',
			'topic_category_id'       => 'topic_category_id',
			'topic_tag_id'            => 'topic_tag_id',
			'tlms_at_post_type'       => 'tlms_at_post_type',
		);

		$params = array();
		foreach ($params_map as $key => $value) {
			if (isset($_REQUEST[$key])) {
				$params[$value] = $_REQUEST[$key];
			}
		}
		$view_type = $this->get_view_type();

		if (isset($params['action']) && ($params['action'] == 'view_detail_logs' || $params['action'] == 'export_detail_logs')) {
			$params['group_by'] = false;
			if ($view_type == 'course') {
				unset($params['user_role'], $params['search'], $params['user_ids']);
			} elseif ($view_type == 'lesson') {
				unset($params['user_role'], $params['search'], $params['user_ids']);
			} elseif ($view_type == 'topic') {
				unset($params['user_role'], $params['search'], $params['user_ids']);
			} elseif ($view_type == 'user') {
				unset($params['course_ids'], $params['course_category_id'], $params['course_tag_id'], $params['post_category_id'], $params['post_tag_id']);
			} elseif ($view_type == 'absent') {
				$params['attendance_type'] = 'absent';
			}
		} else {
			if ($view_type == 'user') {
				$params['group_by'] = 'user';
				unset($params['course_ids'], $params['course_category_id'], $params['course_tag_id'], $params['post_category_id'], $params['post_tag_id']);
			} elseif ($view_type == 'course') {
				$params['group_by'] = 'course';
				unset($params['user_role'], $params['search'], $params['user_ids']);
			} elseif ($view_type == 'lesson') {
				$params['group_by'] = 'lesson';
				unset($params['user_role'], $params['search'], $params['user_ids']);
			} elseif ($view_type == 'topic') {
				$params['group_by'] = 'topic';
				unset($params['user_role'], $params['search'], $params['user_ids']);
			} elseif ($view_type == 'absent') {
				$params['attendance_type'] = 'absent';
				$params['group_by']        = 'all';
			} else {
				$params['group_by'] = 'all';
			}
		}

		$params['is_paged']     = $is_paged;
		$params['current_page'] = $this->get_pagenum();
		$params['per_page']     = $per_page;
		$params['display_col']  = true;

		$raw_results     = tlms_attendance_get($params);
		$tlms_at_options = get_option('tlms_at_options');

		if (
			isset($tlms_at_options['tlms_at_show_absent_of_unmarked_days']) && $tlms_at_options['tlms_at_show_absent_of_unmarked_days'] == 'on'
			&& ((isset($_REQUEST['tlms_at_date_start']) && !empty($_REQUEST['tlms_at_date_start']))) && $view_type !== 'user'
		) {

			$start = $_GET['tlms_at_date_start'];
			$end   = $_GET['tlms_at_date_end'];
			$diff  = abs(strtotime($start) - strtotime($end)) / (60 * 60 * 24);

			$count = count($raw_results['results']);
			for ($i = 0; $i < $count; $i++) {
				$raw_results['results'][$i]['attendance_count'] = $diff + 1;
			}

			// Function call with passing the start date and end date 
			$dates_in_range = $this->getDatesFromRange($start, $end);

			if (isset($params['action']) && ($params['action'] == 'view_detail_logs' || $params['action'] == 'export_detail_logs')) {
				$raw_results['total']                          = $diff;
				$raw_results['absent_fake_records_availables'] = true;
				for ($i = 0; $i <= $diff; $i++) {
					if (isset($raw_results['results'][$i]) && $raw_results['results'][$i] != null) {
						// remove dates from dates in ranges which already exists in raw_results
						$pos = array_search(date('Y-m-d', strtotime($raw_results['results'][$i]['created_at'])), $dates_in_range);
						unset($dates_in_range[$pos]);
					}
				}

				foreach ($dates_in_range as $key => $value) {
					$raw_results['results'][] = array(
						'id'               => (string) rand(10000, 50000),
						'course_id'        => $raw_results['results'][0]['course_id'],
						'lesson_id'        => $raw_results['results'][0]['lesson_id'],
						'topic_id'         => $raw_results['results'][0]['topic_id'],
						'quiz_id'          => $raw_results['results'][0]['quiz_id'],
						'user_id'          => $raw_results['results'][0]['user_id'],
						'log_by_user_id'   => 1,
						'admin_user_login' => $raw_results['results'][0]['admin_user_login'],
						'post_title'       => $raw_results['results'][0]['post_title'],
						'post_type'        => $raw_results['results'][0]['post_type'],
						'user_login'       => $raw_results['results'][0]['user_login'],
						'ip_address'       => $raw_results['results'][0]['ip_address'],
						'device_id'        => 'desktop',
						'attendance_type'  => 'absent',
						'created_at'       => $value,
						'modified_at'      => $value,
						'attendance_count' => $diff,
						'comment' 			=> __('Unmarked', 'tutor-lms-attendance'),
					);
				}
			}
			update_user_meta(get_current_user_id(), 'unmarked_absents_data', $raw_results['results']);

			return $raw_results;
		}

		return $raw_results;
	}

	// Function to get all the dates in given range 
	function getDatesFromRange($start, $end, $format = 'Y-m-d')
	{

		// Declare an empty array
		$array = array();

		// Variable that store the date interval
		// of period 1 day
		$interval = new DateInterval('P1D');

		$realEnd = new DateTime($end);
		$realEnd->add($interval);

		$period = new DatePeriod(new DateTime($start), $interval, $realEnd);

		// Use loop to store date into array
		foreach ($period as $date) {
			$array[] = $date->format($format);
		}

		// Return the array elements
		return $array;
	}

	function show_taxonomy_selectors()
	{
		$object_taxonomies = get_object_taxonomies('courses');
		// We remove 'category' from the object taxonomies because by now WP has already output it.
		// Maybe at some point we can move the filter earlier
		// $object_taxonomies = array_diff( $object_taxonomies, array( 'category' ) );

		$object_taxonomies = apply_filters('learndash-admin-taxonomy-filters-display', $object_taxonomies, $this->post_type);
		if ((!empty($object_taxonomies)) && (is_array($object_taxonomies))) {
			$tax_slug_map = [
				'post_tag'        => 'post_tag_id',
				'category'        => 'post_category_id',
				'course-tag'      => 'course_tag_id',
				'course-category' => 'course_category_id',
			];
			foreach ($object_taxonomies as $taxonomy_slug) {
				$taxonomy_slug_name = $tax_slug_map[$taxonomy_slug];

				if (isset($_GET[$taxonomy_slug_name])) {
					$selected = esc_attr($_GET[$taxonomy_slug_name]);
				} else {
					$selected = false;
				}

				$dropdown_options = array(
					'taxonomy'          => $taxonomy_slug,
					'name'              => $taxonomy_slug_name,
					'show_option_none'  => get_taxonomy($taxonomy_slug)->labels->all_items,
					'option_none_value' => '',
					'hide_empty'        => 0,
					'hierarchical'      => get_taxonomy($taxonomy_slug)->hierarchical,
					'show_count'        => 0,
					'orderby'           => 'name',
					'value_field'       => 'id',
					'selected'          => $selected,
				);

				echo '<label class="screen-reader-text" for="' . esc_attr($taxonomy_slug) . '">' . sprintf(
					// translators: placeholder: Taxonomy singular name.
					esc_html_x('Filter by %s', 'placeholder: Taxonomy singular name.', 'tutor-lms-attendance'),
					get_taxonomy($taxonomy_slug)->labels->singular_name
				) . '</label>';
				wp_dropdown_categories($dropdown_options);
			}
		}
	}

	public function get_view_type()
	{
		$view_type = (isset($_REQUEST['view_type']) ? $_REQUEST['view_type'] : '');

		if (!empty($view_type) && in_array($view_type, array('user', 'course', 'lesson', 'topic', 'absent'))) {
			return $view_type;
		}

		return $view_type;
	}

	protected function extra_tablenav($which)
	{

		if ('top' !== $which) {
			return;
		}

		$view_type = $this->get_view_type();
?>

		<!--Extra Nav-->
		<div class="alignleft tlms_at-extra-nav">
			<?php
			if ($this->current_action() != 'view_detail_logs') {
				$this->get_tlms_at_attendance_type_dropdown();
			}

			//commented by hassan
			if (empty($view_type) || $view_type == 'all' || $view_type == 'absent') {
				$this->get_tlms_at_post_type_dropdown();
			}

			if ($view_type == 'user') {
				$this->get_user_roles_dropdown();
			} elseif ($view_type == 'course') {
				$this->get_course_dropdown();
				if ($this->current_action() != 'view_detail_logs') {
					$this->show_taxonomy_selectors();
				}
			} elseif ($view_type == 'lesson') {
				$this->get_lesson_dropdown();
				if ($this->current_action() != 'view_detail_logs') {
					$this->get_lesson_taxonomies_dropdown();
				}
			} elseif ($view_type == 'topic') {
				$this->get_topic_dropdown();
				if ($this->current_action() != 'view_detail_logs') {
					$this->get_topic_taxonomies_dropdown();
				}
			}

			$this->get_date_range_picker_field();
			if ($this->current_action() != 'view_detail_logs') {
				submit_button(__('Filter', 'tutor-lms-attendance'), '', 'filter_action', false, array('id' => 'post-query-submit'));
			}
			if ($this->has_items()) {
				if ($this->current_action() == 'view_detail_logs') {
					$this->get_back_button();
				}
				$this->get_export_button();
				$this->export_button();
				$this->get_delete_button();
			}
			?>
			<input type="hidden" name="view_type" value="<?php echo $this->get_view_type(); ?>">
		</div>
		<!--/Extra Nav-->
		<?php
	}

	public function get_user_roles_dropdown()
	{
		global $wp_roles;

		$all_roles = $wp_roles->roles;

		$selected_role = '';
		if (isset($_REQUEST['user_role'])) {
			$selected_role = $_REQUEST['user_role'];
		}

		if (!empty($all_roles)) {

			$action = $this->current_action();
			if ($action != 'view_detail_logs') {
		?>
				<?php echo '<label class="screen-reader-text" for="tlms_at_user_role_filter">' . __('Filter by Role', 'tutor-lms-attendance') . '</label>'; ?>
				<select id="tlms_at_user_role_filter" name="user_role" class="postform">
					<option value=""><?php _e('All Roles', 'tutor-lms-attendance'); ?></option>
					<?php foreach ($all_roles as $role => $role_detail) : ?>
						<option value="<?php echo $role; ?>" <?php selected($selected_role, $role); ?>><?php echo $role_detail['name']; ?></option>
					<?php endforeach; ?>
				</select>
			<?php
			} else {
			?>
				<input type="hidden" id="tlms_at_course_filter" name="user_role" value="<?php echo $selected_role; ?>">
		<?php
			}
		}
	}

	public function get_tlms_at_attendance_type_dropdown()
	{
		$tlms_at_attendance_types    = array(
			'' 			=> __('All Attendance Types', 'tutor-lms-attendance'),
			'present' 	=> __('Present', 'tutor-lms-attendance'),
			'absent' 	=> __('Absent', 'tutor-lms-attendance')
		);
		$tlms_at_attendance_selected = '';
		if (isset($_REQUEST['tlms_at_attendance_type'])) {
			$tlms_at_attendance_selected = $_REQUEST['tlms_at_attendance_type'];
		}
		?>
		<select id="tlms_at_attendance_type_filter" name="tlms_at_attendance_type" class="postform">
			<?php foreach ($tlms_at_attendance_types as $tlms_at_attendance_value => $tlms_at_attendance_type) : ?>
				<option value="<?php echo $tlms_at_attendance_value; ?>" <?php selected($tlms_at_attendance_selected, $tlms_at_attendance_value); ?>><?php echo $tlms_at_attendance_type; ?></option>
			<?php endforeach; ?>
		</select>
		<?php
	}


	public function get_tlms_at_post_type_dropdown()
	{

		$tlms_at_post_types = array(
			sprintf(esc_html_x('%s', 'placeholder: Courses', 'tutor-lms-attendance'), ('courses')) => 'courses',
			sprintf(esc_html_x('%s', 'placeholder: Lessons', 'tutor-lms-attendance'), ('lessons')) => 'lesson',
		);

		$tlms_at_selected_post_type = '';
		if (isset($_REQUEST['tlms_at_post_type'])) {
			$tlms_at_selected_post_type = $_REQUEST['tlms_at_post_type'];
		}

		$action = $this->current_action();

		if ($action != 'view_detail_logs') {
		?>
			<?php echo '<label class="screen-reader-text" for="tlms_at_post_type_filter">' . __('Filter by Post Type', 'tutor-lms-attendance') . '</label>'; ?>
			<select id="tlms_at_post_type_filter" name="tlms_at_post_type" class="postform">
				<option value=""><?php _e('All Post Types', 'tutor-lms-attendance'); ?></option>
				<?php foreach ($tlms_at_post_types as $tlms_at_post_type_name => $tlms_at_post_type_slug) : ?>
					<option value="<?php echo $tlms_at_post_type_slug; ?>" <?php selected($tlms_at_selected_post_type, $tlms_at_post_type_slug); ?>><?php _e($tlms_at_post_type_name, 'tutor-lms-attendance'); ?></option>
				<?php endforeach; ?>
			</select>
		<?php
		} else {
		?>
			<input type="hidden" id="tlms_at_post_type_filter" name="tlms_at_post_type" value="<?php echo $tlms_at_selected_post_type; ?>">
			<?php
		}
	}

	public function get_tlms_at_post_type()
	{
		$tlms_at_post_type = (isset($_REQUEST['tlms_at_post_type']) ? $_REQUEST['tlms_at_post_type'] : '');
		if (!empty($tlms_at_post_type) && in_array(
			$tlms_at_post_type,
			array(
				sprintf(esc_html_x('%s', 'placeholder: Courses', 'tutor-lms-attendance'), ('courses')) => 'courses',
				sprintf(esc_html_x('%s', 'placeholder: Lessons', 'tutor-lms-attendance'), ('lessons')) => 'lesson',
				sprintf(esc_html_x('%s', 'placeholder: Topics', 'tutor-lms-attendance'), ('topics'))  => 'topics',
			)
		)) {
			return $tlms_at_post_type;
		}
	}

	public function get_course_dropdown()
	{
		$args = array(
			'post_type'   => 'courses',
			'post_status' => 'publish',
		);

		$course_query       = new WP_Query($args);
		$selected_course_id = 0;
		if (isset($_REQUEST['course_id'])) {
			$selected_course_id = $_REQUEST['course_id'];
		}

		if ($course_query->have_posts()) {
			$action = $this->current_action();
			if ($action != 'view_detail_logs') {
			?>
				<?php echo '<label class="screen-reader-text" for="tlms_at_course_filter">' . sprintf(esc_html_x('Filter by %s', 'placeholder: Course', 'tutor-lms-attendance'), ('course')) . '</label>'; ?>
				<select id="tlms_at_course_filter" name="course_id" class="postform">
					<option value="0"><?php echo sprintf(esc_html_x('All %s', 'placeholder: Courses', 'tutor-lms-attendance'), ('courses')); ?></option>
					<?php foreach ($course_query->posts as $post) : ?>
						<option value="<?php echo $post->ID; ?>" <?php selected($selected_course_id, $post->ID); ?>><?php echo $post->post_title; ?></option>
					<?php endforeach; ?>
				</select>
			<?php
			} else {
			?>
				<input type="hidden" id="tlms_at_course_filter" name="course_id" value="<?php echo $selected_course_id; ?>">
			<?php
			}
		}
	}

	public function get_lesson_dropdown()
	{
		$args = array(
			'post_type'   => 'lesson',
			'post_status' => 'publish',
		);

		$lesson_query       = new WP_Query($args);
		$selected_lesson_id = 0;
		if (isset($_REQUEST['lesson_id'])) {
			$selected_lesson_id = $_REQUEST['lesson_id'];
		}

		if ($lesson_query->have_posts()) {
			$action = $this->current_action();
			if ($action != 'view_detail_logs') {
			?>
				<?php echo '<label class="screen-reader-text" for="tlms_at_lesson_filter">' . sprintf(esc_html_x('Filter by %s', 'placeholder: Lesson', 'tutor-lms-attendance'), ('lesson')) . '</label>'; ?>
				<select id="tlms_at_lesson_filter" name="lesson_id" class="postform">
					<option value="0"><?php echo sprintf(esc_html_x('All %s', 'placeholder: Lessons', 'tutor-lms-attendance'), ('lessons')); ?></option>
					<?php foreach ($lesson_query->posts as $post) : ?>
						<option value="<?php echo $post->ID; ?>" <?php selected($selected_lesson_id, $post->ID); ?>><?php echo $post->post_title; ?></option>
					<?php endforeach; ?>
				</select>
			<?php
			} else {
			?>
				<input type="hidden" id="tlms_at_lesson_filter" name="lesson_id" value="<?php echo $selected_lesson_id; ?>">
			<?php
			}
		}
	}

	function get_lesson_taxonomies_dropdown()
	{
		echo '<label class="screen-reader-text" for="tlms_at_lesson_category_filter">' . sprintf(esc_html_x('Filter by %s Category', 'placeholder: Lesson', 'tutor-lms-attendance'), ('lesson')) . '</label>';

		echo '<label class="screen-reader-text" for="tlms_at_lesson_tag_filter">' . sprintf(esc_html_x('Filter by %s tag', 'placeholder: Lesson', 'tutor-lms-attendance'), ('lesson')) . '</label>';
	}

	public function get_topic_dropdown()
	{
		$args = array(
			'post_type'   => 'topics',
			'post_status' => 'publish',
		);

		$topic_query       = new WP_Query($args);
		$selected_topic_id = 0;
		if (isset($_REQUEST['topic_id'])) {
			$selected_topic_id = $_REQUEST['topic_id'];
		}

		if ($topic_query->have_posts()) {
			$action = $this->current_action();
			if ($action != 'view_detail_logs') {
				echo '<label class="screen-reader-text" for="tlms_at_topic_filter">' . sprintf(esc_html_x('Filter by %s', 'placeholder: Topic', 'tutor-lms-attendance'), ('topic')) . '</label>'; ?>
				<select id="tlms_at_topic_filter" name="topic_id" class="postform">
					<option value="0"><?php echo sprintf(esc_html_x('All %s ', 'placeholder: Topics', 'tutor-lms-attendance'), ('topics')); ?></option>
					<?php foreach ($topic_query->posts as $post) : ?>
						<option value="<?php echo $post->ID; ?>" <?php selected($selected_topic_id, $post->ID); ?>><?php echo $post->post_title; ?></option>
					<?php endforeach; ?>
				</select>
			<?php
			} else {
			?>
				<input type="hidden" id="tlms_at_topic_filter" name="topic_id" value="<?php echo $selected_topic_id; ?>">
		<?php
			}
		}
	}

	public function get_topic_taxonomies_dropdown()
	{
		$selected_topic_category_id = 0;
		if (isset($_REQUEST['topic_category_id'])) {
			$selected_topic_category_id = $_REQUEST['topic_category_id'];
		}
		$topic_categories = get_terms(
			array(
				'taxonomy'   => 'ld_topic_category',
				'hide_empty' => false,
			)
		);
		?>
		<?php echo '<label class="screen-reader-text" for="tlms_at_topic_category_filter">' . sprintf(esc_html_x('Filter by %s Category', 'placeholder: Topic', 'tutor-lms-attendance'), ('topic')) . '</label>'; ?>
		<select id="tlms_at_topic_category_filter" name="topic_category_id" class="postform">
			<option value="0"><?php echo sprintf(esc_html_x('All %s Categories', 'placeholder: Topics', 'tutor-lms-attendance'), ('topics')); ?></option>
			<?php foreach ($topic_categories as $topic_category) : ?>
				<option value="<?php echo $topic_category->term_id; ?>" <?php selected($selected_topic_category_id, $topic_category->term_id); ?>><?php echo $topic_category->name; ?></option>
			<?php endforeach; ?>
		</select>
		<?php

		$selected_topic_tag_id = 0;
		if (isset($_REQUEST['topic_tag_id'])) {
			$selected_topic_tag_id = $_REQUEST['topic_tag_id'];
		}

		$topic_tags = get_terms(
			array(
				'taxonomy'   => 'ld_topic_tag',
				'hide_empty' => false,
			)
		);
		?>
		<?php echo '<label class="screen-reader-text" for="tlms_at_topic_tag_filter">' . sprintf(esc_html_x('Filter by %s tag', 'placeholder: Topic', 'tutor-lms-attendance'), ('topic')) . '</label>'; ?>
		<select id="tlms_at_topic_tag_filter" name="topic_tag_id" class="postform">
			<option value="0"><?php echo sprintf(esc_html_x('All %s Tags', 'placeholder: Topics', 'tutor-lms-attendance'), ('topics')); ?></option>
			<?php foreach ($topic_tags as $topic_tag) : ?>
				<option value="<?php echo $topic_tag->term_id; ?>" <?php selected($selected_topic_tag_id, $topic_tag->term_id); ?>><?php echo $topic_tag->name; ?></option>
			<?php endforeach; ?>
		</select>
		<?php
	}

	public function get_date_range_picker_field()
	{
		$start_date = isset($_REQUEST['tlms_at_date_start']) && !empty($_REQUEST['tlms_at_date_start']) ? $_REQUEST['tlms_at_date_start'] : '';
		$end_date   = isset($_REQUEST['tlms_at_date_end']) && !empty($_REQUEST['tlms_at_date_end']) ? $_REQUEST['tlms_at_date_end'] : '';
		$dates      = isset($_REQUEST['dates']) && !empty($_REQUEST['dates']) ? $_REQUEST['dates'] : '';
		$action     = $this->current_action();

		if ($action != 'view_detail_logs') { ?>
			<input type="hidden" id="tlms_at_date_start" name="tlms_at_date_start" value="<?php echo $start_date; ?>">
			<input type="hidden" id="tlms_at_date_end" name="tlms_at_date_end" value="<?php echo $end_date; ?>">
			<input id="tlms_at-daterange-picker" class="tlms_at-daterange-picker" type="text" name="dates" value="<?php echo $dates; ?>" placeholder="<?php _e('Select Date Range', 'tutor-lms-attendance'); ?>" autocomplete="off"> <a href="#" id="tlms_at-clear-daterange-picker"><?php echo __('Clear', 'tutor-lms-attendance'); ?></a>
		<?php } else { ?>
			<input type="hidden" id="tlms_at_date_start" name="tlms_at_date_start" value="<?php echo $start_date; ?>">
			<input type="hidden" id="tlms_at_date_end" name="tlms_at_date_end" value="<?php echo $end_date; ?>">
		<?php
		}
	}
	private function export_button()
	{
		?>
		<!-- <button id="btn_export_attendance_logs" type="button" class="button"><?php _e('Export Attendance logs', 'tutor-lms-attendance'); ?></button> -->
		<?php
	}
	private function get_export_button()
	{
		$export_action = 'export';
		$action        = $this->current_action();

		if ($action == 'view_detail_logs') {
			$export_action = 'export_detail_logs';
		}

		$user_id   = isset($_REQUEST['user_id']) ? $_REQUEST['user_id'] : 0;
		$post_type = isset($_REQUEST['post_type']) ? $_REQUEST['post_type'] : 0;
		if ($action == 'view_detail_logs') {
			$tlms_at_attendance_type = isset($_REQUEST['tlms_at_attendance_type']) ? $_REQUEST['tlms_at_attendance_type'] : '';
			$this->object_input();
		?>
			<input type="hidden" name="tlms_at_attendance_type" value="<?php echo $tlms_at_attendance_type; ?>">
		<?php
		}
		?>
		<input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
		<input type="hidden" name="post_type" value="<?php echo $post_type; ?>">
		<button style="display:none;" type="submit" name="action" value="<?php echo $export_action; ?>" class="button"><?php _e('Export', 'tutor-lms-attendance'); ?></button>
	<?php
	}

	private function get_delete_button()
	{
	?>
	<button id="btn_clear_attendance_logs" type="button" class="button"><?php _e('Clear logs', 'tutor-lms-attendance'); ?></button>
	<?php
	}

	private function object_input()
	{
		$object_types = ['course', 'lesson', 'topic'];
		foreach ($object_types as $object_type) {
			$field_name = "{$object_type}_id";
			if (isset($_REQUEST[$field_name]) && !empty($_REQUEST[$field_name])) {
				$field_value = $_REQUEST[$field_name];
				echo sprintf('<input type="hidden" name="%s" value="%s">', $field_name, $field_value);
			}
		}
	}

	private function get_back_button()
	{
	?>
		<button class="button" onclick="window.history.go(-1); return false;"><?php _e('Back', 'tutor-lms-attendance'); ?></button>
<?php
	}

	// protected function views_keep_require_query_args() { }

	protected function get_views()
	{

		$views          = array();
		$current        = (!empty($_REQUEST['view_type']) ? $_REQUEST['view_type'] : 'all');
		$course_c_label = sprintf(esc_html_x('By %s', 'placeholder: Course', 'tutor-lms-attendance'), __('Course', 'tutor-lms-attendance'));
		$lesson_c_label = sprintf(esc_html_x('By %s', 'placeholder: Lesson', 'tutor-lms-attendance'), __('Lesson', 'tutor-lms-attendance'));

		// All link
		$class       = ($current == 'all' ? ' class="current"' : '');
		$remove_args = [
			's',
			'order',
			'paged',
			'dates',
			'user_id',
			'orderby',
			'topic_id',
			'lesson_id',
			'user_role',
			'course_id',
			'topic_tag_id',
			'course_tag_id',
			'lesson_tag_id',
			'tlms_at_date_end',
			'tlms_at_post_type',
			'topic_category_id',
			'course_category_id',
			'tlms_at_date_start',
			'lesson_category_id',
			'tlms_at_attendance_type',
		];

		$all_url      = remove_query_arg($remove_args, add_query_arg('view_type', 'all'));
		$views['all'] = "<a href='{$all_url}' {$class} >" . __('All', 'tutor-lms-attendance') . '</a>';

		// Course link
		$remove_args = [
			'paged',
			'course_id',
			'tlms_at_attendance_type',
			'course_category_id',
			'course_tag_id',
			'lesson_id',
			'lesson_category_id',
			'lesson_tag_id',
			'topic_id',
			'topic_category_id',
			'topic_tag_id',
			'tlms_at_post_type',
			'tlms_at_date_start',
			'tlms_at_date_end',
			'dates',
			'user_id',
			'user_role',
			'orderby',
			'order',
			's'
		];

		$course_url         = remove_query_arg($remove_args, add_query_arg('view_type', 'course'));
		$class              = ($current == 'course' ? ' class="current"' : '');
		$views['by_course'] = "<a href='{$course_url}' {$class} >" . $course_c_label . '</a>';

		// Lesson link
		$remove_args = [
			'paged',
			'course_id',
			'tlms_at_attendance_type',
			'course_category_id',
			'course_tag_id',
			'lesson_id',
			'lesson_category_id',
			'lesson_tag_id',
			'topic_id',
			'topic_category_id',
			'topic_tag_id',
			'tlms_at_post_type',
			'tlms_at_date_start',
			'tlms_at_date_end',
			'dates',
			'user_id',
			'user_role',
			'orderby',
			'order',
			's'
		];

		$lesson_url         = remove_query_arg($remove_args, add_query_arg('view_type', 'lesson'));
		$class              = ($current == 'lesson' ? ' class="current"' : '');
		$views['by_lesson'] = "<a href='{$lesson_url}' {$class} >" . $lesson_c_label . '</a>';

		// User link
		$remove_args = [
			'paged',
			'course_id',
			'tlms_at_attendance_type',
			'course_category_id',
			'course_tag_id',
			'lesson_id',
			'lesson_category_id',
			'lesson_tag_id',
			'topic_id',
			'topic_category_id',
			'topic_tag_id',
			'tlms_at_post_type',
			'tlms_at_date_start',
			'tlms_at_date_end',
			'dates',
			'user_id',
			'user_role',
			'orderby',
			'order',
			's'
		];

		$user_url         = remove_query_arg($remove_args, add_query_arg('view_type', 'user'));
		$class            = ($current == 'user' ? ' class="current"' : '');
		$views['by_user'] = "<a href='{$user_url}' {$class} >" . __('By User', 'tutor-lms-attendance') . '</a>';

		return $views;
	}

	/**
	 * Get the current action selected from the bulk actions dropdown.
	 *
	 * @return string|false The action name or False if no action was selected
	 * @since 3.1.0
	 *
	 */
	public function current_action()
	{
		if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'view_detail_logs') {
			return $_REQUEST['action'];
		}

		if (isset($_REQUEST['filter_action']) && !empty($_REQUEST['filter_action'])) {
			return false;
		}

		if (isset($_REQUEST['action']) && -1 != $_REQUEST['action']) {
			return $_REQUEST['action'];
		}

		if (isset($_REQUEST['action2']) && -1 != $_REQUEST['action2']) {
			return $_REQUEST['action2'];
		}

		return false;
	}
}

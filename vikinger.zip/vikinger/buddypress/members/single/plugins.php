<?php
/**
 * Vikinger Template - BuddyPress Member Plugins
 * 
 * Loads member custom templates
 * 
 * @package Vikinger
 * @since 1.0.0
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

  do_action('bp_template_content');

?>
/*------------
    SVG 
------------*/
import './icon/svg-loader';

/*----------------------------
    REQUIRED PLUGIN LIST
----------------------------*/
import './component-dom/plugin/plugin-list';

/*----------------------------
    DEMO IMPORT LIST
----------------------------*/
import './component-dom/demo/demo-import-list';
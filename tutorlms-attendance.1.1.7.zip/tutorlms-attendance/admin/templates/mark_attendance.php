<?php
defined( 'ABSPATH' ) || exit;

$users       = get_users( array( 'fields' => array( 'ID' ) ) );
$users_count = sizeof( $users );

?>

<div class="ld_attendance_wrap tlm-atd-panel">
    <h2><?php _e( 'Mark Attendance', 'tutor-lms-attendance' ); ?></h2>
    <p><?php _e( '<strong>Note:</strong> Only enrolled user(s) attendance will be marked, non-enrolled user(s) will be ignored.', 'tutor-lms-attendance' ); ?></p>
    <form id="wn_ld_mark_attendance_form" method="post"
          action="<?php admin_url( 'admin.php?page=tlms-attendance&tab=mark_attendance' ) ?>">
        <table style="border-spacing:0px;">
            <!-- select user start -->
            <tr valign="top">
                <th scope="row">
                    <label for="tlms_at_disable_user_mark_attendance">
						<?php _e( 'Mark attendance for selected Users', 'tutor-lms-attendance' ); ?>
                    </label>
                </th>
                <td>
                    <nav class="tlms_mark_att_nav">
                        <ul class="tlms_mark_att_ul"
                            style="<?php echo( $users_count > 6 ? 'overflow-y:scroll;' : '' ) ?>">
							<?php
							foreach ( $users as $user ) {
								$user_info = get_userdata( $user->ID );
								?>
                                <li><label>
                                        <input type="checkbox" name="tlms_at_user_id_field[]" id="tlms_at_user_id_field"
                                               value="<?php echo $user->ID; ?>"/><?php _e( $user_info->display_name, 'tutor-lms-attendance' ); ?>
                                    </label></li>
								<?php
							}
							?>
                        </ul>
                    </nav>
                </td>
            </tr>
            <!-- select user end -->

            <!-- select course start -->
            <tr valign="top">
                <th scope="row">
                    <label for="tlms_at_disable_user_mark_attendance">
						<?php _e( 'Mark attendance for selected Courses', 'tutor-lms-attendance' ); ?>
                    </label>
                </th>
                <td>
                    <nav class="tlms_mark_att_nav">
						<?php
						$args = array(
							'post_type'   => 'courses',
							'post_status' => 'publish',
						);

						$course_query = new WP_Query( $args );
						?>
                        <ul class="tlms_mark_att_ul"
                            style="<?php echo( sizeof( $course_query->posts ) > 6 ? 'overflow-y:scroll;' : '' ) ?>">
							<?php

							foreach ( $course_query->posts as $course ) {
								?>
                                <li><label>
                                        <input type="checkbox" name="tlms_at_course_id_field[]"
                                               id="tlms_at_course_id_field"
                                               value="<?php echo $course->ID; ?>"/><?php _e( $course->post_title, 'tutor-lms-attendance' ); ?>
                                    </label></li>
								<?php
							}
							?>
                        </ul>
                    </nav>
                </td>
            </tr>
            <!-- Select course end -->
            <!-- Select Lesson start -->
            <tr valign="top">
                <th scope="row">
                    <label for="tlms_at_disable_user_mark_attendance">
						<?php _e( 'Mark attendance for selected Lessons', 'tutor-lms-attendance' ); ?>
                    </label>
                </th>
                <td>
                    <nav class="tlms_mark_att_nav">
						<?php
						$args = array(
							'post_type'   => 'lesson',
							'post_status' => 'publish',
						);

						$lesson_query = new WP_Query( $args );
						?>
                        <ul class="tlms_mark_att_ul"
                            style="<?php echo( sizeof( $lesson_query->posts ) > 6 ? 'overflow-y:scroll;' : '' ) ?>">
							<?php

							foreach ( $lesson_query->posts as $lesson ) {
								?>
                                <li><label>
                                        <input type="checkbox" name="tlms_at_lesson_id_field[]"
                                               id="tlms_at_lesson_id_field"
                                               value="<?php echo $lesson->ID; ?>"/><?php echo _e( $lesson->post_title, 'tutor-lms-attendance' ); ?>
                                    </label></li>
								<?php
							}
							?>
                        </ul>
                    </nav>
                </td>
            </tr>
            <!-- Select Lesson end -->

            <!-- Select date start -->

            <tr valign="top">
                <th scope="row">
                    <label for="tlms_at_disable_user_mark_attendance">
						<?php _e( 'Date Range', 'tutor-lms-attendance' ); ?>
                    </label>
                </th>
                <td><input type="hidden" id="tlms_at_date_start" name="tlms_at_date_start" value="">
                    <input type="hidden" id="tlms_at_date_end" name="tlms_at_date_end" value="">
                    <input id="tlms_at-daterange-picker" class="tlms_at-daterange-picker" type="text" name="dates"
                           value="" placeholder="<?php _e( 'Select Date Range', 'tutor-lms-attendance' ); ?>"
                           autocomplete="off">
                    <a id="tlms_at-clear-daterange-picker"><?php echo __('Clear' , 'tutor-lms-attendance'); ?></a>
                    <p class="description"><?php _e( 'Mark attendance for selected date(s)', 'tutor-lms-attendance' ); ?></p>
                </td>
            </tr>
            <!-- Select date end -->

            <!-- Select attendance comment start -->

            <tr valign="top">
                <th scope="row">
                    <label for="tlms_at_disable_user_mark_attendance">
						<?php _e( 'Remarks', 'tutor-lms-attendance' ); ?>
                    </label>
                </th>
                <td><?php wp_editor( '', 'tlms_at_mark_attendance_comment', array( 'textarea_rows' => 4 ) ); ?>
                    <p class="description"><?php _e('Remarks for this attendance', 'tutor-lms-attendance'); ?></p>
                </td>
            </tr>
            <!-- Select attendance comment end -->

            <!-- Select attendance type -->

            <tr valign="top">
                <th scope="row">
                    <label>
						<?php _e( 'Attendance type', 'tutor-lms-attendance' ); ?>
                    </label>
                </th>
                <td><label><input type="radio" name="tlms_at_mark_attendance_type"
                                  value="absent"> <?php _e( 'Absent', 'tutor-lms-attendance' ); ?></label> &nbsp;
                    <label><input type="radio" name="tlms_at_mark_attendance_type"
                                  value="present"> <?php _e( 'Present', 'tutor-lms-attendance' ); ?></label>
                </td>
            </tr>
            <!-- Select attendance type -->


        </table>
        <div class="submit">
            <input type="submit" name="tlms_at_mark_attendance_submit" class="button-primary wn-ld-attendace-addon-btn"
                   value="<?php _e( 'Mark Attendance', 'tutor-lms-attendance' ); ?>"
                   data-warning="<?php _e( 'Are you sure you want to proceed with deleting data?', 'tutor-lms-attendance' ); ?>">
        </div>
		<?php wp_nonce_field( 'wn_ld_mark_attendance', 'wn_ld_mark_attendance_nonce_field' ); ?>
    </form>
</div>


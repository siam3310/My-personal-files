# Changelog

## 1.1.7
- New: Added an option to display local time instead of universal time in user tracking.

## 1.1.6
- New: Added a pop-up reminder for users to log out.
- New: Users who remain logged in for more than 12 hours will be automatically logged out.

## 1.1.5
- Fix: Fixed a fatal error occurring during user login.

## 1.1.4
- Fix: Fixed PHP warnings.
- Fix: Updated language pot file.

## 1.1.3
- Fix: Fixed User Login/Logout Time Tracking Table Creation.
- Fix: Fixed Clear Logs Button on Attendance Logs.

## 1.1.2
- Fix: Auto Attendance on Login.
- Fix: Minor UI Changes.
- Fix: Enable User Calendar option.
- Fix: Restrict IP option.

## 1.1.1
- Fix: Fixed the User Tracking to track login/logout activity each time a user logs in or out.

## 1.1.0
- New : User Tracking 
- New : Minimum attendance
- New : Attendance calendar on frontend
- New : Import/export attendance
- New : Debug logs
- Fix : UI issues

## 1.0.2
- Updated : POT file for translation

## 1.0.1
- Updated : License Module

## 1.0.0
- Initial
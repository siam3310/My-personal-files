<?php
/**
 * AJAX - Advanced Ads + BuddyPress
 * 
 * @package Vikinger
 * 
 * @since 1.9.1
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

/**
 * Global
 */
require_once VIKINGER_PATH . '/includes/ajax/advancedads/advancedads-buddypress/vikinger-ajax-advancedads-buddypress-global.php';
import React from 'react';

function Grid_6(props) {
  return (
    <div className="grid grid-6-6 centered">
      {props.content}
    </div>
  );
}

export { Grid_6 as default };
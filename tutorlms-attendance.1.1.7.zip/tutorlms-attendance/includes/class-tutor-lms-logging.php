<?php

/**
 * Tutor LMS Attendance Add-on Logging
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'Tutor_Lms_Logging' ) ) {

	class Tutor_Lms_Logging {

		public $is_writable = true;
		private $filename = '';
		private $file = '';

		/**
		 * Get things started
		 */
		public function __construct() {
			$this->init();
			// Hook the downloadCustomLogFile function to your desired action or filter
			// For your HTML link, it seems you want to use the 'admin_init' action
			add_action( 'admin_init', [ $this, 'download_custom_debug_Log_file' ] );
		}

		/**
		 * Get things started
		 * @return void
		 */
		public function init() {

			$upload_dir     = wp_upload_dir( null, false );
			$this->filename = 'tlms-attendance-activity.log';
			$this->file     = trailingslashit( $upload_dir['basedir'] ) . $this->filename;

			if ( ! is_writeable( $upload_dir['basedir'] ) ) {
				$this->is_writable = false;
			}

		}

		/**
		 * Retrieve the log data
		 *
		 * @return string
		 * @since 1.7.15
		 */
		public function get_log() {
			return $this->get_file();
		}

		/**
		 * Retrieve the file data is written to
		 *
		 * @return string
		 * @since 1.7.15
		 */
		protected function get_file() {

			$file = '';

			if ( @file_exists( $this->file ) ) {

				if ( ! is_writeable( $this->file ) ) {
					$this->is_writable = false;
				}

				$file = @file_get_contents( $this->file );

			} else {

				@file_put_contents( $this->file, '' );
				@chmod( $this->file, 0664 );

			}

			return $file;
		}

		/**
		 * Write the log message
		 *
		 * @param string $message Message to write to the debug log.
		 *
		 * @return void
		 * @since 1.7.15
		 *
		 */
		protected function write_to_log( $message ) {
			$file = $this->get_file();
			$file .= $message;

			@file_put_contents( $this->file, $file );
		}

		/**
		 * Write the log message
		 *
		 * @return void
		 * @since 1.7.15
		 */
		public function clear_log() {
			@unlink( $this->file );
		}

		/**
		 * Log message to file
		 *
		 * @param string $message Message to write to the debug log.
		 * @param array|mixed $data Optional. Array of data or other output to send to the log.
		 *                             Default empty array.
		 *
		 * @return void
		 * @since 2.3 An optional `$data` parameter was added.
		 *
		 * @since 1.7.15
		 */
		public function log( $message, $data = array() ) {
			$message = '[' . date( 'd-M-Y H:i:s' ) . ' ' . get_option( 'timezone_string', 'UTC' ) . '] ' . $message . "\r\n";

			if ( ! empty( $data ) ) {
				if ( is_array( $data ) ) {
					$data = var_export( $data, true );
				} else {
					ob_start();

					var_dump( $data );

					$data = ob_get_clean();
				}

				$message .= $data;
			}


			$this->write_to_log( $message );
		}

		public function get_filename() {
			return $this->filename;
		}

		public function get_filesize() {
			$wp_filesystem = $this->get_filesystem();
			$size          = $wp_filesystem->size( $this->file );
			if ( $size > 100000000 ) {
				echo 'huge';
				exit;
			}
		}

		/**
		 * Instantiates the WordPress filesystem for use.
		 *
		 * @return object
		 */
		private function get_filesystem() {
			global $wp_filesystem;

			if ( ! defined( 'FS_METHOD' ) ) {
				define( 'FS_METHOD', 'direct' );
			}

			if ( empty( $wp_filesystem ) ) {
				require_once ABSPATH . '/wp-admin/includes/file.php';
				WP_Filesystem();
			}

			return $wp_filesystem;
		}


		public function copy_debug_log_to_new_file() {
			// Get the path to the debug log file
			$debugLogFilePath = WP_CONTENT_DIR . '/debug.log';

			// Check if the debug log file exists
			if ( file_exists( $debugLogFilePath ) ) {
				// Define the destination file path (same folder as debug.log)
				$destinationFilePath = dirname( $debugLogFilePath ) . '/ldal-debug-log.log';

				// Read the debug log content
				$debugLogContent = file_get_contents( $debugLogFilePath );

				// Create a new file and write the debug log content to it
				if ( file_put_contents( $destinationFilePath, $debugLogContent ) !== false ) {
					return true; // Success
				} else {
					return false; // Failed to write the content
				}
			} else {
				return false; // Debug log file does not exist
			}
		}

		public function download_custom_debug_Log_file() {

			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			// Check if we are on plugin settings page.
			if ( isset( $_REQUEST['page'] ) && 'tlms-attendance' === rtrim( $_REQUEST['page'] ) ) {

				// Check if active tab is quiz_settings
				if ( isset( $_REQUEST['tab'] ) && 'debug_log' === rtrim( $_REQUEST['tab'] ) ) {

					if ( isset( $_REQUEST['action'] ) && 'download' === rtrim( $_REQUEST['action'] ) ) {
						error_log( 'Downloading debug logs...' );
						// Get the path to the custom log file (ldal-debug-log.log)
						$logFilePath = WP_CONTENT_DIR . '/debug.log';

						// Check if the log file exists
						if ( file_exists( $logFilePath ) ) {
							// Set the appropriate headers for downloading
							header( 'Content-Type: application/octet-stream' );
							header( 'Content-Disposition: attachment; filename="tlms-at-debug.log"' );
							header( 'Content-Length: ' . filesize( $logFilePath ) );
							
							// Output the file content
							readfile( $logFilePath );
							exit;
						} else {
							// Log file does not exist
							// wp_die('Custom log file not found.', 'Error');
						}
					}
				}
			}
		}

	}
}

return new Tutor_Lms_Logging();
<?php

/**
 * Fired during plugin activation
 *
 * @link       https://wooninjas.com/
 * @since      1.0.0
 *
 * @package    Tutor_Lms_Attendance
 * @subpackage Tutor_Lms_Attendance/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Tutor_Lms_Attendance
 * @subpackage Tutor_Lms_Attendance/includes
 * @author     WooNinjas
 */
class Tutor_Lms_Attendance_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		Tutor_Lms_Attendance_Activator::db_upgrade();
	}

	/**
	 * Create log table if not exists
	 */
	public static function db_upgrade() {

		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		$table_name = $wpdb->prefix . 'tlms_attendance_logs';

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) != $table_name ) {

			$sql = "CREATE TABLE `{$table_name}` (
					`id` int(11) NOT NULL AUTO_INCREMENT,
					`course_id` int(11) NOT NULL,
					`lesson_id` int(11) NOT NULL,
					`topic_id` int(11) NOT NULL,
					`quiz_id` int(11) NOT NULL,
					`user_id` int(11) NOT NULL,
					`ip_address` text DEFAULT NULL,
					`device_id` text DEFAULT NULL,
					`log_by_user_id` int(11) DEFAULT NULL COMMENT 'The user_id who generate this log',
					`attendance_type` ENUM('absent','present') NOT NULL DEFAULT 'absent',
					`comment` TEXT NOT NULL,
					`created_at` datetime NOT NULL,
					`modified_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NULL,
					PRIMARY KEY (`id`)
					) $charset_collate;";

			// require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			// dbDelta( $sql );

			$wpdb->query( $sql );

		} else {

			$db_table_columns = $wpdb->get_results( "SELECT COLUMN_NAME AS columns FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='{$wpdb->dbname}' AND TABLE_NAME='{$table_name}'" );

			$table_columns = [];
			foreach ( $db_table_columns as $table_column ) {
				$table_columns[] = $table_column->columns;
			}
			if ( in_array( 'course_id', $table_columns ) == false ) {
				$sql    = "ALTER TABLE {$table_name} ADD `course_id` int(11) NOT NULL AFTER course_id";
				$result = $wpdb->query( $sql );
			}
			if ( in_array( 'lesson_id', $table_columns ) == false ) {
				$sql    = "ALTER TABLE {$table_name} ADD `lesson_id` int(11) NOT NULL AFTER course_id";
				$result = $wpdb->query( $sql );
			}
			if ( in_array( 'topic_id', $table_columns ) == false ) {
				$sql    = "ALTER TABLE {$table_name} ADD `topic_id` int(11) NOT NULL AFTER lesson_id";
				$result = $wpdb->query( $sql );
			}
			if ( in_array( 'quiz_id', $table_columns ) == false ) {
				$sql    = "ALTER TABLE {$table_name} ADD `quiz_id` int(11) NOT NULL AFTER topic_id";
				$result = $wpdb->query( $sql );
			}
			if ( in_array( 'attendance_type', $table_columns ) == false ) {
				$sql    = "ALTER TABLE {$table_name} ADD COLUMN `attendance_type` ENUM('absent','present') DEFAULT 'absent' NOT NULL AFTER `log_by_user_id`";
				$result = $wpdb->query( $sql );
			}
			if ( in_array( 'comment', $table_columns ) == false ) {
				$sql    = "ALTER TABLE {$table_name} ADD COLUMN `comment` TEXT NOT NULL AFTER `attendance_type`";
				$result = $wpdb->query( $sql );
			}
			if ( in_array( 'modified_at', $table_columns ) == false ) {
				$sql    = "ALTER TABLE {$table_name} ADD COLUMN `modified_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NULL AFTER `created_at`";
				$result = $wpdb->query( $sql );
			}

			if ( in_array( 'ip_address', $table_columns ) == true ) {
				$sql    = "ALTER TABLE {$table_name} MODIFY `ip_address` TEXT NULL;";
				$result = $wpdb->query( $sql );
			}
			return;
		}

		$table2_name = $wpdb->prefix . 'tlms_timetrack_logs';
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table2_name'" ) != $table2_name ) {
			$sql = "CREATE TABLE `{$table2_name}` (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`user_id` int(11) NOT NULL,
				`login_time` datetime DEFAULT NULL,
				`logout_time` datetime DEFAULT NULL,
				`ip_address` text DEFAULT NULL,
				PRIMARY KEY (`id`)
				) $charset_collate;";

		// require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		// dbDelta( $sql );

		$wpdb->query( $sql );
		}else{
			$db_table_columns = $wpdb->get_results( "SELECT COLUMN_NAME AS columns FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='{$wpdb->dbname}' AND TABLE_NAME='{$table_name2}'" );

			$table2_columns = [];
			foreach ( $db_table_columns as $table2_column ) {
				$table2_columns[] = $table2_column->columns;
			}

			if ( in_array( 'login_time', $table2_columns ) == false ) {
				$sql    = "ALTER TABLE {$table2_name} ADD `login_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NULL AFTER user_id";
				$result = $wpdb->query( $sql );
			}
			if ( in_array( 'logout_time', $table2_columns ) == false ) {
				$sql    = "ALTER TABLE {$table2_name} ADD `logout_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NULL AFTER login_time";
				$result = $wpdb->query( $sql );
			}
			if ( in_array( 'ip_address', $table2_columns ) == true ) {
				$sql    = "ALTER TABLE {$table2_name} MODIFY `ip_address` TEXT NULL;";
				$result = $wpdb->query( $sql );
			}
			return;
		}
	}

}

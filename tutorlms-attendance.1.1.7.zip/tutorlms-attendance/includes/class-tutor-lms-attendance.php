<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://wooninjas.com/
 * @since      1.0.0
 *
 * @package    Tutor_Lms_Attendance
 * @subpackage Tutor_Lms_Attendance/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Tutor_Lms_Attendance
 * @subpackage Tutor_Lms_Attendance/includes
 * @author     WooNinjas
 */
class Tutor_Lms_Attendance
{

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Tutor_Lms_Attendance_Loader $loader Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string $plugin_name The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string $version The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct()
	{
		if (defined('TUTOR_LMS_ATTENDANCE_VERSION')) {
			$this->version = TUTOR_LMS_ATTENDANCE_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'tutor-lms-attendance';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Tutor_Lms_Attendance_Loader. Orchestrates the hooks of the plugin.
	 * - Tutor_Lms_Attendance_i18n. Defines internationalization functionality.
	 * - Tutor_Lms_Attendance_Admin. Defines all hooks for the admin area.
	 * - Tutor_Lms_Attendance_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies()
	{

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-tutor-lms-attendance-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-tutor-lms-attendance-i18n.php';


		/**
		 * The class responsible for defining all actions that occur to verify license.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'admin/license/class-tutor-lms-attendance-license.php';

		/**
		 * The class responsible for defining all actions that occur to verify and update plugin.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'admin/license/class-tutor-lms-attendance-plugin-updater.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-tutor-lms-attendance-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path(dirname(__FILE__)) . 'public/class-tutor-lms-attendance-public.php';

		// include activity log file
		if (file_exists(plugin_dir_path(dirname(__FILE__)) . 'includes/class-tutor-lms-debug.php')) {
			require_once(plugin_dir_path(dirname(__FILE__)) . 'includes/class-tutor-lms-debug.php');
		}

		// include debug log file
		if (file_exists(plugin_dir_path(dirname(__FILE__)) . 'includes/class-tutor-lms-logging.php')) {
			require_once(plugin_dir_path(dirname(__FILE__)) . 'includes/class-tutor-lms-logging.php');
		}

		$this->loader = new Tutor_Lms_Attendance_Loader();
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Tutor_Lms_Attendance_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale()
	{

		$plugin_i18n = new Tutor_Lms_Attendance_i18n();

		$this->loader->add_action('plugins_loaded', $plugin_i18n, 'load_plugin_textdomain');
	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks()
	{

		$plugin_license = new Tutor_Lms_Attendance_License($this->get_plugin_name(), $this->get_version());
		$plugin_admin   = new Tutor_Lms_Attendance_Admin($this->get_plugin_name(), $this->get_version());

		$this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
		$this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');


		//clear/delete attendance logs 
		$this->loader->add_action('wp_ajax_tlms_clear_attendance_logs',		  		  $plugin_admin, 'tlms_clear_attendance_logs');
		$this->loader->add_action('wp_ajax_nopriv_tlms_clear_attendance_logs',		  $plugin_admin, 'tlms_clear_attendance_logs');

		//export attendance 
		$this->loader->add_action('wp_ajax_tlms_at_export_btn',		  		  $plugin_admin, 'tlms_at_export_btn');
		$this->loader->add_action('wp_ajax_nopriv_tlms_at_export_btn',		  $plugin_admin, 'tlms_at_export_btn');
		// import attendance
		$this->loader->add_action('wp_ajax_tlms_at_upload_file_form_action',		  $plugin_admin, 'tlms_at_upload_file_form_action');
		$this->loader->add_action('wp_ajax_nopriv_tlms_at_upload_file_form_action', $plugin_admin, 'tlms_at_upload_file_form_action');

		//submenu page for Attendance
		$this->loader->add_action('admin_menu', $plugin_admin, 'tlms_menu_page_fnc', 100);

		$this->loader->add_action('admin_post_tlms_at_admin_settings', $plugin_admin, 'tlms_at_admin_settings_save_settings');

		$this->loader->add_action('admin_print_footer_scripts', $plugin_admin, 'tlms_at_admin_footer_scripts');
		$this->loader->add_action('admin_init', $plugin_admin, 'tlms_at_admin_mark_attendance');

		$this->loader->add_action('init', $plugin_admin, 'tlms_at_auto_init');

		$this->loader->add_action('wp_login', $plugin_admin, 'tlms_at_auto_login_setup_course_att', 10, 2);
		$this->loader->add_action('setup_course_automatic_attendance_on_login', $plugin_admin, 'set_user_all_courses_attendance_on_login');
		$this->loader->add_action('admin_init', $plugin_admin, 'save_settings');
		$this->loader->add_action('wp_login', $plugin_admin, 'user_login_hook', 10, 2);
		$this->loader->add_action('wp_logout', $plugin_admin, 'user_logout_hook', 10, 2);
		// add minimum attendance metabox in course settings
		$this->loader->add_action('add_meta_boxes', $plugin_admin, 'add_minimum_attendance_metabox');
		$this->loader->add_action('save_post', $plugin_admin, 'save_minimum_attendance_metabox');

		// Plugin license initialize and notices
		$this->loader->add_action('admin_init', $plugin_license, 'plugin_updater');
		$this->loader->add_action('admin_init', $plugin_license, 'register_license_option');
		$this->loader->add_action('admin_init', $plugin_license, 'activate_license');
		$this->loader->add_action('admin_init', $plugin_license, 'deactivate_license');
		$this->loader->add_action('admin_notices', $plugin_license, 'admin_notices');
		$this->loader->add_action('admin_notices', $plugin_license, 'license_activation_notices');

		if (doing_cron()) {
			$this->loader->add_action('tutor_lms_attendance_weekly_scheduled_events', $plugin_license, 'weekly_license_check');
		}


		//add metabox in tutorlms course setting for minimum attendance
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks()
	{

		$plugin_public = new Tutor_Lms_Attendance_Public($this->get_plugin_name(), $this->get_version());
		$options       = get_option('tlms_at_options', array());


		$this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
		$this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');
		//course-single-page attendance
		$this->loader->add_action('tutor_course/single/before/inner-wrap', $plugin_public, 'tlms_attendance_course_callback');
		$this->loader->add_action('tutor_lesson/single/before/content', $plugin_public, 'tlms_attendance_lesson_callback');
		//mark attendance ajax calls
		$this->loader->add_action('wp_ajax_tlms_front_mark_attendance', $plugin_public, 'tlms_front_mark_attendance_cb');

		$this->loader->add_action('tutor_course/single/after/inner-wrap', $plugin_public, 'tlms_admin_mark_attendance_front_cb');


		$this->loader->add_action('tutor_lesson/single/after/content', $plugin_public, 'tlms_admin_mark_attendance_lesson_front_cb');

		$this->loader->add_action('wp_ajax_tlmsat_front_mark_attendance', $plugin_public, 'ajax_tlmsat_front_mark_attendance_cb');

		// add Attendance tab in tutorlms dashboard frontend
		$this->loader->add_filter('tutor_dashboard/nav_items', $plugin_public, 'add_attendance_tabs_dashboard');
		$this->loader->add_filter('load_dashboard_template_part_from_other_location', $plugin_public, 'set_attendance_template_dashboard');

		// minimum attendance functionality
		$this->loader->add_filter('is_completed_course', $plugin_public, 'is_completed_course', 10, 3);
		$this->loader->add_action('tutor_course/single/actions_btn_group/before', $plugin_public, 'add_miminum_attendance_message', 10, 3);

		//export attendance 
		$this->loader->add_action('wp_ajax_tlms_at_get_attendance_data',		  	  $plugin_public, 'tlms_at_get_attendance_data');
		$this->loader->add_action('wp_ajax_nopriv_tlms_at_get_attendance_data',		  $plugin_public, 'tlms_at_get_attendance_data');

		//save user session value 
		$this->loader->add_action('wp_ajax_update_session',		  	  $plugin_public, 'update_session');
		$this->loader->add_action('wp_ajax_nopriv_update_session',		  $plugin_public, 'update_session');


	}


	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run()
	{
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @return    string    The name of the plugin.
	 * @since     1.0.0
	 */
	public function get_plugin_name()
	{
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @return    Tutor_Lms_Attendance_Loader    Orchestrates the hooks of the plugin.
	 * @since     1.0.0
	 */
	public function get_loader()
	{
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @return    string    The version number of the plugin.
	 * @since     1.0.0
	 */
	public function get_version()
	{
		return $this->version;
	}
}

<?php
    $connection = mysqli_connect("localhost:3307","root","","movie");

    $base_url = "http://localhost/movie/";
?>
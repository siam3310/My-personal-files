document.addEventListener('DOMContentLoaded', async () => {
    const encodedUrl = 'aHR0cHM6Ly9lcHpyanFxY3V5cmh5bmtra2tqYS5zdXBhYmFzZS5jby9mdW5jdGlvbnMvdjEvcGxheWxpc3Q/aG9zdD04OS4xODcuMTkxLjU0';
    const playlistUrl = atob(encodedUrl);
    const channelList = document.getElementById('channel-list');
    const searchInput = document.getElementById('search');
    const categoryFilter = document.getElementById('category-filter');
    const playerContainer = document.getElementById('player-container');
    const video = document.getElementById('video');
    const refreshStreamBtn = document.getElementById('refresh-stream');
    const logo = document.getElementById('logo');
    const loader = document.getElementById('loader');
    const initialLoader = document.getElementById('initial-loader');

    let channels = [];
    let currentStreamUrl = null;
    let player = null;
    let currentlyDisplayedChannels = [];
    let channelsToDisplay = [];
    const channelsPerLoad = 20;
    let isLoading = false;

    // Show initial loader
    initialLoader.style.display = 'flex';

    // Pre-initialize the player for faster startup
    initPlayer();

    try {
        const response = await fetch(playlistUrl);
        const data = await response.text();
        channels = parseM3U(data);
        channelsToDisplay = [...channels];
        populateCategoryFilter(channels);
        loadMoreChannels();
    } catch (error) {
        console.error('Error fetching playlist:', error);
    } finally {
        // Hide initial loader
        initialLoader.style.display = 'none';
    }

    function parseM3U(data) {
        const lines = data.split('\n');
        const channels = [];
        let currentChannel = {};

        for (const line of lines) {
            if (line.startsWith('#EXTINF')) {
                const info = line.split(',');
                const name = info[1];
                const groupMatch = line.match(/group-title="(.*?)"/);
                const group = groupMatch ? groupMatch[1] : 'Uncategorized';
                currentChannel = { name, group };
            } else if (line.startsWith('http')) {
                currentChannel.url = line;
                channels.push(currentChannel);
                currentChannel = {};
            }
        }
        return channels;
    }

    function populateChannelList(channels) {
        const fragment = document.createDocumentFragment();
        for (const channel of channels) {
            const listItem = document.createElement('li');
            listItem.className = 'list-group-item';
            listItem.textContent = channel.name;
            listItem.addEventListener('click', () => {
                playChannel(channel.url);
            });
            fragment.appendChild(listItem);
        }
        channelList.appendChild(fragment);
    }

    function populateCategoryFilter(allChannels) {
        const categories = [...new Set(allChannels.map(channel => channel.group))];
        for (const category of categories) {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            categoryFilter.appendChild(option);
        }
    }

    function loadMoreChannels() {
        if (isLoading || currentlyDisplayedChannels.length >= channelsToDisplay.length) {
            loader.style.display = 'none';
            return;
        }
        isLoading = true;
        loader.style.display = 'block';

        const nextChannels = channelsToDisplay.slice(currentlyDisplayedChannels.length, currentlyDisplayedChannels.length + channelsPerLoad);
        populateChannelList(nextChannels);
        currentlyDisplayedChannels.push(...nextChannels);
        isLoading = false;
        if (currentlyDisplayedChannels.length >= channelsToDisplay.length) {
            loader.style.display = 'none';
        }
    }

    window.addEventListener('scroll', () => {
        if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 500 && !isLoading) {
            loadMoreChannels();
        }
    });

    async function playChannel(url) {
        currentStreamUrl = url;
        playerContainer.style.display = 'block';
        refreshStreamBtn.style.display = 'block';

        playerContainer.scrollIntoView({ behavior: 'smooth' });

        try {
            await player.load(url);
            video.play();
        } catch (err) {
            video.src = url;
            video.play();
        }
    }

    async function initPlayer() {
        shaka.polyfill.installAll();
        const ui = video['ui'];
        ui.configure({
            controlPanelElements: ["play_pause", "mute", "spacer", "fullscreen"],
            addSeekBar: false,
            overflowMenuButtons: []
        });
        const controls = ui.getControls();
        player = controls.getPlayer();
        player.configure({
            streaming: {
                lowLatencyMode: true,
                bufferingGoal: 1, // Start playback after 1 second of audio is buffered
                rebufferingGoal: 0.1, // Very quick recovery from buffering
                bufferBehind: 10
            },
            abr: {
                enabled: true,
                defaultBandwidthEstimate: 1000000, // Start with a 1Mbps estimate
                switchInterval: 2
            }
        });
    }

    function applyFilters() {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedCategory = categoryFilter.value;

        channelsToDisplay = channels.filter(channel => {
            const nameMatch = channel.name.toLowerCase().includes(searchTerm);
            const categoryMatch = selectedCategory === '' || channel.group === selectedCategory;
            return nameMatch && categoryMatch;
        });

        channelList.innerHTML = '';
        currentlyDisplayedChannels = [];
        loadMoreChannels();
    }

    searchInput.addEventListener('input', applyFilters);
    categoryFilter.addEventListener('change', applyFilters);

    logo.addEventListener('click', (e) => {
        e.preventDefault();
        location.reload();
    });

    refreshStreamBtn.addEventListener('click', () => {
        if (currentStreamUrl) {
            playChannel(currentStreamUrl);
        }
    });
});
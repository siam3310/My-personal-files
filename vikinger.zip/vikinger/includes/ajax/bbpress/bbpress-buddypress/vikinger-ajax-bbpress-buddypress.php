<?php
/**
 * AJAX - bbPress + BuddyPress
 * 
 * @package Vikinger
 * 
 * @since 1.9.1
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

/**
 * Group
 */
require_once VIKINGER_PATH . '/includes/ajax/bbpress/bbpress-buddypress/vikinger-ajax-bbpress-buddypress-group.php';

?>

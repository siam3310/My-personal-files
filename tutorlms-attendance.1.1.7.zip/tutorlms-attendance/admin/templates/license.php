<?php
/**
 * License Options
 */

defined( "ABSPATH" ) || exit;

if ( ! function_exists( 'get_plugin_data' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

$plugin_data           = get_plugin_data( TUTOR_LMS_ATTENDANCE_FILE );
$license_option_prefix = 'tutor_lms_attendance';
$license               = get_option( "{$license_option_prefix}_license_key" );
$status                = get_option( "{$license_option_prefix}_license_status" );

?>
<div class="wn_settings_wrap wn_wrap tlm-atd-panel tlm-atd-license">
    <form method="post">
		<?php
		settings_fields( "{$license_option_prefix}_license" );
		wp_nonce_field( "{$license_option_prefix}_nonce", "{$license_option_prefix}_nonce" );
		?>
		<?php if ( $status === 'valid' ): ?>
        <h2><?php echo _e( 'Congratulations! You are receiving automatic updates', 'tutor-lms-attendance' ) ?></h2>
		<?php else: ?>
		<h2><?php echo _e( 'Receive Automatic Updates', 'tutor-lms-attendance' ) ?></h2>
		<?php endif; ?>
		<?php if ( $status === 'valid' ): ?>
            <h4><?php  echo sprintf(__('Your license key has been verified and activated successfully, you will receive new features and improvements for "%s" automatically.', 'tutor-lms-attendance'), $plugin_data['Name']) ?></h4>
		<?php else: ?>
            <h4><?php echo  sprintf(__('Please enter the license key to keep your "%s" plugin updated, and receive new features and improvements automatically.' , 'tutor-lms-attendance'), $plugin_data['Name']) ?></h4>
            <h4><?php echo  sprintf(__('Don\'t have the license key? Click <a href="%s" target="_blank">here</a> to get one.','tutor-lms-attendance' ), $plugin_data['PluginURI']) ?></h4>
		<?php endif; ?>
        <table class="form-table">
            <tr>
                <th><label for="wn-license-key-field"><?php _e( 'License Key', 'tutor-lms-attendance' ); ?></label>
                </th>
        </tr>
        <tr>    
                <td>
                    <input class="regular-text" type="text" id="wn-license-key-field"
					       placeholder="<?php echo __('Enter license key provided with plugin', 'tutor-lms-attendance'); ?>"
                           name="<?php echo $license_option_prefix; ?>_license_key"
                           value="<?php esc_attr_e( $license ); ?>"
						<?php echo ( $status === 'valid' ) ? 'readonly' : ''; ?>><?php echo ( $status === 'valid' ) ? '<span class="dashicons dashicons-saved wn-license-activated-icon"></span>' : ''; ?>
                </td>
            </tr>
        </table>
        <p class="submit">
			<?php if ( $status !== 'valid' ) : ?>

                <input type="submit" name="<?php echo $license_option_prefix; ?>_license_activate"
                       value="<?php echo _e( 'Activate', 'tutor-lms-attendance' ); ?>"
                       class="button-primary"/>
			<?php else: ?>
                <input type="submit" name="<?php echo $license_option_prefix; ?>_license_deactivate"
                       value="<?php echo  _e( 'Deactivate', 'tutor-lms-attendance' ); ?>"
                       class="button-primary"/>
			<?php endif; ?>
        </p>
    </form>
</div>
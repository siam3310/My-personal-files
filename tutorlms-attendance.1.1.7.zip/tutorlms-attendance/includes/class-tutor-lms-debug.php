<?php

/**
 * Tutor LMS Attendance
 *
 * This file has all activity logs generation related functionality
 *
 * @author   WooNinjas
 * @category Admin
 * @version  1.0.0
 */

defined('ABSPATH') || exit;

class Tutor_Lms_DEBUG
{

	public $errors = array();
	var $debug_log_file = null;
	var $debug_log_option = null;

	public function __construct()
	{

		add_action('admin_init', [$this, 'clear_activity_log']);

		$upload_dir           = wp_upload_dir(null, false);
		$debug_log_filename   = 'tlms-attendance-activity.log';
		$this->debug_log_file = trailingslashit($upload_dir['basedir']) . $debug_log_filename;

		/** Activity LOG **/
		$options = get_option('tlms_at_options', array());
		$this->debug_log_option = isset($options['tutor_lms_att_activity_log']) && $options['tutor_lms_att_activity_log'] == 'on' ? $options['tutor_lms_att_activity_log'] : null;
		if (isset($this->debug_log_option) && $this->debug_log_option == 'on') {
			$this->set_custom_debug_log();
		} else {
			$this->delete_debug_log_file();
		}
	}

	public function delete_debug_log_file()
	{
		if (file_exists($this->debug_log_file)) {
			unlink($this->debug_log_file);
		}
	}

	public function set_custom_debug_log()
	{
		set_error_handler([$this, 'error_handler']);
		add_action('shutdown', [$this, 'shutdown_handler']);

		ini_set('log_errors', 1);
		ini_set('error_log', $this->debug_log_file);
	}

	public function shutdown_handler($array)
	{

		$error = error_get_last();

		if (empty($error) || (isset($error['file']) && !empty($error['file']) && $error['file'] != 'Unknown' && strpos('tutorlms-attendance', $error['file']) === false)) {
			return false;
		}

		(new Tutor_Lms_Logging())->log($error['message']);
		exit();
	}


	/**
	 * Debug Log function
	 *
	 * @param $var
	 * @param bool $print
	 * @param bool $show_execute_at
	 *
	 * displaying debug backtrace
	 */
	public static function debug_log($var, $print = true, $show_execute_at = false)
	{
		ob_start();

		if ($show_execute_at) {
			$bt         = debug_backtrace();
			$caller     = array_shift($bt);
			$execute_at = $caller['file'] . ':' . $caller['line'] . "\n";
			echo $execute_at;
		}

		if ($print) {
			if (is_object($var) || is_array($var)) {
				echo print_r($var, true);
			} else {
				echo $var;
			}
		} else {
			var_dump($var);
		}

		error_log(ob_get_clean());
	}

	public function error_handler($errno, $errstr, $errfile, $errline)
	{
		if (strpos('tutorlms-attendance', $errfile) !== false) {
			$this->debug_log($errfile, false, true);
			$errstr = esc_attr($errstr);
			(new Tutor_Lms_Logging())->log('error-' . $errstr);

			/*var_dump($errstr);
			WN_LD_Quiz_Import_Export_Helper::debug_log($errstr, false, true);*/

			//throw new Exception($errstr, $errno);

			/* Don't execute PHP internal error handler */

			//return true;

			return true;
		}
	}

	public function log_message($message)
	{
		//$debug_log_option = get_option( 'llms_qie_option_name' );
		if (isset($this->debug_log_option) && $this->debug_log_option == 'on') {
			$this->debug_log($message);
		}
	}

	/**
	 * Clear Activity Logs function
	 */
	function clear_activity_log()
	{

		$page   = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
		$tab    = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : '';
		$action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';

		if ($page === 'tlms-attendance' && $tab === 'activity_log' && $action === 'clear_activity_log') {
			(new Tutor_Lms_Logging())->clear_log();
			wp_safe_redirect(add_query_arg(array(
				'page' => 'tlms-attendance',
				'tab'  => 'activity_log',
			), admin_url('admin.php')));
		}
	}
}

return new Tutor_Lms_DEBUG();

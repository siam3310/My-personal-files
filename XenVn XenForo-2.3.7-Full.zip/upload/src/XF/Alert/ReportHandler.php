<?php

namespace XF\Alert;

/**
 * @extends AbstractHandler<\XF\Entity\Report>
 */
class ReportHandler extends AbstractHandler
{
}

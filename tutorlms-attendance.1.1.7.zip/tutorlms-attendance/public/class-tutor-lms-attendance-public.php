<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://wooninjas.com/
 * @since      1.0.0
 *
 * @package    Tutor_Lms_Attendance
 * @subpackage Tutor_Lms_Attendance/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Tutor_Lms_Attendance
 * @subpackage Tutor_Lms_Attendance/public
 * @author     WooNinjas
 */
class Tutor_Lms_Attendance_Public
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $plugin_name The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $version The current version of this plugin.
	 */
	private $version;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string $version The current version of this plugin.
	 */
	private $dashboard_page_name;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @param string $plugin_name The name of the plugin.
	 * @param string $version The version of this plugin.
	 *
	 * @since    1.0.0
	 */
	public function __construct($plugin_name, $version)
	{

		$this->plugin_name = $plugin_name;
		$this->version     = $version;
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Tutor_Lms_Attendance_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Tutor_Lms_Attendance_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/tutor-lms-attendance-public.css', array(), $this->version, 'all');
		wp_enqueue_style('chosen-css', plugin_dir_url(__FILE__) . 'css/chosen-min.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Tutor_Lms_Attendance_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Tutor_Lms_Attendance_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		/**
		 * DATA Table
		 */
		wp_enqueue_style('dataTablecss', '//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css');
		wp_enqueue_script('dataTablejs', "//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js", array('jquery'), false, true);

		// /**
		//  * DATA Table checkbox
		//  */
		// wp_enqueue_style('dataTable_checkbox_css', '//gyrocode.github.io/jquery-datatables-checkboxes/1.2.12/css/dataTables.checkboxes.css');
		// wp_enqueue_script('dataTable_checkbox_js', "//gyrocode.github.io/jquery-datatables-checkboxes/1.2.12/js/dataTables.checkboxes.min.js", array('jquery'), false, true);
		?>
		<div id="page-wrap">
			<span id="coordinates"></span>	
		</div>		
		<!-- Popup HTML -->
		<div id="logout-popup" class="popup">
		  <div class="popup-content">
		    <!-- <span class="close-btn">&times;</span> -->
		    <p>Don't forget to log out before exiting the page.</p>
		    <a href="<?php echo wp_logout_url(); ?>" class="logout-btn">Logout</a>
		    <button class="cancel-btn">Cancel</button>
		  </div>
		</div>

		<?php
		if ( !session_id() ) session_start();
		session_start();
		wp_enqueue_script('chosen-js', plugin_dir_url(__FILE__) . 'js/chosen-min.js', array('jquery'), $this->version, false);
		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/tutor-lms-attendance-public.js', array(
			'jquery',
			'chosen-js'
		), $this->version, false);

		$options = get_option('tlms_at_options');

		wp_localize_script(
			$this->plugin_name,
			'tlms_ajax_url',
			array(
				'ajax_url' => admin_url('admin-ajax.php'),
				'user_role' => wp_get_current_user()->roles,
				'sessionValue' => isset( $_SESSION['my_variable'] ) ? $_SESSION['my_variable'] : '',
				'user_tr_option' => isset( $options['tlms_at_user_track'] ) ? $options['tlms_at_user_track'] : ''
			)
		);
		wp_enqueue_script('jquery-form');
	}

	function update_session() {
	    if (!session_id()) session_start();

	    if (isset($_POST['value'])) {
	    	
	        $_SESSION['my_variable'] = sanitize_text_field($_POST['value']);
	        wp_send_json_success('Session updated');
	    } else {
	        wp_send_json_error('No value provided');
	    }
	}

	function tlms_attendance_lesson_callback()
	{
		$options = get_option('tlms_at_options', array());
		if (isset($options['disable_user_mark_attendance'])) {
			if (in_array('lesson', $options['disable_user_mark_attendance'])) {
				return;
			}
		}
		$course_id = tutor_utils()->get_course_id_by('lesson', get_the_ID());

		if (!is_user_logged_in() || !tutor_utils()->is_enrolled($course_id, get_current_user_id())) {
			return;
		}
		$date_to           = current_time('mysql');
		$date_from         = current_time('mysql');
		$attendance_exists = $this->check_user_attendance(get_current_user_id(), 'lesson_id', get_the_ID(), $date_from, $date_to);
		if (!empty($attendance_exists)) {
			return;
		}
?>
		<div id="tlms-mark-attendance-wrap" style="margin-top:10px;margin-left:10px;">
			<form id="tlms-mark-attendance-user" action="" method="post">
				<input type="hidden" name="action" value="tlms_front_mark_attendance">
				<input type="hidden" name="attendance_type" value="lesson">
				<input type="hidden" name="course_id" value="<?php echo get_the_ID(); ?>">
				<p><button type="submit" class="tutor-btn tutor-btn-outline-primary tad-mrk-atnd" data-default-text="<?php echo __('Mark Attendance', 'tutor-lms-attendance'); ?>" data-loading-text="<?php echo __('Loading...', 'tutor-lms-attendance'); ?>"><?php echo __('Mark Attendance', 'tutor-lms-attendance'); ?></button></p>
			</form>
		</div>
	<?php
	}

	function tlms_attendance_course_callback()
	{
		$options = get_option('tlms_at_options', array());
		if (isset($options['disable_user_mark_attendance'])) {
			if (in_array('course', $options['disable_user_mark_attendance'])) {
				return;
			}
		}
		if (!is_user_logged_in() || !tutor_utils()->is_enrolled(get_the_ID(), get_current_user_id())) {
			return;
		}
		$date_to           = current_time('mysql');
		$date_from         = current_time('mysql');
		$attendance_exists = $this->check_user_attendance(get_current_user_id(), 'course_id', get_the_ID(), $date_from, $date_to);
		if (!empty($attendance_exists)) {
			return;
		}
		// ob_start();
	?>
		<div id="tlms-mark-attendance-wrap">
			<form id="tlms-mark-attendance-user" action="" method="post">
				<input type="hidden" name="action" value="tlms_front_mark_attendance">
				<input type="hidden" name="attendance_type" value="course">
				<input type="hidden" name="course_id" value="<?php echo get_the_ID(); ?>">
				<p>
					<button type="submit" class="tutor-btn tutor-btn-outline-primary tad-mrk-atnd" data-default-text="<?php echo __('Mark Attendance', 'tutor-lms-attendance'); ?>" data-loading-text="<?php echo __('Loading...', 'tutor-lms-attendance'); ?>"><?php echo __('Mark Attendance', 'tutor-lms-attendance'); ?></button>
				</p>
			</form>
		</div>
		<?php

		// return ob_get_clean();

		// die();
	}

	function tlms_front_mark_attendance_cb()
	{
		$course_id     = $_POST['course_id'];
		$type          = $_POST['attendance_type'];
		$content       = ($_POST['attendance_type'] == 'course') ? 'course_id' : 'lesson_id';
		$user_id       = get_current_user_id();
		$is_restricted = $this->check_is_restricted_ip($this->get_client_ip(), $user_id, $course_id, $content);

		if (!$is_restricted) {
			$response = array(
				'status'  => 'error',
				'message' => 'Restricted IP',
			);
			wp_send_json($response);
		} else {
			$id       = $this->mark_attendance($course_id, $user_id, 'present', '', null, $type);
			$response = array(
				'status'  => 'success',
				'message' => $id,
			);
			wp_send_json($response);
		}
	}

	/**
	 *
	 * Mark attendance on the bases of given arguements
	 *
	 * @param $resource_id
	 * @param $user_id
	 * @param $attendance_type
	 * @param $comment
	 * @param $attendance_date
	 * @param $resource_type
	 *
	 * @return int
	 */
	public function mark_attendance($resource_id, $user_id, $attendance_type = 'present', $comment = '', $attendance_date = null, $resource_type = 'course')
	{
		global $wpdb;

		$table_attendance_logs = $wpdb->prefix . 'tlms_attendance_logs';

		$ip_address = $this->get_client_ip();
		$device_id  = wp_is_mobile() ? $_SERVER['HTTP_USER_AGENT'] : 'desktop';

		$date_from = current_time('mysql');
		$date_to   = current_time('mysql');
		$date      = current_time('mysql');

		if (!empty($attendance_date)) {
			$datetime  = new DateTime($attendance_date, wp_timezone());
			$date      = $datetime->format('Y-m-d H:i:s');
			$date_from = $date;
			$date_to   = $date;
		}

		$resource_field    = "{$resource_type}_id";
		$attendance_exists = $this->check_user_attendance($user_id, $resource_field, $resource_id, $date_from, $date_to);

		if (empty($attendance_exists)) {

			if (isset($resource_type) && !empty($resource_type) && $resource_type != 'course') {
				if ($resource_type == 'lesson') {
					$resource_array = array('lesson_id' => $resource_id);
				}
				if ($resource_type == 'topic') {
					$resource_array = array('topic_id' => $resource_id);
				}

				$data = array(
					'user_id'         => $user_id,
					'ip_address'      => $ip_address,
					'device_id'       => $device_id,
					'log_by_user_id'  => get_current_user_id(),
					'attendance_type' => $attendance_type,
					'comment'         => $comment,
					'created_at'      => $date
				);

				$data = array_merge($resource_array, $data);
			} else {
				$data = array(
					'course_id'       => $resource_id,
					'user_id'         => $user_id,
					'ip_address'      => $ip_address,
					'device_id'       => $device_id,
					'log_by_user_id'  => get_current_user_id(),
					'attendance_type' => $attendance_type,
					'comment'         => $comment,
					'created_at'      => $date
				);
			}

			$format = array(
				'%d',
				'%d',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
				'%s'
			);

			$wpdb->insert($table_attendance_logs, $data, $format);
			$id = $wpdb->insert_id;
			(new Tutor_Lms_DEBUG())->log_message('Inserting attendance in database...', 'tutor-lms-attendance');
		} else {
			$id = $attendance_exists[0]['id'];

			$data = array(
				'log_by_user_id'  => get_current_user_id(),
				'attendance_type' => $attendance_type,
				'comment'         => $comment,
			);

			$where = array(
				'id' => $id,
			);

			$format = array(
				'%d',
				'%s',
				'%s'
			);

			$wpdb->update($table_attendance_logs, $data, $where, $format);
			(new Tutor_Lms_DEBUG())->log_message('Updating attendance in database...', 'tutor-lms-attendance');
		}

		$attendance_count = tlms_attendance_get(array(
			'course_ids' => array($course_id ?? null),
			'user_ids'   => $user_id,
			'no_group'   => true,
		));

		$count      = count($attendance_count);
		$percentage = tlms_attendance_get_percentage($count);

		do_action('learndash_mark_attendance', $user_id, ($course_id ?? null), $percentage, $count);

		return $id;
	}

	/**
	 *
	 * Checks user attendance for specific course, lesson and topic
	 *
	 * @param $user_id
	 * @param $resource_type
	 * @param $resource_id
	 *
	 * @return array
	 */
	private function check_user_attendance($user_id, $resource_type = null, $resource_id = null, $date_from = null, $date_to = null)
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'tlms_attendance_logs';

		$result = $wpdb->get_results("SELECT * FROM {$table_name} WHERE 1=1 AND DATE(created_at) >= DATE('{$date_from}') AND DATE(created_at) <= DATE('{$date_to}')  AND (user_id = {$user_id}) AND ({$resource_type} = {$resource_id})", ARRAY_A);

		return $result;
	}

	/**
	 *
	 * Get current active user IP
	 *
	 * @return string
	 */
	private function get_client_ip()
	{
		$ipaddress = '';
		if (isset($_SERVER['HTTP_CLIENT_IP'])) {
			$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} elseif (isset($_SERVER['HTTP_X_FORWARDED'])) {
			$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
		} elseif (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
			$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
		} elseif (isset($_SERVER['HTTP_FORWARDED'])) {
			$ipaddress = $_SERVER['HTTP_FORWARDED'];
		} elseif (isset($_SERVER['REMOTE_ADDR'])) {
			$ipaddress = $_SERVER['REMOTE_ADDR'];
		} else {
			$ipaddress = 'UNKNOWN';
		}

		$comma_ipaddress = explode(',', $ipaddress);

		if (isset($comma_ipaddress[0]) && !empty($comma_ipaddress[0])) {
			return $comma_ipaddress[0];
		}

		return $ipaddress;
	}


	function tlms_admin_mark_attendance_front_cb()
	{
		$options        = get_option('tlms_at_options', array());
		$selected_roles = isset($options['tlms_at_attendance_allow_user_roles']) ? $options['tlms_at_attendance_allow_user_roles'] : array();

		$roles = array();
		if (is_user_logged_in()) {

			$user = wp_get_current_user();

			$roles = $user->roles;
		}
		if ((current_user_can('administrator') || array_intersect($selected_roles, $roles)) && isset($options['tlms_at_manual_attendance']) && $options['tlms_at_manual_attendance'] == 'on') {
			$users = get_users(array('fields' => array('ID')));
			(new Tutor_Lms_DEBUG())->log_message('Admin marking course attendance...', 'tutor-lms-attendance');
		?>
			<div id="tlmsat-mark-attendance-wrap" class="tlmsat-mark-attendance-wrap">
				<form id="tlmsat-mark-attendance-form" action="" method="post">
					<?php wp_nonce_field('tlmsat_mark_attendance_form_submit'); ?>
					<input type="hidden" name="action" value="tlmsat_front_mark_attendance">
					<input type="hidden" name="course_id" value="<?php echo get_the_ID(); ?>">
					<input type="hidden" name="attendance_type" value="present">
					<div id="tlms-at_front_msg-box" style="display:none;">
						<h4 class="tlmsat-mark-attendance-h4"><?php echo apply_filters('tlms_at_attendance_front_select_label', __('Course Mark Attendance', 'tutor-lms-attendance')); ?></h4>
						<div id="tlms_at_success" class="frontend_box frontend_box-success" style="display:none;">
							<?php echo __('Students attendance marked successfully.
                        ', 'tutor-lms-attendance'); ?></div>
						<div id="tlms_at_failed" class="frontend_box frontend_box-fail" style="display:none;"></div>
					</div>
					<h4 class="tlmsat-mark-attendance-h4"><?php echo apply_filters('tlms_at_attendance_front_select_label', __('Mark attendance for selected students', 'tutor-lms-attendance')); ?></h4>
					<select style="width:100%" id="tlmsat_mark_attendance_users" name="tlmsat_mark_attendance_users[]" data-placeholder="<?php echo __('Select users to mark attendance', 'tutor-lms-attendance'); ?>" multiple class="chosen-select">
						<?php
						foreach ($users as $user) {
							$user_info         = get_userdata($user->ID);
							$date_to           = current_time('mysql');
							$date_from         = current_time('mysql');
							$attendance_exists = $this->check_user_attendance($user->ID, 'course_id', get_the_ID(), $date_from, $date_to);
							if (tutor_utils()->is_enrolled(get_the_ID(), $user->ID) && empty($attendance_exists)) { ?>
								<option value='<?php echo $user->ID ?>'><?php echo $user_info->display_name . '(' . $user_info->user_email . ')' ?></option>

						<?php }
						} ?>
					</select>

					<p class="tlmsat-mark-attendance-p">
						<label><?php echo apply_filters('wn_ld_attendance_front_message_label', __('Message', 'tutor-lms-attendance')); ?></label>
						<?php wp_editor('', 'tlmsat_mark_attendance_comment', array('textarea_rows' => 4)); ?>
					</p>
					<p>
						<label><input type="radio" name="tlmsat_mark_attendance_type" value="absent" checked> <?php echo __('Absent', 'tutor-lms-attendance'); ?></label> &nbsp;&nbsp;
						<label><input type="radio" name="tlmsat_mark_attendance_type" value="present"> <?php echo __('Present', 'tutor-lms-attendance'); ?></label>
					</p>
					<p>
						<button type="submit" class="tutor-btn tutor-btn-outline-primary " data-default-text="<?php echo apply_filters('attendance_group_admin_button_text', __('Mark Attendance', 'tutor-lms-attendance')); ?>" data-loading-text="<?php echo apply_filters('attendance_group_admin_loading_text', __('Loading...', 'tutor-lms-attendance')); ?>"><?php echo apply_filters('attendance_group_admin_button_text', __('Mark Attendance', 'tutor-lms-attendance')); ?></button>
					</p>
				</form>
			</div>
		<?php
		}
	}


	function tlms_admin_mark_attendance_lesson_front_cb()
	{
		$roles          = array();
		$options        = get_option('tlms_at_options', array());
		$selected_roles = isset($options['tlms_at_attendance_allow_user_roles']) ? $options['tlms_at_attendance_allow_user_roles'] : array();
		if (is_user_logged_in()) {
			$user  = wp_get_current_user();
			$roles = $user->roles;
		}
		if ((current_user_can('administrator') || array_intersect($selected_roles, $roles)) && isset($options['tlms_at_manual_attendance']) && $options['tlms_at_manual_attendance'] == 'on') {
			$users = get_users(array('fields' => array('ID')));
			(new Tutor_Lms_DEBUG())->log_message('Admin marking lesson attendance...', 'tutor-lms-attendance');
		?>
			<div id="tlmsat-mark-attendance-wrap" class="tlmsat-mark-attendance-wrap">
				<form id="tlmsat-mark-attendance-form" action="" method="post">
					<?php wp_nonce_field('tlmsat_mark_attendance_form_submit'); ?>
					<input type="hidden" name="action" value="tlmsat_front_mark_attendance">
					<input type="hidden" name="lesson_id" value="<?php echo get_the_ID(); ?>">
					<input type="hidden" name="attendance_type" value="present">
					<div id="tlms-at_front_msg-box" style="display:none;">
						<h4 class="tlmsat-mark-attendance-h4"><?php echo apply_filters('tlms_at_attendance_front_select_label', __('Lesson Mark Attendance', 'tutor-lms-attendance')); ?></h4>
						<div id="tlms_at_success" class="frontend_box frontend_box-success" style="display:none;">
							<?php echo __('Students attendance marked successfully.
                        ', 'tutor-lms-attendance') ?></div>
						<div id="tlms_at_failed" class="frontend_box frontend_box-fail" style="display:none;"></div>
					</div>
					<h4 class="tlmsat-mark-attendance-h4"><?php echo apply_filters('tlms_at_attendance_front_select_label', __('Mark attendance for selected students', 'tutor-lms-attendance')); ?></h4>
					<select style="width:100%" id="tlmsat_mark_attendance_users" name="tlmsat_mark_attendance_users[]" data-placeholder="<?php echo __('Select users to mark attendance', 'tutor-lms-attendance'); ?>" multiple class="chosen-select">
						<?php
						foreach ($users as $user) {
							$user_info         = get_userdata($user->ID);
							$date_to           = current_time('mysql');
							$date_from         = current_time('mysql');
							$attendance_exists = $this->check_user_attendance($user->ID, 'lesson_id', get_the_ID(), $date_from, $date_to);
							$course_id         = tutor_utils()->get_course_id_by('lesson', get_the_ID());
							if (tutor_utils()->is_enrolled($course_id, $user->ID) && empty($attendance_exists)) { ?>
								<option value='<?php echo $user->ID ?>'><?php echo $user_info->display_name . '(' . $user_info->user_email . ')' ?></option>

						<?php }
						} ?>
					</select>

					<p class="tlmsat-mark-attendance-p">
						<label><?php echo apply_filters('wn_ld_attendance_front_message_label', __('Message', 'tutor-lms-attendance')); ?></label>
						<?php wp_editor('', 'tlmsat_mark_attendance_comment', array('textarea_rows' => 4)); ?>
					</p>
					<p>
						<label><input type="radio" name="tlmsat_mark_attendance_type" value="absent" checked> <?php echo __('Absent', 'tutor-lms-attendance'); ?></label> &nbsp;&nbsp;
						<label><input type="radio" name="tlmsat_mark_attendance_type" value="present"> <?php echo __('Present', 'tutor-lms-attendance'); ?></label>
					</p>
					<p>
						<button type="submit" class="tutor-btn tutor-btn-outline-primary " data-default-text="<?php echo apply_filters('attendance_group_admin_button_text', __('Mark Attendance', 'tutor-lms-attendance')); ?>" data-loading-text="<?php echo apply_filters('attendance_group_admin_loading_text', __('Loading...', 'tutor-lms-attendance')); ?>"><?php echo apply_filters('attendance_group_admin_button_text', __('Mark Attendance', 'tutor-lms-attendance')); ?></button>
					</p>
				</form>
			</div>
			<?php
		}
	}

	/**
	 * Aajax call to mark frontend attendance
	 */
	public function ajax_tlmsat_front_mark_attendance_cb()
	{
		$response = array(
			'status'  => 'error',
			'message' => __('An unknown error occurred, please try again later.', 'tutor-lms-attendance'),
		);

		if (
			isset($_POST['_wpnonce'])
			&& wp_verify_nonce($_POST['_wpnonce'], 'tlmsat_mark_attendance_form_submit')
		) {

			if (isset($_POST['tlmsat_mark_attendance_users']) && (is_numeric($_POST['tlmsat_mark_attendance_users']) || is_array($_POST['tlmsat_mark_attendance_users'])) && !empty($_POST['tlmsat_mark_attendance_users'])) {

				if (is_numeric($_POST['tlmsat_mark_attendance_users'])) {
					$mark_attendance_user_ids[] = $_POST['tlmsat_mark_attendance_users'];
				} else {
					$mark_attendance_user_ids = array_filter(array_map('absint', $_POST['tlmsat_mark_attendance_users']));
				}

				if (!empty($mark_attendance_user_ids)) {

					if (isset($_POST['course_id'])) {
						$resource_id   = absint($_POST['course_id']);
						$resource_type = 'course';
					}
					if (isset($_POST['lesson_id'])) {
						$resource_id   = absint($_POST['lesson_id']);
						$resource_type = 'lesson';
					}
					if (isset($_POST['topic_id'])) {
						$resource_id   = absint($_POST['topic_id']);
						$resource_type = 'topic';
					}

					// $course_id = learndash_get_course_id( absint( $_POST['course_id'] ) );

					if (!empty($resource_id) && !empty($resource_type)) {

						$type    = sanitize_text_field($_POST['tlmsat_mark_attendance_type']);
						$comment = str_replace('\"', "'", $_POST['tlmsat_mark_attendance_comment']);

						$attendance_log_ids = array();

						foreach ($mark_attendance_user_ids as $mark_attendance_user_id) {
							$attendance_log_ids[] = $this->mark_attendance($resource_id, $mark_attendance_user_id, $type, $comment, null, $resource_type);
						}

						if (!empty($attendance_log_ids)) {
							(new Tutor_Lms_DEBUG())->log_message('Marking student attendance...', 'tutor-lms-attendance');
							$response = array(
								'status'  => 'success',
								'message' => __('Students attendance marked successfully.', 'tutor-lms-attendance'),
							);
						} else { // Attendance already marked
							// TODO: Change success message when necessary
							$response = array(
								'status'  => 'error',
								'message' => __('Students attendance marked successfully.', 'tutor-lms-attendance'),
							);
						}
					} else {
						$response['message'] = __('Invalid course', 'tutor-lms-attendance');
					}
				}
			} else {
				$response['message'] = __('Please select students first', 'tutor-lms-attendance');
			}
		}

		wp_send_json($response);
	}

	private function check_is_restricted_ip($user_ip, $user_id, $id, $content)
	{
		$options = get_option('tlms_at_options', array());

		$user_lesson_last_attendance_ip = $this->get_user_lesson_last_attendance_ip($user_id, $id, $content);

		$is_restrict_ip = ($options['tlms_at_restrict_ip'] == 'on') ? $options['tlms_at_restrict_ip'] : 'no';

		if ($is_restrict_ip == 'on') {
			(new Tutor_Lms_DEBUG())->log_message('Checking user IP...', 'tutor-lms-attendance');
			if (empty($user_lesson_last_attendance_ip) || $user_lesson_last_attendance_ip == $user_ip) {
				return true;
			} else {
				return false;
			}
		}

		return true;
	}

	private function get_user_lesson_last_attendance_ip($user_id, $id, $content_type)
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'tlms_attendance_logs';
		$result     = $wpdb->get_var("SELECT ip_address FROM {$table_name} WHERE (user_id = {$user_id}) AND ($content_type = {$id}) ORDER BY id DESC LIMIT 1");

		return $result;
	}

	/**
	 * add attendance tab in user dashboard
	 *
	 * @param [array] $default_menu
	 * @return array
	 */
	public function add_attendance_tabs_dashboard($default_menu)
	{
		$custom_array = array(
			'separator-new' =>
			array(
				'title' => 'Attendance',
				'auth_cap' => 'parent',
				'type' => 'separator',
			),

			'course_attendance'            => array(
				'title' => __('Attendance', 'tutor'),
				'icon'  => 'tutor-icon-user-group',

			),
		);
		$option = get_option('tlms_at_options');
		if (isset($option['tlms_at_user_celendar']) && $option['tlms_at_user_celendar'] == 'on') {
			// error_log('option:' . var_export($option, true));
			$default_menu = array_merge($default_menu, $custom_array);
		}
		return $default_menu;
	}

	/**
	 * set attendance calendar temlate 
	 *
	 * @param [string] $other_location
	 * @return string
	 */
	public function set_attendance_template_dashboard($other_location)
	{
		$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		if (strpos($actual_link, 'course_attendance') !== false) {
			$other_location =  plugin_dir_path(dirname(__FILE__)) .
				'/tutor/templates/dashboard/course_attendance.php';
			return $other_location;
		}
		return $other_location;
	}

	/**
	 * 
	 *
	 * @param [type] $is_completed
	 * @param [type] $course_id
	 * @param [type] $user_id
	 * @return boolean
	 */
	public function is_completed_course($is_completed, $course_id, $user_id)
	{
		$minimum_attendance = get_post_meta($course_id, '_minimum_attendance_tlms_at', true);
		// error_log('result:' . var_export($minimum_attendance, true));
		global $wpdb;
		$table_name = $wpdb->prefix . 'tlms_attendance_logs';
		$result = $wpdb->get_results("SELECT COUNT(id) as ids FROM {$table_name} where user_id = $user_id AND course_id = $course_id");
		if (isset($result[0]->ids) && $minimum_attendance != 0) {
			if ($result[0]->ids >= $minimum_attendance) {

				return $is_completed;
			} else {

			?>
				<script>
					// Disable the button by its class
					jQuery(document).ready(function() {
						var btn = jQuery('button[name="complete_course_btn"]').prop('disabled', true);
					});
				</script>
<?php
				return $is_completed = false;
			}
		} else {
			return $is_completed;
		}
	}

	/**
	 * add minimum attendance message
	 *
	 * @return void
	 */
	public function add_miminum_attendance_message()
	{
		$post_id = get_the_ID();
		$user_id = get_current_user_id();
		$minimum_attendance = get_post_meta($post_id, '_minimum_attendance_tlms_at', true);
		global $wpdb;
		$table_name = $wpdb->prefix . 'tlms_attendance_logs';
		$result = $wpdb->get_results("SELECT COUNT(id) as ids FROM {$table_name} where user_id = $user_id AND course_id = $post_id");
		if (isset($result[0]->ids) && $minimum_attendance != 0) {
			if ($result[0]->ids >= $minimum_attendance) {
			} else {
				$option = get_option('tlms_at_options');
				if (isset($option['tutor_lms_att_minimum_attendance'])) {
					// error_log('tlms_at_options else:' . var_export($option, true));
					echo '<p>' . $option['tutor_lms_att_minimum_attendance'] . '</p>';
				}
				// echo '<p> users are required to mark their attendance a minimum of ' . $minimum_attendance . ' times.</p>';
			}
		} else {
		}
	}

	/**
	 * get course data 
	 *
	 * @return void
	 */
	public function tlms_at_get_attendance_data()
	{
		$course_id = isset($_POST['course_id']) && !empty($_POST['course_id'])  ? $_POST['course_id'] : '';

		if ($course_id !== '') {
			global $wpdb;
			$table_name = $wpdb->prefix . 'tlms_attendance_logs';
			$user_current_id = get_current_user_id();

			$result = $wpdb->get_results("SELECT * FROM {$table_name} where user_id = $user_current_id AND course_id = $course_id ");
			$calendar_attendance_data = [];

			if (is_array($result) && count($result) != 0) {
				foreach ($result as $attendance_data) {
					$post_title = get_the_title($attendance_data->course_id);
					$title =  $attendance_data->attendance_type . ' in ' . $post_title;
					$attendance_date  = explode(" ", $attendance_data->created_at);
					$att_type         = strtoupper($attendance_data->attendance_type);
					if ($att_type == 'PRESENT') {
						$calendar_array   = ['title' => $att_type, 'start' => $attendance_date[0], "backgroundColor" => "green",  "textColor" => "white",];
					} else {
						$calendar_array   = ['title' => $att_type, 'start' => $attendance_date[0], "backgroundColor" => "red",  "textColor" => "white",];
					}
					array_push($calendar_attendance_data, $calendar_array);
				}
				error_log('result :' . var_export($calendar_attendance_data, true));
			}
			wp_send_json($calendar_attendance_data);
		}
	}
}

<?php

$tlms_at_options = get_option('tlms_at_options', array());

$tlms_at_restrict_ip = !empty($tlms_at_options['tlms_at_restrict_ip']) ? $tlms_at_options['tlms_at_restrict_ip'] : 'no';
$tlms_at_user_track = !empty($tlms_at_options['tlms_at_user_track']) ? $tlms_at_options['tlms_at_user_track'] : 'no';
$tlms_at_user_celendar = !empty($tlms_at_options['tlms_at_user_celendar']) ? $tlms_at_options['tlms_at_user_celendar'] : 'no';
$manual_attendance   = !empty($tlms_at_options['tlms_at_manual_attendance']) ? $tlms_at_options['tlms_at_manual_attendance'] : 'no';
$show_universal_time   = !empty($tlms_at_options['tlms_show_universal_time']) ? $tlms_at_options['tlms_show_universal_time'] : 'no';
$delete_attendance   = !empty($tlms_at_options['tlms_at_delete_attendance']) ? $tlms_at_options['tlms_at_delete_attendance'] : 'no';

$disable_user_mark_attendance         = isset($tlms_at_options['disable_user_mark_attendance']) ? $tlms_at_options['disable_user_mark_attendance'] : array();
$disable_user_attendance_email_option = !empty($tlms_at_options['tlms_at_disable_user_attendance_email_option']) ? $tlms_at_options['tlms_at_disable_user_attendance_email_option'] : 'no';

$attendance_email_report_duration = !empty($tlms_at_options['tlms_at_attendance_email_report_duration']) ? $tlms_at_options['tlms_at_attendance_email_report_duration'] : 'week';


$attendance_email_report_count = !empty($tlms_at_options['tlms_at_attendance_email_report_count']) ? $tlms_at_options['tlms_at_attendance_email_report_count'] : 'percentage';

// Automatic Attendance on login
$automatic_attendance_on_login = !empty($tlms_at_options['tlms_at_automatic_attendance_on_login']) ? $tlms_at_options['tlms_at_automatic_attendance_on_login'] : 'no';
$auto_att_options              = isset($tlms_at_options['tlms_auto_attendance_options']) ? $tlms_at_options['tlms_auto_attendance_options'] : array();

// New option to show absents count of unmarked days in report and detail logs 
$show_absent_of_unmarked_days = !empty($tlms_at_options['tlms_at_show_absent_of_unmarked_days']) ? $tlms_at_options['tlms_at_show_absent_of_unmarked_days'] : 'no';

// Allowed user roles to mark attendance
$tlms_at_attendance_allow_user_roles = !empty($tlms_at_options['tlms_at_attendance_allow_user_roles']) ? $tlms_at_options['tlms_at_attendance_allow_user_roles'] : array();

// New option to show activity logs
$activity_log = !empty($tlms_at_options['tutor_lms_att_activity_log']) ? $tlms_at_options['tutor_lms_att_activity_log'] : 'no';

// New option to show debug logs
$debug_log = !empty($tlms_at_options['tutor_lms_att_debug_log']) ? $tlms_at_options['tutor_lms_att_debug_log'] : 'no';
$minimum_att_text = !empty($tlms_at_options['tutor_lms_att_minimum_attendance']) ? $tlms_at_options['tutor_lms_att_minimum_attendance'] : 'Your attendance falls below the minimum requirement. To complete this course, kindly ensure you have fulfilled the attendance criteria..';


?>
<div id="tlms_at-general-options" class="tlm-atd-panel">
	<form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="POST">
		<input type="hidden" name="action" value="tlms_at_admin_settings">
		<?php wp_nonce_field('tlms_at_admin_settings_action', 'tlms_at_admin_settings_field'); ?>
		<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Restrict IP', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i>
						</label>
						<p class="description"><?php _e('If enabled, students will be allowed to mark attendance from single IP address only', 'tutor-lms-attendance'); ?></p>
					</th>
					<td>
						<input type="checkbox" name="tlms_at_restrict_ip" id="tlms_at_restrict_ip" <?php checked(true, ($tlms_at_restrict_ip == 'on')); ?> />

					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Enable User Time Tracking', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i>
						</label>
						<p class="description"><?php _e('This option track user login and logout time.', 'tutor-lms-attendance'); ?></p>
					</th>
					<td>
						<input type="checkbox" name="tlms_at_user_track" id="tlms_at_user_track" <?php checked(true, ($tlms_at_user_track == 'on')); ?> />

					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Enable User Calendar', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i>
						</label>
						<p class="description"><?php _e('This option enable user calendar view in the TutorLMS dashboard.', 'tutor-lms-attendance'); ?></p>
					</th>
					<td>
						<input type="checkbox" name="tlms_at_user_celendar" id="tlms_at_user_celendar" <?php checked(true, ($tlms_at_user_celendar == 'on')); ?> />

					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Enable Admin Mark Attendance', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i>
						</label>
						<p class="description"><?php _e('If enabled `Admin` and `Tutor Instructors` can mark attendance for students from course, lesson pages', 'tutor-lms-attendance'); ?></p>
					</th>
					<td>
						<input type="checkbox" name="tlms_at_manual_attendance" id="tlms_at_manual_attendance" <?php checked(($manual_attendance == 'on'), true); ?> />

					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Delete Attendance On Uninstall  ', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i>
						</label>
						<p class="description"><?php _e('If enabled it will delete all courses, lessons attendance data', 'tutor-lms-attendance'); ?></p>
					</th>

					<td>
						<input type="checkbox" name="tlms_at_delete_attendance" id="tlms_at_delete_attendance" <?php checked(true, $delete_attendance == 'on'); ?> />

					</td>
				</tr>
				<!-- Start - Automatic Attendance on login Option -->
				<tr valign="top">
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Enable Automatic attendance on login', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i>
						</label>
						<p class="description"><?php _e('If enabled it mark user all courses, lessons attendance on login', 'tutor-lms-attendance'); ?></p>
					</th>
					<td>
						<input type="checkbox" name="tlms_at_automatic_attendance_on_login" id="tlms_at_automatic_attendance_on_login" <?php checked(true, $automatic_attendance_on_login == 'on'); ?> />
						<ul id="wn_lda_disable_mark_attendance" style="<?php echo empty($auto_att_options) ? 'display:none;' : ''; ?>">
							<li><label>
									<input type="checkbox" name="login_auto_att[]" id="auto_att_course" value="course" <?php checked(true, in_array('course', $auto_att_options)); ?> /><?php _e('Courses', 'tutor-lms-attendance'); ?>
								</label></li>
							<li><label>
									<input type="checkbox" name="login_auto_att[]" id="auto_att_lesson" value="lesson" <?php checked(true, in_array('lesson', $auto_att_options)); ?> /><?php _e('Lessons', 'tutor-lms-attendance'); ?>
								</label></li>
						</ul>

					</td>
				</tr>
				<!-- End - Automatic Attendance on login Option -->
				<tr valign="top">
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Disable mark attendance for users', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i>
						</label>
						<p class="description"><?php _e('If enabled users won\'t be able to mark their attendance, only tutor instructor/admin can mark attendance for them.', 'tutor-lms-attendance'); ?></p>
					</th>
					<td>
						<input type="checkbox" name="tlms_at_disable_user_mark_attendance_temp" id="tlms_at_disable_user_mark_attendance" value="1" <?php checked(true, !empty($disable_user_mark_attendance)); ?> />
						<ul id="wn_lda_disable_mark_attendance" style="<?php echo empty($disable_user_mark_attendance) ? 'display:none;' : ''; ?>">
							<li><label>
									<input type="checkbox" name="tlms_at_disable_user_mark_attendance[]" id="tlms_at_disable_user_course_mark_attendance" value="course" <?php checked(true, in_array('course', $disable_user_mark_attendance)); ?> /><?php _e('Courses', 'tutor-lms-attendance'); ?>
								</label></li>
							<li><label>
									<input type="checkbox" name="tlms_at_disable_user_mark_attendance[]" id="tlms_at_disable_user_lesson_mark_attendance" value="lesson" <?php checked(true, in_array('lesson', $disable_user_mark_attendance)); ?> /><?php _e('Lessons', 'tutor-lms-attendance'); ?>
								</label></li>
						</ul>

					</td>
				</tr>
				<tr valign="top">
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Allow selected user roles to mark attendance', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i>
						</label>
						<p class="description"><?php _e('Select user role which you want to allow to mark student(s) attendance', 'tutor-lms-attendance'); ?></p>
					</th>
					<td>
						<input type="checkbox" name="tlms_at_attendance_allow_user_roles_temp" id="tlms_at_attendance_allow_user_roles" value="1" <?php checked(true, !empty($tlms_at_attendance_allow_user_roles)); ?> />
						<ul id="wn_tlms_at_attendance_allow_user_roles" style="<?php echo empty($tlms_at_attendance_allow_user_roles) ? 'display:none;' : ''; ?>">
							<?php
							global $wp_roles;
							$roles = $wp_roles->roles;
							?>
							<?php foreach ($roles as $key => $role) : ?>
								<?php if ($key == 'administrator' || $key == 'subscriber') : ?>
									<?php continue; ?>
								<?php endif ?>
								<li><label>
										<input type="checkbox" name="tlms_at_attendance_allow_user_roles[]" id="tlms_at_attendance_allow_user_roles" value="<?php echo $key; ?>" <?php checked(true, in_array($key, $tlms_at_attendance_allow_user_roles)); ?> />
										<?php 
											switch ($key) {
												case 'editor':
													_e('Editor', 'tutor-lms-attendance');
													break;
												case 'author':
													_e('Author', 'tutor-lms-attendance');
													break;
												case 'contributor':
													_e('Contributor', 'tutor-lms-attendance');
													break;
												case 'customer':
													_e('Customer', 'tutor-lms-attendance');
													break;
												case 'shop_manager':
													_e('Shop Manager', 'tutor-lms-attendance');
													break;
												case 'parent':
													_e('Parent', 'tutor-lms-attendance');
													break;
												case 'tutor_instructor':
													_e('Customer', 'tutor-lms-attendance');
													break;
												case 'translator':
													_e('Translator', 'tutor-lms-attendance');
													break;										

											}
										?>
									</label></li>
							<?php endforeach ?>
						</ul>

					</td>
				</tr>
				<!-- End - Allowed user roles Option -->
				<tr valign="top">
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Display Local Time in User Activity Time', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i>
						</label>
						<p class="description"><?php _e('If enabled, the user login and logout times will be displayed in the local format', 'tutor-lms-attendance'); ?></p>
					</th>
					<td>
						<input type="checkbox" name="tlms_show_universal_time" id="tlms_show_universal_time" <?php checked(($show_universal_time == 'on'), true); ?> />

					</td>
				</tr>
				<!-- Activity Log -->
				<tr>
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Enable Activity Logs', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i></label>
						<p class="description"><?php _e('Enable this option to generate import activity logs and send to our support team.', 'tutor-lms-attendance'); ?></p>
					</th>
					<td>
						<fieldset>
							<legend class="screen-reader-text">
								<span><?php _e('Enable Activity Logs', 'tutor-lms-attendance'); ?></span>
							</legend>
							<label class="qst-mrk-tlms-atd">
								<input name="tutor_lms_att_activity_log" type="checkbox" id="tutor_lms_att_activity_log" <?php checked(($activity_log == 'on'), true); ?>>
								<?php _e('Yes', 'tutor-lms-attendance'); ?>
							</label>
						</fieldset>
					</td>
				</tr>

				<!-- Debug Log -->
				<tr>
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Enable Debug Logs', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i></label>
						</label>
						<p class="description"><?php _e('Enable this option to generate import debug logs and send to our support team.', 'tutor-lms-attendance'); ?></p>
						<p class="description" style="color: red;"><?php _e(sprintf('Warning: Debug logs can increase rapidly and occupy lot of server storage, be sure to enable it only when needed.'), 'tutor-lms-attendance'); ?></p>
					</th>
					<td>
						<fieldset>
							<legend class="screen-reader-text">
								<span><?php _e('Enable Debug Logs', 'tutor-lms-attendance'); ?></span>
							</legend>
							<label class="qst-mrk-tlms-atd">
								<input name="tutor_lms_att_debug_log" type="checkbox" id="tutor_lms_att_debug_log" <?php checked(($debug_log == 'on'), true); ?>>
								<?php _e('Yes', 'tutor-lms-attendance'); ?>
							</label>
						</fieldset>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label class="qst-mrk-tlms-atd">
							<?php _e('Minimum Attendance', 'tutor-lms-attendance'); ?>
							<i class="fas fa-question"></i></label>
						</label>
						<p class="description"><?php _e(' Set the minimum required attendance for each course from its settings.', 'tutor-lms-attendance'); ?></p>
					</th>
					<td>
						<fieldset>
							<legend class="screen-reader-text">
								<span><?php _e('Minimum Attendance', 'tutor-lms-attendance'); ?></span>
							</legend>
							<label class="qst-mrk-tlms-atd">
								<textarea rows="4" cols="50" name="tutor_lms_att_minimum_attendance" id="tutor_lms_att_minimum_attendance"><?php echo $minimum_att_text; ?> </textarea>
							</label>

						</fieldset>
					</td>

				</tr>
			</tbody>
		</table>
		<p>
			<?php
			submit_button(__('Save Settings', 'tutor-lms-attendance'), 'primary', 'tlms_at_settings_submit');
			?>
		</p>
	</form>
</div>
<?php
/**
 * Functions - VKMedia
 * 
 * @package Vikinger
 * 
 * @since 1.9.1
 * 
 * @author Odin Design Themes (https://odindesignthemes.com/)
 * 
 */

/**
 * BuddyPress
 */
require_once VIKINGER_PATH . '/includes/functions/vkmedia/vkmedia-buddypress/vikinger-functions-vkmedia-buddypress.php';

?>
<?php

/**
 * Fired when the plugin is uninstalled.
 *
 * When populating this file, consider the following flow
 * of control:
 *
 * - This method should be static
 * - Check if the $_REQUEST content actually is the plugin name
 * - Run an admin referrer check to make sure it goes through authentication
 * - Verify the output of $_GET makes sense
 * - Repeat with other user roles. Best directly by using the links/query string parameters.
 * - Repeat things for multisite. Once for a single site in the network, once sitewide.
 *
 * This file may be updated more in future version of the Boilerplate; however, this is the
 * general skeleton and outline for how the file should work.
 *
 * For more information, see the following discussion:
 * https://github.com/tommcfarlin/WordPress-Plugin-Boilerplate/pull/123#issuecomment-28541913
 *
 * @link       https://wooninjas.com/
 * @since      1.0.0
 *
 * @package    Tutor_Lms_Attendance
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$config_file = ABSPATH . 'wp-config.php';
$config_content = file_get_contents($config_file);
if (strpos($config_content, "define( 'WP_DEBUG', true );\ndefine('WP_DEBUG_LOG', true );\ndefine('WP_DEBUG_DISPLAY', false );") !== false) {
	$config_content = str_replace(
		"define( 'WP_DEBUG', true );\ndefine('WP_DEBUG_LOG', true );\ndefine('WP_DEBUG_DISPLAY', false );",
		"define( 'WP_DEBUG', false );",
		$config_content
	);
	file_put_contents($config_file, $config_content);
}

$options = get_option( 'tlms_at_options', array());
if( isset($options['tlms_at_delete_attendance']) && $options['tlms_at_delete_attendance'] == 'on' ) {
	global $wpdb;

	$table_name = $wpdb->prefix . "tlms_attendance_logs";
    $wpdb->query("DROP TABLE IF EXISTS {$table_name}");

	$table2_name = $wpdb->prefix . 'tlms_timetrack_logs';
	$wpdb->query("DROP TABLE IF EXISTS {$table2_name}");

    delete_option('tlms_at_options');
}
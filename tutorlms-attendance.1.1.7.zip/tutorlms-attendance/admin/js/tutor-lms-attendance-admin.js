
(function ($) {
    $(document).ready(function () {
        'use strict';
        var Datatable;
        // Data Table

        Datatable = $('#Datatable').DataTable(
            {
                columnDefs: [{
                    targets: 0,
                    checkboxes: {
                        selectRow: true,
                    },
                    orderable: false,
                    className: 'select-checkbox',
                }],
                select: {
                    style: 'os',
                    selector: 'td:first-child'
                },
                order: [[1, 'asc']]
            }
        );
    });
})(jQuery);
var LDA_Admin_Settings = {
    initDateRangePicker: function () {
        (function ($) {
            var dateRangeField = $('#tlms_at-daterange-picker');
            var clearDateRangeField = $('#tlms_at-clear-daterange-picker');

            clearDateRangeField.on('click', function (e) {
                e.preventDefault();
                dateRangeField.trigger('cancel.daterangepicker');
            });

            dateRangeField.daterangepicker({
                maxDate: moment(),
                autoUpdateInput: false,
                locale: {
                    format: 'DD-MM-YYYY',
                    cancelLabel: 'Clear'
                },
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                }
            }, function (start, end, label) {
                $('#tlms_at_date_start').val(start.format('YYYY-MM-DD'));
                $('#tlms_at_date_end').val(end.format('YYYY-MM-DD'));
            });

            dateRangeField.on('apply.daterangepicker', function (ev, picker) {
                $(this).val(picker.startDate.format('DD-MM-YYYY') + ' - ' + picker.endDate.format('DD-MM-YYYY'));
                $('#tlms_at_date_start').val(picker.startDate.format('YYYY-MM-DD'));
                $('#tlms_at_date_end').val(picker.endDate.format('YYYY-MM-DD'));
                clearDateRangeField.show();
            });

            dateRangeField.on('cancel.daterangepicker', function (ev, picker) {
                $(this).val('');
                $('#tlms_at_date_start').val('');
                $('#tlms_at_date_end').val('');
                clearDateRangeField.hide();
            });

            dateRangeField.on('change', function () {
                if ($(this).val().trim() == '') {
                    $('#tlms_at_date_start').val('');
                    $('#tlms_at_date_end').val('');
                }
            });
        })(jQuery);
    },
};


(function ($) {
    'use strict';

    /**
     * All of the code for your admin-facing JavaScript source
     * should reside in this file.
     *
     * Note: It has been assumed you will write jQuery code here, so the
     * $ function reference has been prepared for usage within the scope
     * of this function.
     *
     * This enables you to define handlers, for when the DOM is ready:
     *
     * $(function() {
     *
     * });
     *
     * When the window is loaded:
     *
     * $( window ).load(function() {
     *
     * });
     *
     * ...and/or other possibilities.
     *
     * Ideally, it is not considered best practise to attach more than a
     * single DOM-ready or window-load handler for a particular page.
     * Although scripts in the WordPress core, Plugins and Themes may be
     * practising this, we should strive to set a better example in our own work.
     */

    $(document).ready(function () {
        var urlParams = new URLSearchParams(window.location.search);
        var param_x = urlParams.has('action');

        if (param_x) {
            var action = urlParams.get('action');
            if (action == 'view_detail_logs') {
                $('#btn_clear_attendance_logs').hide();
            }
        }
        // Get the modal
        var modal = document.getElementById("tut_atd_Modal");

        // Get the button that opens the modal
        var btn = document.getElementById("btn_clear_attendance_logs");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks the button, open the modal
        if(btn != null){
            btn.onclick = function() {
                modal.style.display = "block";
                document.querySelector('body').style.overflow = 'hidden';
                }
        }
        

        // When the user clicks on <span> (x), close the modal
        if(span != null){
            span.onclick = function() {
            modal.style.display = "none";
            document.querySelector('body').style.overflow = 'unset';
            }
        }   

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
            document.querySelector('body').style.overflow = 'unset';
        }
        }
        $('#clearLogsYes').click(function () {
            let data = {
                action: "tlms_clear_attendance_logs",
            };
            $.ajax({
                type: "POST",
                url: ajaxurl,
                data: data,
                beforeSend: function (xhr) {
                    $("#btn_clear_attendance_logs").prop("disabled", true);
                    $('.reset_spinner').show()
                },
                success: function (response) {
                    if(response['error'] == false){
                        alert(response['message']);
                    }
                },
                complete: function (xhr, textStatus) {
                    $('.reset_spinner').hide()
                    location.reload()
                },
            });
        })
        $('#tlms_at_disable_user_mark_attendance').change(function () {
            if ($(this).is(':checked')) {
                $(this).next().slideDown();
            } else {
                $(this).next().slideUp();
            }
        });
        $('#tlms_at_attendance_allow_user_roles').change(function () {
            if ($(this).is(':checked')) {
                $(this).next().slideDown();
            } else {
                $(this).next().slideUp();
            }
        });
        $('#tlms_at_automatic_attendance_on_login').change(function () {
            if ($(this).is(':checked')) {
                $(this).next().slideDown();
            } else {
                $(this).next().slideUp();
            }
        });
        //===========> activity-log copy to clip board button
        $(document).on('click', '.tlms-ad-activity-copy-button', function (e) {
            $('.tlms-ad-activity-code-box').select();
            document.execCommand('copy');
        })
    })

    $(document).ready(function () {
        $(".qst-mrk-tlms-atd svg, .qst-mrk-tlms-atd i").click(function () {
            $(this).parent().next('p.description').fadeToggle();

        });
        $('.attendance_logs').removeClass("widefat wp-list-table");
    });
    $(document).ready(function () {
        $('#btn_export_attendance_logs').on('click', function () {

            
            var default_label = $(this).text();
            // Set filename
            var today = new Date();
            // var filename = 'Orders-' + today.toISOString().substring(0, 10) + 'wn_ld_export_feedback=table.csv';


            if (confirm(export_confirm)) {
                let data = {
                    action: "tlms_at_export_btn",
                };
                $.ajax({
                    type: "POST",
                    url: ajaxurl,
                    data: data,
                    success: function (response) {
                        if (response.errormsg != undefined) {
                            alert(response.errormsg);
                        } else {
                            // Make CSV in the response downloadable by creating a blob
                            var download_link = document.createElement("a");
                            var fileData = ['\ufeff' + response];
                            var blobObject = new Blob(fileData, {
                                type: "text/csv;charset=utf-8;"
                            });

                            // Actually download the CSV by temporarily creating a link to it and simulating a click
                            download_link.href = URL.createObjectURL(blobObject);
                            download_link.download = 'Attendance';
                            document.body.appendChild(download_link);
                            download_link.click();
                            document.body.removeChild(download_link);

                            // Remove the export button's loading state
                            $('.ld_fb_export_button').removeClass('loading').text(default_label);
                        }
                    },
                    error: function (response) {
                        console.log(response);
                        $('.ld_fb_export_button').removeClass('loading').addClass('error').text('Error exporting');
                    },
                });
            }
        });

        $(document).on('submit', '#tlms_at_upload_file_form', function (e) {
            e.preventDefault();
            var formData = new FormData(this);
            console.log(formData);
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: formData,
                cache: false,
                dataType: 'json',
                contentType: false,
                processData: false,
                beforeSend: function (jqXHR, settings) {
                    $('#tlms_at_loader_spinner').show();
                    $('#tlms_at_import_messages').html('');
                },
                success: function (data, textStatus, jqXHR) {
                    $('.tlms-at-import-log').html(data.log);
                    alert(data);
                    location.reload();
                    // console.log(data);
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    $('.tlms-at-import-log').html(textStatus);
                    alert(textStatus)
                },
                complete: function (jqXHR, textStatus) {
                    $('#tlms_at_loader_spinner').hide();
                }
            });
        })
    });



})(jQuery);
